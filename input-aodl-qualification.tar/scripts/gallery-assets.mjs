#!/usr/bin/env node
// Copy self-hosted fonts into gallery/public/fonts (no font CDN at runtime).
import { copyFileSync, mkdirSync } from 'node:fs';
import { createRequire } from 'node:module';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const require = createRequire(join(root, 'gallery', 'package.json'));
const out = join(root, 'gallery', 'public', 'fonts');
mkdirSync(out, { recursive: true });
const faces = [
  ['@fontsource/cormorant-garamond', ['cormorant-garamond-latin-400-normal.woff2', 'cormorant-garamond-latin-500-normal.woff2']],
  ['@fontsource/hanken-grotesk', ['hanken-grotesk-latin-400-normal.woff2', 'hanken-grotesk-latin-500-normal.woff2']],
  ['@fontsource/ibm-plex-mono', ['ibm-plex-mono-latin-400-normal.woff2']],
];
for (const [pkg, files] of faces) {
  const dir = join(dirname(require.resolve(`${pkg}/package.json`)), 'files');
  for (const f of files) copyFileSync(join(dir, f), join(out, f));
}
console.log(`fonts -> ${out}`);
