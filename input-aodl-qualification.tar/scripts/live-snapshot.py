#!/usr/bin/env python3
"""Snapshot real Hermes activity into a live.json the aodl-views gallery reads.

Read-only. Opens every Hermes profile SessionDB with mode=ro and runs
`git worktree list` / `git remote get-url`. Writes schema 2:

  chats / subagents   id, profile, source, title, model, parent, messages, tools,
                      lastActivity, live, ended, activity, repoTouches
  repos               repo, weight (decayed now), lastTouched
  worktrees           path, head, branch, repo, name, isPrimary

Privacy: session titles are the only free text kept. `activity` is reduced to a
known runtime phrase (tool name, streaming, ...) or dropped; message bodies and
tool arguments are scanned for repo paths and never written.

Usage: live-snapshot.py OUT.json [--hours 24] [--half-life 2] [--worktree-root PATH ...]
"""
import argparse
import json
import os
import re
import socket
import sqlite3
import subprocess
import time
from pathlib import Path

HOME = Path.home()
DEFAULT_ROOTS = [
    "/mnt/zer0models/workspace/zer0/products/dash",
    "/mnt/zer0models/workspace/zer0/products/z0live",
    "/mnt/zer0models/lawnchair-z0live",
    "/mnt/zer0models/workspace/zer0/products/zerOS",
]
PATH_RE = re.compile(r"(/(?:mnt/zer0models|workspace|home/kvn)/[\w./~-]+)")
BUCKET_S = 600  # touches are kept in 10-minute buckets
SAFE_ACTIVITY = [
    re.compile(r"^(tool (?:running|completed): [\w.-]+)"),
    re.compile(r"^(sequential tool running \(\d+s\): [\w.-]+)"),
    re.compile(r"^(terminal command running)"),
    re.compile(r"^(receiving stream response)"),
    re.compile(r"^delegate_task: (subagent (?:receiving stream response|running [\w.-]+))"),
]


def safe_activity(text: str) -> str:
    t = (text or "").strip()
    for rx in SAFE_ACTIVITY:
        m = rx.match(t)
        if m:
            return m.group(1)
    return ""


_remote: dict = {}


def repo_of(path: str):
    p = Path(path)
    for cand in [p, *p.parents]:
        key = str(cand)
        if key in _remote:
            return _remote[key]
        if len(cand.parts) <= 3:
            break
        if (cand / ".git").exists():
            try:
                url = subprocess.run(["git", "-C", key, "remote", "get-url", "origin"],
                                     capture_output=True, text=True, timeout=3).stdout.strip()
            except Exception:
                url = ""
            m = re.search(r"github\.com[:/]([^/]+/[^/.]+)", url)
            _remote[key] = m.group(1) if m else None
            return _remote[key]
    return None


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("out")
    ap.add_argument("--hours", type=float, default=24)
    ap.add_argument("--half-life", type=float, default=2)
    ap.add_argument("--worktree-root", action="append")
    args = ap.parse_args()
    now = time.time()
    window_s = args.hours * 3600
    half_s = args.half_life * 3600
    decay = lambda ts: 0.5 ** (max(0.0, now - ts) / half_s)  # noqa: E731

    dbs = {}
    for p in sorted((HOME / ".hermes/profiles").glob("*/state.db")):
        dbs[p.parent.name] = p
    chats, subagents, repo_weight, repo_touch = [], [], {}, {}
    for profile, db in dbs.items():
        try:
            con = sqlite3.connect(f"file:{db}?mode=ro", uri=True, timeout=5)
            con.row_factory = sqlite3.Row
            rows = con.execute(
                "select id, source, title, model, parent_session_id, started_at, ended_at, message_count,"
                " tool_call_count, last_activity_at, last_activity_description, git_repo_root"
                " from sessions where coalesce(last_activity_at, started_at) > ? and coalesce(hidden,0)=0",
                (now - window_s,)).fetchall()
        except sqlite3.Error:
            continue
        for r in rows:
            last = r["last_activity_at"] or r["started_at"] or 0
            if last > 1e11:
                last /= 1000.0
            buckets: dict = {}
            for (calls, ts) in con.execute(
                    "select tool_calls, timestamp from messages where session_id=? and tool_calls is not null"
                    " order by id desc limit 400", (r["id"],)):
                t = ts if ts and ts < 1e11 else (ts or 0) / 1000.0
                t = t or last
                for path in set(PATH_RE.findall(calls or "")):
                    repo = repo_of(path.rstrip(".,;:'\""))
                    if repo:
                        b = int(t // BUCKET_S * BUCKET_S)
                        buckets.setdefault(repo, {}).setdefault(b, 0)
                        buckets[repo][b] += 1
            if r["git_repo_root"]:
                repo = repo_of(r["git_repo_root"])
                if repo:
                    b = int(last // BUCKET_S * BUCKET_S)
                    buckets.setdefault(repo, {}).setdefault(b, 0)
                    buckets[repo][b] += 1
            touches = {repo: sorted([b, c] for b, c in bs.items()) for repo, bs in buckets.items()}
            weights = {repo: sum(c * decay(b) for b, c in ts) for repo, ts in touches.items()}
            top = dict(sorted(weights.items(), key=lambda kv: -kv[1])[:12])
            live = r["ended_at"] is None and now - last < 900
            item = {
                "id": r["id"], "profile": profile, "source": r["source"], "title": r["title"] or "(untitled)",
                "model": r["model"], "parent": r["parent_session_id"], "messages": r["message_count"] or 0,
                "tools": r["tool_call_count"] or 0, "lastActivity": last, "live": live,
                "ended": r["ended_at"] is not None,
                "activity": safe_activity(r["last_activity_description"]) if live else "",
                "repoTouches": {k: touches[k] for k in top},
            }
            (subagents if r["parent_session_id"] else chats).append(item)
            for repo, w in top.items():
                repo_weight[repo] = repo_weight.get(repo, 0.0) + w
                repo_touch[repo] = max(repo_touch.get(repo, 0), max(b for b, _ in touches[repo]))
        con.close()

    worktrees = []
    for root in args.worktree_root or DEFAULT_ROOTS:
        try:
            out = subprocess.run(["git", "-C", root, "worktree", "list", "--porcelain"],
                                 capture_output=True, text=True, timeout=5).stdout
        except Exception:
            continue
        repo = repo_of(root)
        cur: dict = {}
        for line in out.splitlines() + [""]:
            if not line:
                if cur.get("path"):
                    cur.update(repo=repo, name=os.path.basename(cur["path"]), isPrimary=cur["path"] == root)
                    worktrees.append(cur)
                cur = {}
            elif line.startswith("worktree "):
                cur["path"] = line[9:]
            elif line.startswith("HEAD "):
                cur["head"] = line[5:12]
            elif line.startswith("branch "):
                cur["branch"] = line[7:].replace("refs/heads/", "")

    data = {
        "schemaVersion": 2, "generatedAt": now, "windowHours": args.hours, "halfLifeHours": args.half_life,
        "host": socket.gethostname(),
        "chats": sorted(chats, key=lambda c: -c["lastActivity"]),
        "subagents": sorted(subagents, key=lambda c: -c["lastActivity"]),
        "repos": [{"repo": k, "weight": round(v, 4), "lastTouched": repo_touch[k]}
                  for k, v in sorted(repo_weight.items(), key=lambda kv: -kv[1])],
        "worktrees": worktrees,
    }
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(data, separators=(",", ":")))
    print(f"{out}: chats={len(chats)} subagents={len(subagents)} repos={len(data['repos'])} worktrees={len(worktrees)}")


if __name__ == "__main__":
    main()
