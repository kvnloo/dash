#!/usr/bin/env python3
"""Capture gallery frames with headless Chromium (system chromium via Playwright).

  shoot.py URL OUTDIR [--widths 390,1100] [--prefix aodl-views]

Writes a full-page frame per width plus one frame per gallery section
(testID=section-*), after fonts and the live snapshot have loaded. Prints any
console errors so a red console fails loudly.
"""
import argparse
import sys
from pathlib import Path

from playwright.sync_api import sync_playwright

ap = argparse.ArgumentParser()
ap.add_argument("url")
ap.add_argument("out")
ap.add_argument("--widths", default="390,1100")
ap.add_argument("--prefix", default="aodl-views")
ap.add_argument("--chromium", default="/usr/bin/chromium")
ap.add_argument("--full", action="store_true")
ap.add_argument("--only", default="")
args = ap.parse_args()
out = Path(args.out)
out.mkdir(parents=True, exist_ok=True)
errors = []
with sync_playwright() as p:
    browser = p.chromium.launch(executable_path=args.chromium, args=["--no-sandbox"])
    for w in [int(x) for x in args.widths.split(",")]:
        page = browser.new_page(viewport={"width": w, "height": 900}, device_scale_factor=2 if w <= 430 else 1)
        page.on("console", lambda m: m.type == "error" and errors.append(f"[{w}] {m.text}"))
        page.on("pageerror", lambda e: errors.append(f"[{w}] pageerror {e}"))
        page.goto(args.url, wait_until="networkidle", timeout=90000)
        page.wait_for_selector('[data-testid="section-glyph"]', timeout=60000)
        page.evaluate("document.fonts.ready")
        page.wait_for_timeout(1800)
        sections = page.locator('[data-testid^="section-"]')
        for i in range(sections.count()):
            el = sections.nth(i)
            sid = el.get_attribute("data-testid").replace("section-", "")
            if args.only and sid not in args.only.split(","):
                continue
            el.scroll_into_view_if_needed()
            page.wait_for_timeout(700)
            path = out / f"{args.prefix}-{w}-{i + 1:02d}-{sid}.png"
            el.screenshot(path=str(path))
            print(path)
        if args.full:
            path = out / f"{args.prefix}-{w}-full.png"
            page.screenshot(path=str(path), full_page=True)
            print(path)
        page.close()
    browser.close()
for e in errors:
    print("CONSOLE", e, file=sys.stderr)
sys.exit(1 if any("pageerror" in e for e in errors) else 0)
