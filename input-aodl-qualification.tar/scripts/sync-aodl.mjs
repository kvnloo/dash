#!/usr/bin/env node
// Vendor a pinned copy of the AODL encodings this library reads as data.
//
//   node scripts/sync-aodl.mjs [path-to-aodl-checkout] [--ref origin/main]
//
// Reads the files with `git show <ref>:<path>` so the copy matches one commit
// exactly, then writes aodl/SOURCE.json with that commit SHA. Never edit the
// vendored JSON by hand: change kvnloo/aodl first, then re-sync.
import { execFileSync } from 'node:child_process';
import { writeFileSync, mkdirSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const FILES = ['encodings/visual.json', 'encodings/topology-graphs.json', 'encodings/ir-map.json', 'harnesses/catalog.json'];
const args = process.argv.slice(2);
const refIdx = args.indexOf('--ref');
const ref = refIdx >= 0 ? args[refIdx + 1] : 'origin/main';
const checkout = resolve(args.find((a, i) => !a.startsWith('--') && args[i - 1] !== '--ref') || process.env.AODL_CHECKOUT || '../aodl');
const out = join(dirname(fileURLToPath(import.meta.url)), '..', 'aodl');

const git = (...a) => execFileSync('git', ['-C', checkout, ...a], { encoding: 'utf8', maxBuffer: 1 << 24 });
const sha = git('rev-parse', ref).trim();
mkdirSync(out, { recursive: true });
for (const file of FILES) {
  const text = git('show', `${sha}:${file}`);
  JSON.parse(text); // fail loudly on a broken upstream file
  writeFileSync(join(out, file.split('/').pop()), text.endsWith('\n') ? text : `${text}\n`);
}
const source = { repo: 'kvnloo/aodl', ref, sha, files: FILES, syncedAt: new Date().toISOString().slice(0, 10) };
writeFileSync(join(out, 'SOURCE.json'), `${JSON.stringify(source, null, 2)}\n`);
console.log(`aodl/ <- kvnloo/aodl@${sha.slice(0, 12)} (${FILES.length} files)`);
