#!/usr/bin/env python3
"""Interaction + motion probes for the built gallery (headless Chromium).

  probe.py URL OUTDIR

1. decompose: tap a folded live glyph, capture mid-morph and open, tap the hub to fold.
2. motion: two frames of a running glyph 450 ms apart must differ; a paused one must not.
3. reduced motion: with prefers-reduced-motion the running glyph must hold still.
4. legacy: /legacy/gallery.html still renders its sections.
Exits non-zero when a probe fails.
"""
import sys
from pathlib import Path

from playwright.sync_api import sync_playwright

url, out = sys.argv[1].rstrip("/"), Path(sys.argv[2])
out.mkdir(parents=True, exist_ok=True)
fails = []


def same(a: bytes, b: bytes) -> bool:
    return a == b


with sync_playwright() as p:
    browser = p.chromium.launch(executable_path="/usr/bin/chromium", args=["--no-sandbox"])

    page = browser.new_page(viewport={"width": 1100, "height": 1000})
    page.goto(url + "/", wait_until="networkidle")
    page.wait_for_selector('[data-testid="section-glyph"]')
    page.wait_for_timeout(1200)

    # 1. decompose a folded live glyph (the second live chat in section 1)
    opener = page.locator('[aria-label^="Open "]').first
    opener.scroll_into_view_if_needed()
    box = opener.bounding_box()
    region = {"x": max(0, box["x"] - 8), "y": max(0, box["y"] - 8), "width": 520, "height": 380}
    page.screenshot(path=str(out / "decompose-0-folded.png"), clip=region)
    folds_before = page.locator('[aria-label^="Fold "]').count()
    opener.click()
    page.wait_for_timeout(90)
    page.screenshot(path=str(out / "decompose-1-mid.png"), clip=region)
    page.wait_for_timeout(700)
    page.screenshot(path=str(out / "decompose-2-open.png"), clip=region)
    folds = page.locator('[aria-label^="Fold "]')
    if folds.count() != folds_before + 1:
        fails.append(f"decompose: expected one more open glyph, {folds_before} -> {folds.count()}")
    folds.nth(folds.count() - 1).click()
    page.wait_for_timeout(900)
    page.screenshot(path=str(out / "decompose-3-folded-again.png"), clip=region)

    # 2. motion
    running = page.locator('[data-testid="cadence-running"]')
    paused = page.locator('[data-testid="cadence-paused"]')
    running.scroll_into_view_if_needed()
    page.wait_for_timeout(300)
    r1, p1 = running.screenshot(), paused.screenshot()
    page.wait_for_timeout(450)
    r2, p2 = running.screenshot(), paused.screenshot()
    if same(r1, r2):
        fails.append("motion: running glyph did not move")
    if not same(p1, p2):
        fails.append("motion: paused glyph moved")
    page.close()

    # 3. reduced motion
    ctx = browser.new_context(viewport={"width": 1100, "height": 1000}, reduced_motion="reduce")
    page = ctx.new_page()
    page.goto(url + "/", wait_until="networkidle")
    page.wait_for_selector('[data-testid="cadence-running"]')
    running = page.locator('[data-testid="cadence-running"]')
    running.scroll_into_view_if_needed()
    page.wait_for_timeout(500)
    a = running.screenshot()
    page.wait_for_timeout(450)
    b = running.screenshot()
    if not same(a, b):
        fails.append("reduced-motion: running glyph still moves")
    ctx.close()

    # 4. legacy
    page = browser.new_page(viewport={"width": 1100, "height": 900})
    page.goto(url + "/legacy/gallery.html", wait_until="networkidle")
    try:
        page.wait_for_selector("#graph", timeout=20000)
        page.screenshot(path=str(out / "legacy-top.png"))
    except Exception as e:  # noqa: BLE001
        fails.append(f"legacy: {e}")
    page.close()
    browser.close()

for f in fails:
    print("FAIL", f)
print("probes:", "ok" if not fails else f"{len(fails)} failed")
sys.exit(1 if fails else 0)
