#!/usr/bin/env python3
"""Capture the zerOS originals (legacy gallery sections) for the side-by-side.

  capture-originals.py OUTDIR [URL]

Needs the zerOS gallery (homeforge gallery.html) served somewhere; default is
the legacy copy under /legacy/ on the gallery host.
"""
import sys
from playwright.sync_api import sync_playwright
out = sys.argv[1]
url = sys.argv[2] if len(sys.argv) > 2 else 'http://100.113.138.100:5188/legacy/gallery.html'
with sync_playwright() as p:
    b = p.chromium.launch(executable_path='/usr/bin/chromium', args=['--no-sandbox'])
    for w in (1100,):
        pg = b.new_page(viewport={'width': w, 'height': 900}, device_scale_factor=1)
        pg.goto(url, wait_until='networkidle', timeout=60000)
        pg.wait_for_timeout(2500)
        for sid in ['chat', 'graph', 'topology', 'tree', 'orbs']:
            el = pg.locator(f'#{sid}')
            bb = el.bounding_box()
            print(sid, bb)
            clip_h = min(bb['height'], 1400)
            pg.screenshot(path=f'{out}/zeros-{sid}.png', clip={'x': bb['x'], 'y': bb['y'], 'width': bb['width'], 'height': clip_h}, full_page=True)
    b.close()
