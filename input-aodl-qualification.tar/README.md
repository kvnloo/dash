# aodl-views

Orchestration views for AODL graphs, for React Native and the web.

One set of components runs in Dash (Expo Go) and in zerOS (react-native-web).
They draw what agents are doing: who spawned whom, which repos they touch,
how they coordinate, and what each one is thinking right now.

| Component | What it shows |
|---|---|
| `TopologyGlyph` | An orchestration as a badge (16 / 24 / 40 px). Shape is the AODL silhouette, node colour is provider hue, motion is runtime cadence. |
| `DecomposingGlyph` | The glyph is the graph, folded. Tap and every glyph node travels to its place in the member graph; tap the hub and it folds back. |
| `GraphView` | Hosts, chats, subagents and repos. Spine, constellation, radial and island layouts; focus or all; tap to focus, hold to inspect; flow along edges. |
| `TreeView` | host → chat → subagents, and repo → trunk → integration → feature packs → leaves. Collapsible. |
| `TopologyIslands` | Every chat that delegated, as its glyph, with a count per topology. |
| `RepoMap` | Packed bubbles sized by time-decayed touch weight. Scrub "as of" or change the half-life and they re-weigh. |
| `AgentThinking` | Agent state as a [thinking-orbs](https://github.com/Jakubantalik/thinking-orbs) orb. |

## The language

These views decode AODL's visual channels; they do not invent new ones.

- **Topology** (shape): one of the 16 ids in `aodl/visual.json`, drawn from
  `aodl/topology-graphs.json`. A live graph gets an id only through AODL rules
  (see `src/model/compress.ts`): a declared id, declared `policies.kinds`
  through `ir-map.json`, or delegation structure (one executor → solo,
  delegation fan-out → star, nested delegation → hierarchy). `swarm` and
  `hybrid` are never inferred. Anything else stays `unknown`.
- **Provider** (hue), **model** (core geometry), **effort** (orbits),
  **operating mode** (rune) and **runtime state** (cadence) are visual
  channels only. They never become HOTL fields.
- **Cadence**: running flows; claimed flows 2.2× slower with a hollow hub;
  paused and stale hold still (stale is dashed and faded); blocked holds still
  behind a slow warning pulse. Reduced motion stops all of it.
- **Zoom** (from Ripple): unit → pattern (the dots and wires inside) → the
  node stays a node.

## Thinking states

| State | Orb |
|---|---|
| idle | breathing, frozen |
| thinking | working (planning: weaving, solving: solving) |
| tool | connecting (search/read tools: searching, edit tools: shaping) |
| streaming | composing (voice: listening) |
| waiting-approval | breathing, slow, with a gold rim |

The full table and reasons are in `src/thinking/mapping.ts`.

## Data

Every view takes one `OrchestrationGraph` (`src/model/types.ts`): nodes with a
HOTL `kind` (executor, artifact, environment, …) and a display `role` (host,
chat, subagent, repo, worktree), and edges with a HOTL `relation`
(delegation, artifact, …). Adapters:

- `fromLiveSnapshot(json)`: the snapshot written by `scripts/live-snapshot.py`
  (read-only over Hermes SessionDBs and `git worktree list`; titles are the
  only free text kept).
- `fromDashRoster(hosts)`: Dash bridge `HostInfo[]`.
- `fromZ0BridgeSessions(list)`: z0bridge `GET /sessions`.

## Use

```tsx
import { fromLiveSnapshot, DecomposingGlyph, GraphView } from '@kvnloo/aodl-views';

const graph = fromLiveSnapshot(snapshot);
<DecomposingGlyph graph={graph} rootId="chat:abc" width={358} />
<GraphView graph={graph} width={358} />
```

Peer dependencies: `react`, `react-native`, `react-native-svg`,
`react-native-reanimated`, `react-native-worklets`, and (native only, for the
orb) `@shopify/react-native-skia`. All are in Expo Go for SDK 57.

## Develop

```bash
bun install
npm run typecheck && npm run lint && npm test
npm run snapshot              # real data -> gallery/public/live.json (gitignored)
npm run gallery:build         # Expo web export -> gallery/dist
npm run gallery:android-bundle  # proves the native bundle compiles
```

`npm run sync:aodl -- <aodl checkout>` refreshes the pinned AODL encodings.

## Licence

MIT. Third-party notices in `NOTICE.md`.
