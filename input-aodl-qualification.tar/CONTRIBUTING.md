# Contributing

Small, focused pull requests. Never merge `main` yourself.

## Gates

```bash
npm run typecheck
npm run lint
npm test
npm run gallery:build           # web render path
npm run gallery:android-bundle  # native bundle path
```

UI changes also need rendered evidence: build the gallery, serve `gallery/dist`
on 127.0.0.1:5199 and run `python3 scripts/shoot.py http://127.0.0.1:5199/ <dir>`
(390 and 1100 px) and `python3 scripts/probe.py http://127.0.0.1:5199 <dir>`
(decompose, motion, reduced motion). Look at every frame.

## Rules for people and agents

- **AODL is data.** `aodl/` is a pinned copy of kvnloo/aodl. Do not edit it;
  change AODL first, then `npm run sync:aodl`.
- **No new topology ids.** Only the ids in `aodl/visual.json`. The zerOS
  research ids (`map_reduce`, `debate`, `graph`, `relay`, `ensemble`) are not in
  AODL yet; they need an AODL change before they can be drawn here.
- **Never infer a topology from a drawing.** `swarm` and `hybrid` stay
  not-inferred. Compression rules live in `src/model/compress.ts`, with tests.
  Unknown stays unknown.
- **Visual channels stay visual.** Provider hue, model geometry, effort orbits,
  mode runes and runtime cadence are never IR fields.
- **Use thinking-orbs, do not redraw it.** Web uses the npm package; native
  uses the vendored upstream port (`src/thinking/vendor/`). Fix bugs on
  kvnloo/thinking-orbs, then re-vendor. Keep NOTICE.md current.
- **Privacy.** Snapshots keep session titles only. `gallery/public/live.json`
  and captured originals are gitignored; never commit transcripts or secrets.
- **Motion.** Transform/opacity-style props only, one clock per drawing, and
  every animation stops under reduced motion.
- **Calm.** No debug chrome, no walls of explanatory text, no legacy
  fallbacks. Status is a ring or cadence, not a caption. Legible at 390 px.
- **Expo Go.** No native modules outside the Expo SDK.

Commits: `type(scope): summary`, author Kevin Rajan
<7121943+kvnloo@users.noreply.github.com>.
