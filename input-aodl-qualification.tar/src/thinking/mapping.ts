/**
 * AgentThinking states -> thinking-orbs types (Jakubantalik/thinking-orbs).
 *
 * | Agent state        | refinement            | orb         | why                                              |
 * |--------------------|-----------------------|-------------|--------------------------------------------------|
 * | idle               |                       | breathing   | frozen frame: present, not working               |
 * | thinking           | (default)             | working     | particles on tilted orbits: AODL effort = orbits  |
 * | thinking           | planning              | weaving     | three strands plait: steps being braided          |
 * | thinking           | solving               | solving     | bands scramble, then click back solved            |
 * | tool               | (default)             | connecting  | a constellation wires itself: reaching a tool     |
 * | tool               | search / read tools   | searching   | a scan meridian sweeps the globe                  |
 * | tool               | edit / write tools    | shaping     | outline morphs circle -> triangle -> square       |
 * | streaming          | (default)             | composing   | an undulating multi-band sash: words coming out   |
 * | streaming          | voice                 | listening   | a waveform rolls through the rings                |
 * | waiting-approval   |                       | breathing   | slow ring + gold rim: the owner's move (humanGate)|
 *
 * All nine orb types are reachable. The orbs stay monochrome as published;
 * waiting-approval adds a gold rim around the orb, not a recolour.
 */
import type { OrbState } from 'thinking-orbs/engine';
import type { ThinkingPhase } from '../model/types';

export type ThinkingIntent = 'planning' | 'solving' | 'voice';

export interface OrbChoice {
  orb: OrbState;
  /** Speed multiplier on the preset's tuned speed. */
  speed: number;
  paused: boolean;
  /** Gold rim: the agent is waiting on a person. */
  rim: boolean;
  caption: string;
}

const SEARCH_TOOLS = /search|grep|find|fetch|extract|browse|browser|web|read|qmd|rg|fd|recall|lookup|view/;
const EDIT_TOOLS = /patch|write|edit|apply|replace|create|format|skill_manage/;

export function orbFor(phase: ThinkingPhase, opts: { tool?: string; intent?: ThinkingIntent } = {}): OrbChoice {
  const tool = String(opts.tool || '').toLowerCase();
  switch (phase) {
    case 'thinking':
      if (opts.intent === 'planning') return { orb: 'weaving', speed: 1, paused: false, rim: false, caption: 'Planning' };
      if (opts.intent === 'solving') return { orb: 'solving', speed: 1, paused: false, rim: false, caption: 'Solving' };
      return { orb: 'working', speed: 1, paused: false, rim: false, caption: 'Thinking' };
    case 'tool':
      if (tool && SEARCH_TOOLS.test(tool)) return { orb: 'searching', speed: 1, paused: false, rim: false, caption: `Searching · ${opts.tool}` };
      if (tool && EDIT_TOOLS.test(tool)) return { orb: 'shaping', speed: 1, paused: false, rim: false, caption: `Editing · ${opts.tool}` };
      return { orb: 'connecting', speed: 1, paused: false, rim: false, caption: tool ? `Using ${opts.tool}` : 'Using a tool' };
    case 'streaming':
      if (opts.intent === 'voice') return { orb: 'listening', speed: 1, paused: false, rim: false, caption: 'Listening' };
      return { orb: 'composing', speed: 1, paused: false, rim: false, caption: 'Writing' };
    case 'waiting-approval':
      return { orb: 'breathing', speed: 0.6, paused: false, rim: true, caption: 'Waiting for you' };
    default:
      return { orb: 'breathing', speed: 1, paused: true, rim: false, caption: 'Idle' };
  }
}

export const ALL_ORB_TYPES: OrbState[] = ['working', 'searching', 'solving', 'listening', 'connecting', 'weaving', 'composing', 'breathing', 'shaping'];
