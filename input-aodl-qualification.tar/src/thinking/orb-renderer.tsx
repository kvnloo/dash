/**
 * Native orb renderer: the upstream thinking-orbs React Native port (Skia),
 * vendored unmodified from the owner's fork. Geometry comes from the same
 * `thinking-orbs/engine` the web component runs.
 */
export { ThinkingOrb as OrbRenderer } from './vendor/thinking-orbs-native';
