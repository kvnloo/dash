/**
 * Web orb renderer: the upstream `thinking-orbs` canvas component, unchanged.
 * react-native-web renders to the DOM, so the DOM component mounts directly.
 */
import React from 'react';
import { ThinkingOrb } from 'thinking-orbs';
import type { ThinkingOrbProps } from './vendor/thinking-orbs-native';

export function OrbRenderer({ state, size, theme = 'dark', speed, paused, accessibilityLabel }: ThinkingOrbProps) {
  return <ThinkingOrb state={state} size={size} theme={theme} speed={speed} paused={paused} aria-label={accessibilityLabel} />;
}
