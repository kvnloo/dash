/**
 * Living Night tokens, ported from zerOS `packages/ui-foundation/tokens.json`
 * (kvnloo/solarpunk @ wip/control-uncommitted-2026-07-16). tokens.json is the
 * authority; oklch values were converted to sRGB hex once, here.
 */
export const night = {
  canvas: '#0c0c0a',
  canvasRaised: '#151611',
  glass: 'rgba(24,26,23,0.46)',
  glassStrong: 'rgba(20,22,19,0.66)',
  glassRaised: 'rgba(18,20,17,0.82)',
  rim: 'rgba(255,255,255,0.10)',
  textPrimary: '#ECE8DF',
  textSecondary: '#B4AFA3',
  textTertiary: '#837F74',
  textFaint: '#5e5b52',
  /** oklch(0.80 0.075 80) */
  action: '#d7b986',
  /** oklch(0.86 0.09 85) */
  actionStrong: '#eccd8c',
  /** oklch(0.62 0.06 80) */
  actionMuted: '#99835c',
  /** oklch(0.80 0.11 140) */
  success: '#98cf8b',
  /** oklch(0.76 0.075 235) */
  information: '#81b9da',
  /** oklch(0.78 0.10 60) */
  warning: '#e7a875',
  /** oklch(0.70 0.13 35) */
  danger: '#e37f65',
  /** oklch(0.72 0.08 305) */
  provenance: '#b098cd',
  borderQuiet: 'rgba(236,232,223,0.06)',
  borderSubtle: 'rgba(236,232,223,0.10)',
  borderDefault: 'rgba(236,232,223,0.16)',
} as const;

export const space = { 1: 4, 2: 8, 3: 12, 4: 16, 6: 24, 8: 32, 12: 48 } as const;
export const radius = { control: 6, card: 8, sheet: 14, scene: 18, pill: 999 } as const;

/** Motion durations (ms) and the settle curve, from tokens.json foundation. */
export const motion = {
  immediate: 140,
  state: 240,
  transition: 560,
  ambient: 14000,
  /** --z-ease-settle cubic-bezier(.2,.75,.2,1) */
  settle: [0.2, 0.75, 0.2, 1] as const,
} as const;

export { fonts } from './fonts';
import { fonts } from './fonts';

export const type = {
  title: { fontFamily: fonts.editorial, fontSize: 22, lineHeight: 26, color: night.textPrimary },
  label: { fontFamily: fonts.operational, fontSize: 13, lineHeight: 17, color: night.textPrimary },
  meta: { fontFamily: fonts.operational, fontSize: 11, lineHeight: 14, color: night.textTertiary },
  mono: { fontFamily: fonts.telemetry, fontSize: 10, lineHeight: 13, color: night.textTertiary, letterSpacing: 0.4 },
} as const;
