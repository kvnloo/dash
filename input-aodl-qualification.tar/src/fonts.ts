import { Platform } from 'react-native';

/**
 * Living Night type families. Web gets CSS stacks; native gets the
 * @expo-google-fonts face names the host app loads with expo-font
 * (unloaded faces fall back to the system font).
 */
export const fonts = Platform.select({
  web: {
    editorial: '"Cormorant Garamond", Georgia, serif',
    operational: '"Hanken Grotesk", system-ui, -apple-system, sans-serif',
    telemetry: '"IBM Plex Mono", ui-monospace, SFMono-Regular, monospace',
  },
  default: {
    editorial: 'CormorantGaramond_500Medium',
    operational: 'HankenGrotesk_400Regular',
    telemetry: 'IBMPlexMono_400Regular',
  },
});
