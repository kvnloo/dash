/**
 * Deterministic circle packing for the repo map. Largest circle first; every
 * next circle takes the tangent spot (against one or two placed circles) that
 * is closest to the centre without overlap. n <= ~40, so O(n^3) is fine.
 */
export interface PackInput {
  id: string;
  r: number;
}
export interface PackedCircle {
  id: string;
  x: number;
  y: number;
  r: number;
}

const GAP = 3;

function fits(x: number, y: number, r: number, placed: PackedCircle[]): boolean {
  for (const p of placed) {
    const d = Math.hypot(p.x - x, p.y - y);
    if (d < p.r + r + GAP - 1e-6) return false;
  }
  return true;
}

export function packCircles(items: PackInput[], aspect = 1): PackedCircle[] {
  const list = [...items].filter((i) => i.r > 0).sort((a, b) => b.r - a.r || a.id.localeCompare(b.id));
  const placed: PackedCircle[] = [];
  // Distance metric stretched by aspect so wide containers pack wide.
  const cost = (x: number, y: number) => Math.hypot(x / aspect, y);
  for (const item of list) {
    if (!placed.length) {
      placed.push({ id: item.id, x: 0, y: 0, r: item.r });
      continue;
    }
    let best: { x: number; y: number; c: number } | null = null;
    const consider = (x: number, y: number) => {
      if (!fits(x, y, item.r, placed)) return;
      const c = cost(x, y);
      if (!best || c < best.c) best = { x, y, c };
    };
    for (let i = 0; i < placed.length; i += 1) {
      const a = placed[i];
      // Tangent to a single circle, 12 directions.
      for (let k = 0; k < 12; k += 1) {
        const t = (k / 12) * Math.PI * 2;
        consider(a.x + Math.cos(t) * (a.r + item.r + GAP), a.y + Math.sin(t) * (a.r + item.r + GAP));
      }
      for (let j = i + 1; j < placed.length; j += 1) {
        const b = placed[j];
        // Tangent to both a and b: intersect circles of radius a.r+r and b.r+r.
        const ra = a.r + item.r + GAP;
        const rb = b.r + item.r + GAP;
        const dx = b.x - a.x;
        const dy = b.y - a.y;
        const d = Math.hypot(dx, dy);
        if (d === 0 || d > ra + rb || d < Math.abs(ra - rb)) continue;
        const l = (ra * ra - rb * rb + d * d) / (2 * d);
        const h = Math.sqrt(Math.max(0, ra * ra - l * l));
        const mx = a.x + (dx * l) / d;
        const my = a.y + (dy * l) / d;
        consider(mx + (-dy * h) / d, my + (dx * h) / d);
        consider(mx - (-dy * h) / d, my - (dx * h) / d);
      }
    }
    const b = best as { x: number; y: number } | null;
    placed.push({ id: item.id, x: b ? b.x : 0, y: b ? b.y : 0, r: item.r });
  }
  return placed;
}

/** Scale + translate packed circles to fit a box with padding. */
export function fitPack(circles: PackedCircle[], width: number, height: number, pad = 8): { circles: PackedCircle[]; scale: number } {
  if (!circles.length) return { circles, scale: 1 };
  const minX = Math.min(...circles.map((c) => c.x - c.r));
  const maxX = Math.max(...circles.map((c) => c.x + c.r));
  const minY = Math.min(...circles.map((c) => c.y - c.r));
  const maxY = Math.max(...circles.map((c) => c.y + c.r));
  const scale = Math.min((width - 2 * pad) / (maxX - minX || 1), (height - 2 * pad) / (maxY - minY || 1));
  const ox = (width - (maxX - minX) * scale) / 2 - minX * scale;
  const oy = (height - (maxY - minY) * scale) / 2 - minY * scale;
  return { circles: circles.map((c) => ({ id: c.id, x: ox + c.x * scale, y: oy + c.y * scale, r: c.r * scale })), scale };
}
