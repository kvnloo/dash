/**
 * Glyph geometry: AODL silhouettes scaled into a box, members mapped onto
 * silhouette nodes, and the expanded member layout the glyph decomposes into.
 */
import { silhouette, SILHOUETTE_H, SILHOUETTE_W, type Silhouette, type TopologyId } from '../aodl/encodings';

export interface Pt {
  x: number;
  y: number;
  r: number;
}

export function glyphFrame(topologyId: TopologyId, w: number, h: number, pad = 0) {
  const sil = silhouette(topologyId);
  const s = Math.min((w - 2 * pad) / SILHOUETTE_W, (h - 2 * pad) / SILHOUETTE_H);
  const ox = (w - SILHOUETTE_W * s) / 2;
  const oy = (h - SILHOUETTE_H * s) / 2;
  const points: Pt[] = sil.nodes.map(([x, y, r]) => ({ x: ox + x * s, y: oy + y * s, r: r * s }));
  const map = (x: number, y: number) => ({ x: ox + x * s, y: oy + y * s });
  return { sil, points, scale: s, map };
}

/** Parent -> children in the silhouette, reading edges as drawn (from -> to). */
export function silhouetteChildren(sil: Silhouette): Map<number, number[]> {
  const m = new Map<number, number[]>();
  for (const [a, b] of sil.edges) {
    if (!m.has(a)) m.set(a, []);
    m.get(a)!.push(b);
  }
  return m;
}

/**
 * Put members on silhouette nodes. Tree-shaped silhouettes (star, hierarchy)
 * follow the member delegation tree; others fill in index order. Members that
 * do not fit stay unmapped and emerge from their parent's node.
 */
export function assignMembers(
  topologyId: TopologyId,
  memberIds: string[],
  childrenOf: (id: string) => string[],
): Map<string, number> {
  const sil = silhouette(topologyId);
  const out = new Map<string, number>();
  if (!memberIds.length || !sil.nodes.length) return out;
  if (topologyId === 'star' || topologyId === 'hierarchy' || topologyId === 'solo') {
    const silKids = silhouetteChildren(sil);
    const used = new Set<number>();
    const walk = (member: string, idx: number) => {
      out.set(member, idx);
      used.add(idx);
      const free = (silKids.get(idx) || []).filter((k) => !used.has(k));
      childrenOf(member).forEach((c, i) => {
        if (i < free.length) walk(c, free[i]);
      });
    };
    walk(memberIds[0], 0);
    return out;
  }
  memberIds.slice(0, sil.nodes.length).forEach((id, i) => out.set(id, i));
  return out;
}

/**
 * The decomposed view: members as a tidy layered tree (depth rows), or a ring
 * around the hub when the tree is one level deep (star).
 */
export function memberLayout(
  rootId: string,
  childrenOf: (id: string) => string[],
  w: number,
  h: number,
  pad = 28,
): Map<string, { x: number; y: number; depth: number }> {
  const out = new Map<string, { x: number; y: number; depth: number }>();
  const depth = new Map<string, number>([[rootId, 0]]);
  const order = [rootId];
  for (let i = 0; i < order.length; i += 1) {
    for (const c of childrenOf(order[i])) {
      if (depth.has(c)) continue;
      depth.set(c, depth.get(order[i])! + 1);
      order.push(c);
    }
  }
  const maxDepth = Math.max(...depth.values());
  if (maxDepth <= 1) {
    const kids = order.slice(1);
    const cx = w / 2;
    const cy = h / 2;
    out.set(rootId, { x: cx, y: cy, depth: 0 });
    const rx = w / 2 - pad;
    const ry = h / 2 - pad * 0.8;
    // Many spokes: alternate two rings so neighbours do not touch.
    const staggered = kids.length > 12;
    kids.forEach((id, i) => {
      const a = -Math.PI / 2 + (i / Math.max(1, kids.length)) * Math.PI * 2;
      const k = staggered && i % 2 ? 0.7 : 1;
      out.set(id, { x: cx + Math.cos(a) * rx * k, y: cy + Math.sin(a) * ry * k, depth: 1 });
    });
    return out;
  }
  // Tidy tree: leaves get evenly spaced slots; parents sit over their children.
  let slot = 0;
  const slots = new Map<string, number>();
  const place = (id: string): number => {
    const kids = childrenOf(id).filter((c) => depth.get(c) === depth.get(id)! + 1);
    if (!kids.length) {
      slots.set(id, slot);
      slot += 1;
      return slots.get(id)!;
    }
    const xs = kids.map(place);
    const x = (Math.min(...xs) + Math.max(...xs)) / 2;
    slots.set(id, x);
    return x;
  };
  place(rootId);
  const span = Math.max(1, slot - 1);
  for (const id of order) {
    const d = depth.get(id)!;
    out.set(id, {
      x: slot === 1 ? w / 2 : pad + (slots.get(id)! / span) * (w - 2 * pad),
      y: pad + (d / maxDepth) * (h - 2 * pad),
      depth: d,
    });
  }
  return out;
}
