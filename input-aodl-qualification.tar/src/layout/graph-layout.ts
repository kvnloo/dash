/**
 * Graph view layouts, simplified from zerOS system-graph-layouts.js:
 *  spine   columns by role (hosts -> chats -> subagents -> repos); rows when narrow
 *  force   deterministic constellation (charge + springs, no Math.random)
 *  radial  rings by graph distance from the focused node
 *  islands role islands (zerOS "cluster" mode)
 * plus the focus projection: hot nodes stay individual up to a cap per role,
 * the quiet remainder folds into one aggregate node per role.
 */
import type { OrchestrationEdge, OrchestrationGraph, OrchestrationNode, NodeRole } from '../model/types';

export type LayoutMode = 'spine' | 'force' | 'radial' | 'islands';
export const LAYOUT_MODES: Array<{ id: LayoutMode; label: string }> = [
  { id: 'spine', label: 'Spine' },
  { id: 'force', label: 'Constellation' },
  { id: 'radial', label: 'Radial' },
  { id: 'islands', label: 'Islands' },
];

export const GRAPH_ROLES: NodeRole[] = ['host', 'chat', 'subagent', 'repo'];
export const ROLE_LABEL: Record<NodeRole, string> = { host: 'Hosts', chat: 'Chats', subagent: 'Subagents', repo: 'Repos', worktree: 'Worktrees' };

export interface ViewNode extends OrchestrationNode {
  /** Present on aggregate nodes: the folded members. */
  folded?: OrchestrationNode[];
}

export interface Projection {
  nodes: ViewNode[];
  edges: OrchestrationEdge[];
  hidden: number;
}

export const FOCUS_CAPS: Record<NodeRole, number> = { host: 4, chat: 8, subagent: 10, repo: 8, worktree: 0 };

/** 0..1: how much a node is happening right now. Drives size and flow. */
export function nodeEnergy(n: ViewNode): number {
  if (n.folded) return 0.1;
  let e = 0.12 + 0.5 * Math.min(1, n.weight);
  if (n.state === 'running') e += 0.3;
  if (n.phase === 'waiting-approval') e += 0.15;
  return Math.min(1, e);
}

export function isHot(n: OrchestrationNode): boolean {
  return n.state === 'running' || n.weight >= 0.35;
}

export function projectGraph(
  graph: OrchestrationGraph,
  opts: { mode: 'focus' | 'all'; focusId?: string | null; caps?: Record<NodeRole, number> },
): Projection {
  const nodes = graph.nodes.filter((n) => GRAPH_ROLES.includes(n.role));
  const ids = new Set(nodes.map((n) => n.id));
  const edges = graph.edges.filter((e) => ids.has(e.from) && ids.has(e.to));
  if (opts.mode === 'all') return { nodes, edges, hidden: 0 };

  const caps = opts.caps || FOCUS_CAPS;
  // The focused node's neighbourhood is always kept.
  const pinned = new Set<string>();
  if (opts.focusId && ids.has(opts.focusId)) {
    pinned.add(opts.focusId);
    for (const e of edges) {
      if (e.from === opts.focusId) pinned.add(e.to);
      if (e.to === opts.focusId) pinned.add(e.from);
    }
  }
  const keep = new Set<string>();
  const out: ViewNode[] = [];
  for (const role of GRAPH_ROLES) {
    const list = nodes.filter((n) => n.role === role).sort((a, b) =>
      Number(pinned.has(b.id)) - Number(pinned.has(a.id))
      || Number(isHot(b)) - Number(isHot(a))
      || nodeEnergy(b) - nodeEnergy(a)
      || (b.lastActivity || 0) - (a.lastActivity || 0)
      || a.label.localeCompare(b.label));
    // The focus neighbourhood may stretch a role's cap, but only a little.
    const cap = Math.max(caps[role], Math.min(list.filter((n) => pinned.has(n.id)).length, caps[role] + 4));
    const kept = list.slice(0, cap);
    kept.forEach((n) => keep.add(n.id));
    out.push(...kept);
    const rest = list.slice(cap);
    if (rest.length) {
      out.push({
        id: `quiet:${role}`,
        kind: rest[0].kind,
        role,
        label: `${rest.length} quiet`,
        providerId: 'unknown',
        modelId: 'unknown',
        operatingModeId: 'unknown',
        state: 'paused',
        weight: 0,
        folded: rest,
      });
    }
  }
  // Edges into folded nodes re-point at the aggregate, deduplicated.
  const where = new Map<string, string>();
  for (const n of out) {
    if (n.folded) n.folded.forEach((m) => where.set(m.id, n.id));
    else where.set(n.id, n.id);
  }
  const seen = new Map<string, OrchestrationEdge>();
  for (const e of edges) {
    const from = where.get(e.from);
    const to = where.get(e.to);
    if (!from || !to || from === to) continue;
    const both = keep.has(e.from) && keep.has(e.to);
    // Quiet aggregates carry a count, not wiring: their edges would only be soup.
    if (!both) continue;
    const id = e.id;
    const prev = seen.get(id);
    if (prev) prev.weight += e.weight;
    else seen.set(id, { ...e, id, from, to, weight: e.weight });
  }
  return { nodes: out, edges: [...seen.values()], hidden: nodes.length - keep.size };
}

/**
 * Keep the strongest artifact edges only: each agent keeps its top `perAgent`
 * repos, and edges under `minShare` of the strongest edge drop. Delegation and
 * structural edges are always kept: they are the coordination itself.
 */
export function thinEdges<E extends OrchestrationEdge>(edges: E[], opts: { perAgent?: number; minShare?: number } = {}): E[] {
  const perAgent = opts.perAgent ?? 2;
  const minShare = opts.minShare ?? 0.04;
  const art = edges.filter((e) => e.relation === 'artifact');
  const top = Math.max(0, ...art.map((e) => e.weight));
  const byAgent = new Map<string, E[]>();
  for (const e of art) {
    if (e.weight < top * minShare) continue;
    if (!byAgent.has(e.from)) byAgent.set(e.from, []);
    byAgent.get(e.from)!.push(e);
  }
  const keep = new Set<string>();
  for (const list of byAgent.values()) list.sort((a, b) => b.weight - a.weight).slice(0, perAgent).forEach((e) => keep.add(e.id));
  return edges.filter((e) => e.relation !== 'artifact' || keep.has(e.id));
}

export interface Placed {
  x: number;
  y: number;
  r: number;
}

export function nodeRadius(n: ViewNode, scale = 1, repoMax = 1): number {
  if (n.folded) return (9 + Math.min(7, Math.log2(n.folded.length + 1) * 2)) * scale;
  const e = nodeEnergy(n);
  if (n.role === 'host') return 9 * scale;
  if (n.role === 'repo') return (4.5 + 8 * Math.sqrt(Math.min(1, n.weight / Math.max(repoMax, 1e-6)))) * scale;
  if (n.role === 'chat') return (6 + 4 * e) * scale;
  return (4 + 3 * e) * scale;
}

const clamp = (v: number, lo: number, hi: number) => Math.max(lo, Math.min(hi, v));

export function layoutGraph(
  proj: Projection,
  width: number,
  height: number,
  mode: LayoutMode,
  focusId?: string | null,
): Map<string, Placed> {
  const scale = width < 480 ? 0.85 : 1;
  const repoMax = Math.max(1e-6, ...proj.nodes.filter((n) => n.role === 'repo' && !n.folded).map((n) => n.weight));
  const radius = (n: ViewNode) => nodeRadius(n, scale, repoMax);
  const pos = new Map<string, Placed>();
  const pad = 22;
  const roles = GRAPH_ROLES.filter((r) => proj.nodes.some((n) => n.role === r));
  const ordered = (role: NodeRole) => proj.nodes.filter((n) => n.role === role);

  if (mode === 'spine') {
    const columns = width >= 560;
    roles.forEach((role, ri) => {
      const list = ordered(role);
      list.forEach((n, i) => {
        const t = list.length === 1 ? 0.5 : i / (list.length - 1);
        const band = (ri + 0.5) / roles.length;
        const row = roles.length === 1 ? 0.5 : ri / (roles.length - 1);
        const x = columns ? pad + band * (width - 2 * pad) : pad + t * (width - 2 * pad);
        const y = columns ? pad + 14 + t * (height - 2 * pad - 14) : pad + 10 + row * (height - 2 * pad - 34);
        pos.set(n.id, { x, y, r: radius(n) });
      });
    });
    return pos;
  }

  if (mode === 'islands') {
    // One island per role, laid on a grid; members on a sunflower spiral.
    const cols = width >= 560 ? roles.length : 2;
    const rows = Math.ceil(roles.length / cols);
    roles.forEach((role, ri) => {
      const cx = ((ri % cols) + 0.5) * (width / cols);
      const cy = (Math.floor(ri / cols) + 0.5) * (height / rows) + 6;
      const list = ordered(role);
      const maxR = Math.min(width / cols, height / rows) / 2 - 16;
      list.forEach((n, i) => {
        const a = i * 2.39996; // golden angle
        const d = list.length === 1 ? 0 : maxR * Math.sqrt((i + 0.5) / list.length);
        pos.set(n.id, { x: cx + Math.cos(a) * d, y: cy + Math.sin(a) * d, r: radius(n) });
      });
    });
    return pos;
  }

  const cx = width / 2;
  const cy = height / 2;
  if (mode === 'radial') {
    const center = proj.nodes.find((n) => n.id === focusId)
      || [...proj.nodes].sort((a, b) => nodeEnergy(b) - nodeEnergy(a))[0];
    if (!center) return pos;
    const adj = new Map<string, Set<string>>(proj.nodes.map((n) => [n.id, new Set()]));
    for (const e of proj.edges) {
      adj.get(e.from)?.add(e.to);
      adj.get(e.to)?.add(e.from);
    }
    const dist = new Map([[center.id, 0]]);
    const q = [center.id];
    while (q.length) {
      const id = q.shift()!;
      for (const nb of adj.get(id) || []) {
        if (dist.has(nb)) continue;
        dist.set(nb, dist.get(id)! + 1);
        q.push(nb);
      }
    }
    const maxD = Math.max(1, ...dist.values());
    const rings = new Map<number, ViewNode[]>();
    for (const n of proj.nodes) {
      const d = dist.has(n.id) ? dist.get(n.id)! : maxD + 1;
      if (!rings.has(d)) rings.set(d, []);
      rings.get(d)!.push(n);
    }
    const ringCount = Math.max(...rings.keys());
    const rx = width / 2 - pad;
    const ry = height / 2 - pad;
    for (const [d, list] of rings) {
      list.forEach((n, i) => {
        const a = (i / list.length) * Math.PI * 2 - Math.PI / 2 + d * 0.4;
        const k = d === 0 ? 0 : d / ringCount;
        pos.set(n.id, { x: cx + Math.cos(a) * rx * k, y: cy + Math.sin(a) * ry * k, r: radius(n) });
      });
    }
    return pos;
  }

  // force
  const N = proj.nodes.length;
  const roleAngle = new Map(roles.map((r, i) => [r, (i / roles.length) * Math.PI * 2]));
  const P = proj.nodes.map((n, i) => {
    const a = (roleAngle.get(n.role) || 0) + (i % 7) * 0.17;
    const d = 40 + (i % 5) * 16;
    return { id: n.id, x: cx + Math.cos(a) * d, y: cy + Math.sin(a) * d, vx: 0, vy: 0, r: radius(n), role: n.role };
  });
  const index = new Map(P.map((p, i) => [p.id, i]));
  const springs = proj.edges.map((e) => [index.get(e.from)!, index.get(e.to)!]).filter(([a, b]) => a !== undefined && b !== undefined);
  const iters = Math.min(220, 60 + N * 3);
  const charge = Math.min(1800, (width * height) / Math.max(8, N) * 0.9);
  for (let t = 0; t < iters; t += 1) {
    const alpha = 0.6 * Math.exp(-t / (iters * 0.45));
    for (let i = 0; i < N; i += 1) {
      for (let j = i + 1; j < N; j += 1) {
        const a = P[i];
        const b = P[j];
        let dx = b.x - a.x;
        let dy = b.y - a.y;
        let d2 = dx * dx + dy * dy;
        if (d2 < 1) {
          dx = ((i * 17 + j * 31) % 7) - 3 || 1;
          dy = ((i * 13 + j * 23) % 7) - 3 || 1;
          d2 = dx * dx + dy * dy;
        }
        const d = Math.sqrt(d2);
        const f = (charge * alpha) / d2;
        a.vx -= (dx / d) * f;
        a.vy -= (dy / d) * f;
        b.vx += (dx / d) * f;
        b.vy += (dy / d) * f;
      }
    }
    for (const [ia, ib] of springs) {
      const a = P[ia];
      const b = P[ib];
      const dx = b.x - a.x;
      const dy = b.y - a.y;
      const d = Math.sqrt(dx * dx + dy * dy) || 1;
      const f = (d - 56) * 0.05 * alpha;
      a.vx += (dx / d) * f;
      a.vy += (dy / d) * f;
      b.vx -= (dx / d) * f;
      b.vy -= (dy / d) * f;
    }
    for (const p of P) {
      p.vx += (cx - p.x) * 0.02 * alpha;
      p.vy += (cy - p.y) * 0.02 * alpha;
      p.vx *= 0.78;
      p.vy *= 0.78;
      p.x = clamp(p.x + p.vx, pad, width - pad);
      p.y = clamp(p.y + p.vy, pad, height - pad);
    }
  }
  for (const p of P) pos.set(p.id, { x: p.x, y: p.y, r: p.r });
  return pos;
}

/** The zerOS edge curve: a gentle S bend proportional to distance. */
export function edgeCurve(a: { x: number; y: number }, b: { x: number; y: number }) {
  const dx = b.x - a.x;
  const dy = b.y - a.y;
  const dist = Math.hypot(dx, dy) || 1;
  const nx = -dy / dist;
  const ny = dx / dist;
  const bend = Math.min(28, dist * 0.12);
  return {
    p0: a,
    p1: { x: a.x + dx * 0.33 + nx * bend, y: a.y + dy * 0.33 + ny * bend },
    p2: { x: a.x + dx * 0.66 - nx * bend * 0.55, y: a.y + dy * 0.66 - ny * bend * 0.55 },
    p3: b,
  };
}

export function curvePath(c: ReturnType<typeof edgeCurve>): string {
  const f = (n: number) => n.toFixed(1);
  return `M${f(c.p0.x)} ${f(c.p0.y)}C${f(c.p1.x)} ${f(c.p1.y)} ${f(c.p2.x)} ${f(c.p2.y)} ${f(c.p3.x)} ${f(c.p3.y)}`;
}
