/**
 * AODL encodings as data. The JSON in /aodl is a pinned copy of kvnloo/aodl
 * (see aodl/SOURCE.json, refresh with `npm run sync:aodl`). Nothing here adds a
 * topology, provider, model, mode or state id: unknown input resolves to the
 * `unknown` entry that AODL itself defines.
 */
import visualJson from '../../aodl/visual.json';
import graphsJson from '../../aodl/topology-graphs.json';
import irMapJson from '../../aodl/ir-map.json';
import sourceJson from '../../aodl/SOURCE.json';

export const visual = visualJson;
export const irMap = irMapJson;
export const aodlSource = sourceJson as { repo: string; ref: string; sha: string; syncedAt: string };

export type TopologyId = keyof typeof visualJson.topologies;
export type ProviderId = keyof typeof visualJson.providers;
export type ModelId = keyof typeof visualJson.models;
export type EffortId = keyof typeof visualJson.efforts;
export type OperatingModeId = keyof typeof visualJson.operatingModes;
export type RuntimeStateId = keyof typeof visualJson.runtimeStates;

/** HOTL 0.2 node kinds (schema/hotl-0.2.schema.json $defs/node/kind). */
export const AODL_NODE_KINDS = [
  'task', 'executor', 'model', 'tool', 'service', 'memory', 'stateStore', 'humanGate', 'environment', 'artifact', 'verifier',
] as const;
export type AodlNodeKind = (typeof AODL_NODE_KINDS)[number];

/** HOTL 0.2 edge relations (schema/hotl-0.2.schema.json $defs/edge/relation). */
export const AODL_RELATIONS = [
  'dependency', 'data', 'message', 'delegation', 'critique', 'verification', 'allocation', 'control', 'observation', 'artifact',
] as const;
export type AodlRelation = (typeof AODL_RELATIONS)[number];

export const TOPOLOGY_IDS = Object.keys(visualJson.topologies) as TopologyId[];

const has = <T extends object>(obj: T, key: unknown): key is keyof T =>
  typeof key === 'string' && Object.prototype.hasOwnProperty.call(obj, key);

export const isTopologyId = (id: unknown): id is TopologyId => has(visualJson.topologies, id);
export const isProviderId = (id: unknown): id is ProviderId => has(visualJson.providers, id);
export const isModelId = (id: unknown): id is ModelId => has(visualJson.models, id);
export const isOperatingModeId = (id: unknown): id is OperatingModeId => has(visualJson.operatingModes, id);
export const isRuntimeStateId = (id: unknown): id is RuntimeStateId => has(visualJson.runtimeStates, id);

export const topologyOf = (id: TopologyId) => visualJson.topologies[id];
export const providerHue = (id: ProviderId) => visualJson.providers[id].hue;
export const runtimeStateOf = (id: RuntimeStateId) => visualJson.runtimeStates[id];
export const operatingModeOf = (id: OperatingModeId) => visualJson.operatingModes[id];

/** The ir-map status: only `expressible` topologies compile to HOTL. */
export type TopologyStatus = 'expressible' | 'not-inferred' | 'unspecified';
export function topologyStatus(id: TopologyId): TopologyStatus {
  const entry = (irMapJson.topologies as Record<string, { status: string }>)[id];
  return (entry?.status as TopologyStatus) || 'unspecified';
}

export interface Silhouette {
  /** [x, y, r] in the AODL 72x44 viewBox. A declared center (blackboard/marketplace) is appended last. */
  nodes: Array<[number, number, number]>;
  edges: Array<[number, number]>;
  directed: boolean;
  soft: boolean;
  envelope?: 'council' | 'supervisor' | 'marketplace' | 'cluster';
  center?: 'blackboard' | 'marketplace' | 'unknown';
  /** Index of the drawn center node when `center` is blackboard/marketplace. */
  centerIndex?: number;
}

export const SILHOUETTE_W = 72;
export const SILHOUETTE_H = 44;

type RawGraph = {
  nodes: number[][];
  edges: number[][];
  directed?: boolean;
  soft?: boolean;
  envelope?: string;
  center?: string;
};

/** Silhouette for a topology id, exactly as topology-graphs.json draws it. */
export function silhouette(id: TopologyId): Silhouette {
  const raw = ((graphsJson as Record<string, RawGraph>)[id] || (graphsJson as Record<string, RawGraph>).unknown) as RawGraph;
  const nodes = raw.nodes.map((n) => [n[0], n[1], n[2]] as [number, number, number]);
  let centerIndex: number | undefined;
  if (raw.center === 'blackboard' || raw.center === 'marketplace') {
    // AODL edges point at index nodes.length; the language draws it at the viewBox centre.
    centerIndex = nodes.length;
    nodes.push([36, 22, 5]);
  }
  return {
    nodes,
    edges: raw.edges.map((e) => [e[0], e[1]] as [number, number]),
    directed: Boolean(raw.directed),
    soft: Boolean(raw.soft),
    envelope: raw.envelope as Silhouette['envelope'],
    center: raw.center as Silhouette['center'],
    centerIndex,
  };
}

/** Provider hue per drawn node; `multi` cycles the same provider list the AODL language uses. */
const MULTI_PROVIDER_NODE_IDS: ProviderId[] = ['openai', 'anthropic', 'moonshot', 'xai', 'cursor', 'fable'];
export function silhouetteNodeHue(providerId: ProviderId, index: number): string {
  if (providerId !== 'multi') return providerHue(providerId);
  return providerHue(MULTI_PROVIDER_NODE_IDS[index % MULTI_PROVIDER_NODE_IDS.length]);
}

/**
 * Resolve a raw model / agent string to AODL provider + model ids.
 * 1. AODL `ownerRules` (prefix match), exactly as published.
 * 2. An explicit `vendor/` prefix or a well-known family name, but only onto
 *    provider ids that AODL already defines. The model stays `unknown`.
 */
const FAMILY_PROVIDER: Array<[RegExp, ProviderId]> = [
  [/^(anthropic\/|claude)/, 'anthropic'],
  [/^(openai\/|gpt|o\d)/, 'openai'],
  [/^(xai\/|x-ai\/)/, 'xai'],
  [/^(moonshot|moonshotai\/)/, 'moonshot'],
  [/^cursor/, 'cursor'],
  [/^fable/, 'fable'],
];

export function resolveModel(raw: string | null | undefined): { providerId: ProviderId; modelId: ModelId } {
  const value = String(raw || '').trim().toLowerCase();
  if (!value) return { providerId: 'unknown', modelId: 'unknown' };
  const bare = value.includes('/') ? value.slice(value.indexOf('/') + 1) : value;
  for (const rule of visualJson.ownerRules) {
    if (bare.startsWith(rule.prefix) || value.startsWith(rule.prefix)) {
      return {
        providerId: isProviderId(rule.provider) ? rule.provider : 'unknown',
        modelId: isModelId(rule.model) ? rule.model : 'unknown',
      };
    }
  }
  if (/haiku/.test(bare)) return { providerId: 'anthropic', modelId: 'claude-haiku' };
  for (const [re, providerId] of FAMILY_PROVIDER) {
    if (re.test(value)) return { providerId, modelId: 'unknown' };
  }
  return { providerId: 'unknown', modelId: 'unknown' };
}
