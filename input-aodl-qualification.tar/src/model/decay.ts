/**
 * Time-decay weighting. A touch of size `count` at time `t` weighs
 * count * 0.5^((at - t) / halfLife) at time `at`. Touches after `at` do not
 * exist yet, so scrubbing `at` backwards replays how attention moved.
 */
export type Touch = readonly [epochSeconds: number, count: number];

export function decayFactor(ageSeconds: number, halfLifeHours: number): number {
  if (!(halfLifeHours > 0)) return ageSeconds <= 0 ? 1 : 0;
  return 0.5 ** (Math.max(0, ageSeconds) / (halfLifeHours * 3600));
}

export function weightAt(touches: readonly Touch[], at: number, halfLifeHours: number): number {
  let sum = 0;
  for (const [t, count] of touches) {
    if (t > at) continue;
    sum += count * decayFactor(at - t, halfLifeHours);
  }
  return sum;
}

/** Relative age label used across the views: 42s, 7m, 3h, 2d. */
export function ago(epochSeconds: number | undefined, now: number): string {
  if (!epochSeconds) return '—';
  const s = Math.max(0, now - epochSeconds);
  if (s < 90) return `${Math.round(s)}s`;
  if (s < 5400) return `${Math.round(s / 60)}m`;
  if (s < 172800) return `${Math.round(s / 3600)}h`;
  return `${Math.round(s / 86400)}d`;
}
