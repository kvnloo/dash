import type {
  AodlNodeKind,
  AodlRelation,
  ModelId,
  OperatingModeId,
  ProviderId,
  RuntimeStateId,
  TopologyId,
} from '../aodl/encodings';

/**
 * One observed orchestration graph, aligned with AODL's O_t = (V, E, S, ...).
 * `kind` and `relation` are HOTL 0.2 enums. `role` is a display role only: it
 * picks the row/shape a view uses and never compiles to HOTL.
 */
export type NodeRole = 'host' | 'chat' | 'subagent' | 'repo' | 'worktree';

/** What an agent is doing right now, for AgentThinking. Not an AODL channel. */
export type ThinkingPhase = 'idle' | 'thinking' | 'tool' | 'streaming' | 'waiting-approval';

export type WorktreeTier = 'trunk' | 'integration' | 'feature' | 'leaf';

export interface OrchestrationNode {
  id: string;
  kind: AodlNodeKind;
  role: NodeRole;
  label: string;
  /** Visual channels (AODL visual.json ids). */
  providerId: ProviderId;
  modelId: ModelId;
  operatingModeId: OperatingModeId;
  /** Runtime cadence (AODL runtimeStates). */
  state: RuntimeStateId;
  harnessId?: string;
  phase?: ThinkingPhase;
  /** Tool name for phase === 'tool', when the source reports one. */
  tool?: string;
  parentId?: string;
  hostId?: string;
  repoId?: string;
  /** Epoch seconds. */
  lastActivity?: number;
  /** Time-decayed activity weight at graph.generatedAt (repos: summed touch weight). */
  weight: number;
  meta?: {
    profile?: string;
    source?: string;
    messages?: number;
    tools?: number;
    model?: string;
    branch?: string;
    head?: string;
    path?: string;
    tier?: WorktreeTier;
    primary?: boolean;
  };
}

export interface OrchestrationEdge {
  id: string;
  from: string;
  to: string;
  relation: AodlRelation;
  /** Time-decayed weight at graph.generatedAt. */
  weight: number;
  /** Epoch seconds of the newest observation behind this edge. */
  touchedAt?: number;
  /** Raw touch history ([epochSeconds, count]) so views can re-weigh at any time / half-life. */
  touches?: Array<readonly [number, number]>;
}

/** A coordination class that was declared, never drawn into existence. */
export interface DeclaredCoordination {
  topologyId?: string;
  policyKinds?: string[];
}

export interface OrchestrationGraph {
  source: 'live-snapshot' | 'dash-roster' | 'z0bridge';
  /** Epoch seconds. */
  generatedAt: number;
  halfLifeHours: number;
  nodes: OrchestrationNode[];
  edges: OrchestrationEdge[];
  declared?: DeclaredCoordination;
}

export interface CompressedTopology {
  topologyId: TopologyId;
  /** Which AODL rule produced the id. */
  rule: 'declared-topology' | 'declared-policy' | 'single-executor' | 'delegation-fanout' | 'delegation-tree' | 'none';
  /** Members in glyph order: hub/root first, then breadth-first. */
  memberIds: string[];
}
