/**
 * Adapters for the two bridge shapes Dash already speaks:
 *  - Dash bridge roster: `HostInfo[]` (kvnloo/dash shared/protocol.ts)
 *  - z0bridge sessions API: `{ sessions: SessionSummary[] }` (kvnloo/z0bridge src/types.ts)
 * Both are observed V only (AODL: "A Dash /roster is observed V, not O_t"), so
 * they produce nodes and no invented edges.
 */
import { resolveModel } from '../aodl/encodings';
import { decayFactor } from './decay';
import type { OrchestrationGraph, OrchestrationNode } from './types';

/** Mirrors kvnloo/dash shared/protocol.ts AgentInfo. */
export interface DashAgentInfo {
  id: string;
  name: string;
  kind: string;
  status: 'running' | 'available' | 'offline';
  detail?: string;
  cwd?: string;
  sessionId?: string;
  hostId?: string;
  profileId?: string;
}

/** Mirrors kvnloo/dash shared/protocol.ts HostInfo. */
export interface DashHostInfo {
  id: string;
  name: string;
  hostname: string;
  online: boolean;
  self: boolean;
  address?: string;
  agents: DashAgentInfo[];
}

/** Mirrors kvnloo/z0bridge src/types.ts SessionSummary (times in ms). */
export interface Z0SessionSummary {
  harness: string;
  profile: string;
  id: string;
  title: string;
  source: string;
  cwd?: string;
  startedAt: number;
  lastActivityAt: number;
  messageCount: number;
  ended: boolean;
}

const isObj = (v: unknown): v is Record<string, unknown> => typeof v === 'object' && v !== null;

export function fromDashRoster(raw: unknown, now = Date.now() / 1000): OrchestrationGraph {
  const hosts = Array.isArray(raw) ? raw : isObj(raw) && Array.isArray(raw.hosts) ? raw.hosts : [];
  const nodes: OrchestrationNode[] = [];
  for (const h of hosts as unknown[]) {
    if (!isObj(h) || typeof h.id !== 'string') continue;
    const host = h as unknown as DashHostInfo;
    const hostId = `host:${host.id}`;
    nodes.push({
      id: hostId,
      kind: 'environment',
      role: 'host',
      label: host.name || host.hostname || host.id,
      providerId: 'unknown',
      modelId: 'unknown',
      operatingModeId: 'unknown',
      state: host.online ? 'running' : 'stale',
      weight: host.online ? 1 : 0,
    });
    for (const a of Array.isArray(host.agents) ? host.agents : []) {
      if (!isObj(a) || typeof a.id !== 'string') continue;
      const { providerId, modelId } = resolveModel(a.kind);
      nodes.push({
        id: `chat:${host.id}:${a.id}`,
        kind: 'executor',
        role: 'chat',
        label: a.name || a.id,
        providerId,
        modelId,
        operatingModeId: 'unknown',
        state: a.status === 'running' ? 'running' : a.status === 'offline' ? 'stale' : 'paused',
        harnessId: a.kind,
        phase: a.status === 'running' ? 'thinking' : 'idle',
        hostId,
        weight: a.status === 'running' ? 1 : 0.2,
        meta: { profile: a.profileId, path: a.cwd },
      });
    }
  }
  return { source: 'dash-roster', generatedAt: now, halfLifeHours: 2, nodes, edges: [] };
}

export function fromZ0BridgeSessions(raw: unknown, opts: { hostId?: string; now?: number; halfLifeHours?: number } = {}): OrchestrationGraph {
  const now = opts.now ?? Date.now() / 1000;
  const halfLife = opts.halfLifeHours ?? 2;
  const sessions = isObj(raw) && Array.isArray(raw.sessions) ? raw.sessions : Array.isArray(raw) ? raw : [];
  const hostId = `host:${opts.hostId || 'z0bridge'}`;
  const nodes: OrchestrationNode[] = [
    { id: hostId, kind: 'environment', role: 'host', label: opts.hostId || 'z0bridge', providerId: 'unknown', modelId: 'unknown', operatingModeId: 'unknown', state: 'running', weight: 1 },
  ];
  for (const s of sessions as unknown[]) {
    if (!isObj(s) || typeof s.id !== 'string') continue;
    const sess = s as unknown as Z0SessionSummary;
    const last = (Number(sess.lastActivityAt) || 0) / 1000;
    const quiet = now - last > 15 * 60;
    nodes.push({
      id: `chat:${sess.harness}:${sess.id}`,
      kind: 'executor',
      role: 'chat',
      label: sess.title || '(untitled)',
      ...resolveModel(sess.harness === 'hermes' ? '' : sess.harness),
      operatingModeId: 'unknown',
      state: sess.ended ? 'paused' : quiet ? 'stale' : 'running',
      harnessId: sess.harness,
      phase: !sess.ended && !quiet ? 'thinking' : 'idle',
      hostId,
      lastActivity: last || undefined,
      weight: decayFactor(now - last, halfLife),
      meta: { profile: sess.profile, source: sess.source, messages: Number(sess.messageCount) || 0, path: sess.cwd },
    });
  }
  return { source: 'z0bridge', generatedAt: now, halfLifeHours: halfLife, nodes, edges: [] };
}
