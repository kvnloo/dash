/**
 * Tree projections of an OrchestrationGraph:
 *  - sessions: host -> chat -> subagents (nested by delegation)
 *  - worktrees: repo -> trunk -> integration -> feature packs -> leaves
 */
import { compressGraph } from './compress';
import { packKey, TIER_LABEL, TIER_ORDER } from './worktrees';
import type { CompressedTopology, OrchestrationGraph, OrchestrationNode, WorktreeTier } from './types';

export interface TreeItem {
  id: string;
  label: string;
  type: 'host' | 'chat' | 'subagent' | 'repo' | 'tier' | 'pack' | 'worktree';
  node?: OrchestrationNode;
  /** Glyph for chats: their delegation subtree compressed through AODL rules. */
  topology?: CompressedTopology;
  /** Count of descendants of the leaf type (sessions or worktrees). */
  count: number;
  /** Live descendants (running), for the collapsed summary. */
  live: number;
  tier?: WorktreeTier;
  children: TreeItem[];
}

const byRecent = (a: OrchestrationNode, b: OrchestrationNode) => (b.lastActivity || 0) - (a.lastActivity || 0);

export function sessionTree(graph: OrchestrationGraph): TreeItem[] {
  const agents = graph.nodes.filter((n) => n.role === 'chat' || n.role === 'subagent');
  const kids = new Map<string, OrchestrationNode[]>();
  for (const n of agents) {
    if (!n.parentId) continue;
    if (!kids.has(n.parentId)) kids.set(n.parentId, []);
    kids.get(n.parentId)!.push(n);
  }
  const build = (n: OrchestrationNode, depth: number): TreeItem => {
    const children = depth < 8 ? (kids.get(n.id) || []).sort(byRecent).map((c) => build(c, depth + 1)) : [];
    return {
      id: n.id,
      label: n.label,
      type: n.role === 'chat' ? 'chat' : 'subagent',
      node: n,
      topology: n.role === 'chat' ? compressGraph(graph, n.id) : undefined,
      count: children.reduce((s, c) => s + 1 + c.count, 0),
      live: children.reduce((s, c) => s + (c.node?.state === 'running' ? 1 : 0) + c.live, 0),
      children,
    };
  };
  return graph.nodes
    .filter((n) => n.role === 'host')
    .map((host) => {
      const roots = agents.filter((n) => n.hostId === host.id && (n.role === 'chat' || !n.parentId)).sort(byRecent);
      const children = roots.map((r) => build(r, 0));
      return {
        id: host.id,
        label: host.label,
        type: 'host' as const,
        node: host,
        count: children.reduce((s, c) => s + 1 + c.count, 0),
        live: children.reduce((s, c) => s + (c.node?.state === 'running' ? 1 : 0) + c.live, 0),
        children,
      };
    });
}

export function worktreeTree(graph: OrchestrationGraph): TreeItem[] {
  const repos = new Map(graph.nodes.filter((n) => n.role === 'repo').map((n) => [n.id, n]));
  const byRepo = new Map<string, OrchestrationNode[]>();
  for (const w of graph.nodes) {
    if (w.role !== 'worktree' || !w.repoId) continue;
    if (!byRepo.has(w.repoId)) byRepo.set(w.repoId, []);
    byRepo.get(w.repoId)!.push(w);
  }
  const leaf = (w: OrchestrationNode): TreeItem => ({
    id: w.id,
    label: w.meta?.branch || w.label,
    type: 'worktree',
    node: w,
    tier: w.meta?.tier,
    count: 0,
    live: 0,
    children: [],
  });
  const items: TreeItem[] = [];
  for (const [repoId, wts] of byRepo) {
    const repo = repos.get(repoId);
    const tiers: TreeItem[] = [];
    for (const tier of TIER_ORDER) {
      const inTier = wts.filter((w) => (w.meta?.tier || 'feature') === tier)
        .sort((a, b) => String(a.meta?.branch || a.label).localeCompare(String(b.meta?.branch || b.label)));
      if (!inTier.length) continue;
      let children: TreeItem[];
      if (tier === 'feature' || tier === 'leaf') {
        // Feature packs: congruent branches fold into one pack; singletons stay leaves.
        const packs = new Map<string, OrchestrationNode[]>();
        const singles: OrchestrationNode[] = [];
        for (const w of inTier) {
          const key = packKey(w.meta?.branch);
          if (key) {
            if (!packs.has(key)) packs.set(key, []);
            packs.get(key)!.push(w);
          } else singles.push(w);
        }
        children = [];
        for (const [key, members] of packs) {
          if (members.length < 2 && key !== 'detached') {
            singles.push(...members);
            continue;
          }
          children.push({ id: `${repoId}:pack:${key}`, label: key, type: 'pack', tier, count: members.length, live: 0, children: members.map(leaf) });
        }
        // Largest pack first; detached heads last.
        children.sort((a, b) => Number(a.label === 'detached') - Number(b.label === 'detached') || b.count - a.count);
        children.push(...singles.sort((a, b) => String(a.meta?.branch).localeCompare(String(b.meta?.branch))).map(leaf));
      } else {
        children = inTier.map(leaf);
      }
      tiers.push({ id: `${repoId}:tier:${tier}`, label: TIER_LABEL[tier], type: 'tier', tier, count: inTier.length, live: 0, children });
    }
    items.push({
      id: repoId,
      label: repo?.meta?.path || repoId.slice(5),
      type: 'repo',
      node: repo,
      count: wts.length,
      live: 0,
      children: tiers,
    });
  }
  return items.sort((a, b) => b.count - a.count);
}
