/**
 * Adapter: live snapshot JSON (scripts/live-snapshot.py) -> OrchestrationGraph.
 *
 * Accepts schema 1 (the zerOS gallery prototype: per-session pre-decayed repo
 * weights) and schema 2 (adds host, ended and raw repo touch buckets). Input is
 * `unknown` at the boundary; anything malformed is dropped, never guessed.
 */
import { isOperatingModeId, resolveModel, type OperatingModeId } from '../aodl/encodings';
import { decayFactor, weightAt, type Touch } from './decay';
import { classifyWorktreeTier } from './worktrees';
import type { OrchestrationEdge, OrchestrationGraph, OrchestrationNode, ThinkingPhase } from './types';

export interface LiveSession {
  id: string;
  profile?: string;
  source?: string;
  title?: string;
  model?: string | null;
  parent?: string | null;
  messages?: number;
  tools?: number;
  lastActivity?: number;
  live?: boolean;
  ended?: boolean;
  activity?: string;
  /** schema 1: repo -> decayed weight. */
  repos?: Record<string, number>;
  /** schema 2: repo -> [[bucketStartEpoch, count], ...]. */
  repoTouches?: Record<string, Array<[number, number]>>;
}

export interface LiveWorktree {
  path: string;
  head?: string;
  branch?: string;
  repo?: string | null;
  name?: string;
  isPrimary?: boolean;
}

export interface LiveSnapshot {
  schemaVersion?: number;
  generatedAt: number;
  windowHours?: number;
  halfLifeHours?: number;
  host?: string;
  chats: LiveSession[];
  subagents: LiveSession[];
  repos?: Array<{ repo: string; weight: number; lastTouched?: number }>;
  worktrees?: LiveWorktree[];
}

export interface LiveSnapshotOptions {
  /** Session sources to leave out. Default: one-shot CLI calls. */
  excludeSources?: string[];
  /** Keep at most this many top-level chats (most recent first). */
  maxChats?: number;
}

/** Sources where a person is in the loop turn by turn: AODL `copilot` (live paired work). */
const COPILOT_SOURCES = new Set(['cli', 'local', 'tui', 'telegram', 'acp', 'desktop', 'discord', 'slack']);
/** Scheduled bounded runs: AODL `batch`. */
const BATCH_SOURCES = new Set(['cron']);

const QUIET_SECONDS = 15 * 60;

export function operatingModeForSource(source: string | undefined): OperatingModeId {
  const s = String(source || '');
  if (COPILOT_SOURCES.has(s)) return 'copilot';
  if (BATCH_SOURCES.has(s)) return 'batch';
  return isOperatingModeId(s) ? s : 'unknown';
}

/** Hermes `last_activity_description` -> thinking phase + tool. Never returns prompt text. */
export function phaseFromActivity(activity: string | undefined, live: boolean): { phase: ThinkingPhase; tool?: string } {
  if (!live) return { phase: 'idle' };
  const a = String(activity || '').toLowerCase();
  const tool = /tool (?:running|completed): ([\w.-]+)/.exec(a)?.[1]
    || /sequential tool running \([^)]*\): ([\w.-]+)/.exec(a)?.[1]
    || /subagent running ([\w.-]+)/.exec(a)?.[1]
    || (/terminal command running/.test(a) ? 'terminal' : undefined);
  if (/clarify|approval|approve|permission|waiting for (?:user|human|owner)/.test(a)) {
    return { phase: 'waiting-approval', tool };
  }
  if (tool) return { phase: 'tool', tool };
  if (/stream|respond|receiving/.test(a)) return { phase: 'streaming' };
  return { phase: 'thinking' };
}

const num = (v: unknown, fallback = 0) => (typeof v === 'number' && Number.isFinite(v) ? v : fallback);
const str = (v: unknown) => (typeof v === 'string' ? v : undefined);

function isSession(v: unknown): v is LiveSession {
  return typeof v === 'object' && v !== null && typeof (v as LiveSession).id === 'string';
}

export function parseLiveSnapshot(raw: unknown): LiveSnapshot | null {
  if (typeof raw !== 'object' || raw === null) return null;
  const r = raw as Record<string, unknown>;
  const generatedAt = num(r.generatedAt, NaN);
  if (!Number.isFinite(generatedAt)) return null;
  const list = (v: unknown) => (Array.isArray(v) ? v.filter(isSession) : []);
  return {
    schemaVersion: num(r.schemaVersion, 1),
    generatedAt,
    windowHours: num(r.windowHours, 24),
    halfLifeHours: num(r.halfLifeHours, 2),
    host: str(r.host),
    chats: list(r.chats),
    subagents: list(r.subagents),
    repos: Array.isArray(r.repos) ? (r.repos as LiveSnapshot['repos']) : [],
    worktrees: Array.isArray(r.worktrees)
      ? (r.worktrees as unknown[]).filter((w): w is LiveWorktree => typeof (w as LiveWorktree)?.path === 'string')
      : [],
  };
}

/** Touch history for one session -> repo pair, with a schema-1 fallback. */
function touchesFor(s: LiveSession, repo: string, snap: LiveSnapshot): Touch[] {
  const raw = s.repoTouches?.[repo];
  if (Array.isArray(raw) && raw.length) {
    return raw.filter((t) => Array.isArray(t) && t.length === 2).map((t) => [num(t[0]), num(t[1])] as const);
  }
  // Schema 1 only kept the decayed sum: treat it as one touch at generation time.
  const w = num(s.repos?.[repo]);
  return w > 0 ? [[snap.generatedAt, w] as const] : [];
}

export function fromLiveSnapshot(input: unknown, options: LiveSnapshotOptions = {}): OrchestrationGraph {
  const snap = parseLiveSnapshot(input);
  if (!snap) return { source: 'live-snapshot', generatedAt: 0, halfLifeHours: 2, nodes: [], edges: [] };
  const exclude = new Set(options.excludeSources ?? ['oneshot']);
  const halfLife = snap.halfLifeHours ?? 2;
  const hostId = `host:${snap.host || 'this-host'}`;
  const nodes: OrchestrationNode[] = [];
  const edges: OrchestrationEdge[] = [];
  const seen = new Set<string>();

  nodes.push({
    id: hostId,
    kind: 'environment',
    role: 'host',
    label: snap.host || 'this host',
    providerId: 'unknown',
    modelId: 'unknown',
    operatingModeId: 'unknown',
    state: 'running',
    weight: 1,
  });

  const chats = snap.chats
    .filter((c) => !exclude.has(String(c.source)))
    .sort((a, b) => num(b.lastActivity) - num(a.lastActivity))
    .slice(0, options.maxChats ?? Infinity);
  const chatIds = new Set(chats.map((c) => c.id));
  const allChatIds = new Set(snap.chats.map((c) => c.id));
  const subById = new Map(snap.subagents.map((s) => [s.id, s]));
  // Kept when the parent chain reaches a kept chat. A parent that is not in the
  // snapshot at all makes an orphan (shown under the host); an excluded chat drops it.
  const rootOf = (s: LiveSession, depth = 0): string | null => {
    const p = s.parent || '';
    if (chatIds.has(p)) return p;
    if (allChatIds.has(p)) return null;
    const up = subById.get(p);
    if (up) return depth < 16 ? rootOf(up, depth + 1) : null;
    return 'orphan';
  };
  const subagents = snap.subagents.filter((s) => {
    const root = rootOf(s);
    return root !== null && (root !== 'orphan' || !exclude.has(String(s.source)));
  });

  const repoTouched = new Map<string, number>();
  const addSession = (s: LiveSession, role: 'chat' | 'subagent') => {
    const id = `${role}:${s.id}`;
    if (seen.has(id)) return;
    seen.add(id);
    const last = num(s.lastActivity);
    const live = Boolean(s.live);
    const quiet = snap.generatedAt - last > QUIET_SECONDS;
    const { providerId, modelId } = resolveModel(s.model);
    const { phase, tool } = phaseFromActivity(s.activity, live);
    const parentIsChat = s.parent && chatIds.has(s.parent);
    const parentId = role === 'subagent' && s.parent
      ? (parentIsChat ? `chat:${s.parent}` : subById.has(s.parent) ? `subagent:${s.parent}` : undefined)
      : undefined;
    nodes.push({
      id,
      kind: 'executor',
      role,
      label: (s.title || '(untitled)').replace(/^Subagent:\s*/, ''),
      providerId,
      modelId,
      operatingModeId: role === 'chat' ? operatingModeForSource(s.source) : 'unknown',
      state: live ? 'running' : s.ended === false && quiet ? 'stale' : 'paused',
      harnessId: 'hermes',
      phase,
      tool,
      parentId,
      hostId,
      lastActivity: last || undefined,
      weight: decayFactor(snap.generatedAt - last, halfLife),
      meta: { profile: s.profile, source: s.source, messages: num(s.messages), tools: num(s.tools), model: s.model || undefined },
    });
    if (parentId) {
      edges.push({ id: `delegation:${parentId}->${id}`, from: parentId, to: id, relation: 'delegation', weight: 1, touchedAt: last });
    }
    const repos = new Set([...Object.keys(s.repos || {}), ...Object.keys(s.repoTouches || {})]);
    for (const repo of repos) {
      const touches = touchesFor(s, repo, snap);
      if (!touches.length) continue;
      const repoId = `repo:${repo}`;
      const touchedAt = Math.max(...touches.map((t) => t[0]));
      repoTouched.set(repoId, Math.max(repoTouched.get(repoId) || 0, touchedAt));
      edges.push({
        id: `artifact:${id}->${repoId}`,
        from: id,
        to: repoId,
        relation: 'artifact',
        weight: weightAt(touches, snap.generatedAt, halfLife),
        touchedAt,
        touches,
      });
    }
  };
  chats.forEach((c) => addSession(c, 'chat'));
  subagents.forEach((s) => addSession(s, 'subagent'));

  // Repos: every repo an included session touched, plus repos with worktrees.
  const repoWeight = new Map<string, number>();
  for (const e of edges) if (e.relation === 'artifact') repoWeight.set(e.to, (repoWeight.get(e.to) || 0) + e.weight);
  for (const w of snap.worktrees || []) if (w.repo) repoWeight.set(`repo:${w.repo}`, repoWeight.get(`repo:${w.repo}`) || 0);
  for (const [repoId, weight] of repoWeight) {
    const full = repoId.slice(5);
    nodes.push({
      id: repoId,
      kind: 'artifact',
      role: 'repo',
      label: full.split('/').pop() || full,
      providerId: 'unknown',
      modelId: 'unknown',
      operatingModeId: 'unknown',
      state: weight > 0 ? 'running' : 'paused',
      lastActivity: repoTouched.get(repoId),
      weight,
      meta: { path: full },
    });
  }

  for (const w of snap.worktrees || []) {
    if (!w.repo) continue;
    const branch = w.branch || '';
    nodes.push({
      id: `worktree:${w.path}`,
      kind: 'environment',
      role: 'worktree',
      label: w.name || w.path.split('/').pop() || w.path,
      providerId: 'unknown',
      modelId: 'unknown',
      operatingModeId: 'unknown',
      state: 'unknown',
      repoId: `repo:${w.repo}`,
      hostId,
      weight: 0,
      meta: {
        branch: branch || undefined,
        head: w.head,
        path: w.path,
        primary: Boolean(w.isPrimary),
        tier: classifyWorktreeTier({ branch, name: w.name, primary: w.isPrimary }),
      },
    });
  }

  return { source: 'live-snapshot', generatedAt: snap.generatedAt, halfLifeHours: halfLife, nodes, edges };
}
