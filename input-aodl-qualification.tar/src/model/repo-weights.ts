/**
 * Repo weights with time decay. Each artifact edge keeps its raw touch history,
 * so a repo's weight can be recomputed for any moment (`at`) and any half-life:
 * short half-lives favour where work is now, long ones where work has been.
 */
import { compressGraph } from './compress';
import { weightAt } from './decay';
import type { CompressedTopology, OrchestrationGraph, OrchestrationNode } from './types';

export interface RepoAgentGroup {
  rootId: string;
  weight: number;
  /** The group's own delegation subgraph (root + touching members + their ancestors). */
  graph: OrchestrationGraph;
  topology: CompressedTopology;
}

export interface RepoWeight {
  repoId: string;
  label: string;
  path: string;
  weight: number;
  lastTouched?: number;
  agents: Array<{ node: OrchestrationNode; weight: number }>;
  groups: RepoAgentGroup[];
}

export function repoWeights(
  graph: OrchestrationGraph,
  opts: { at?: number; halfLifeHours?: number; scopeRootId?: string | null; minShare?: number } = {},
): RepoWeight[] {
  const at = opts.at ?? graph.generatedAt;
  const hl = opts.halfLifeHours ?? graph.halfLifeHours;
  const byId = new Map(graph.nodes.map((n) => [n.id, n]));
  const rootOf = (id: string): string => {
    let cur = byId.get(id);
    for (let i = 0; cur?.parentId && i < 16; i += 1) cur = byId.get(cur.parentId);
    return cur?.id || id;
  };
  const inScope = (agentId: string) => !opts.scopeRootId || rootOf(agentId) === opts.scopeRootId;

  const repos = new Map<string, { weight: number; last: number; agents: Map<string, number> }>();
  for (const e of graph.edges) {
    if (e.relation !== 'artifact' || !inScope(e.from)) continue;
    const touches = e.touches?.length ? e.touches : [[graph.generatedAt, e.weight] as const];
    const w = weightAt(touches, at, hl);
    const seen = touches.filter((t) => t[0] <= at).map((t) => t[0]);
    if (!seen.length) continue;
    const r = repos.get(e.to) || { weight: 0, last: 0, agents: new Map() };
    r.weight += w;
    r.last = Math.max(r.last, ...seen);
    r.agents.set(e.from, (r.agents.get(e.from) || 0) + w);
    repos.set(e.to, r);
  }

  const out: RepoWeight[] = [];
  for (const [repoId, r] of repos) {
    const repo = byId.get(repoId);
    const agents = [...r.agents.entries()]
      .map(([id, weight]) => ({ node: byId.get(id)!, weight }))
      .filter((a) => a.node)
      .sort((a, b) => b.weight - a.weight);
    // Active agents: a meaningful share of this repo's weight right now.
    const active = agents.filter((a) => a.weight >= (opts.minShare ?? 0.08) * r.weight);
    const groupsMap = new Map<string, Set<string>>();
    for (const a of active) {
      const root = rootOf(a.node.id);
      if (!groupsMap.has(root)) groupsMap.set(root, new Set([root]));
      // Keep the chain from the member up to the root so delegation stays connected.
      let cur: OrchestrationNode | undefined = a.node;
      for (let i = 0; cur && i < 16; i += 1) {
        groupsMap.get(root)!.add(cur.id);
        cur = cur.parentId ? byId.get(cur.parentId) : undefined;
      }
    }
    const groups: RepoAgentGroup[] = [...groupsMap.entries()].map(([rootId, ids]) => {
      const nodes = graph.nodes.filter((n) => ids.has(n.id));
      const edges = graph.edges.filter((e) => e.relation === 'delegation' && ids.has(e.from) && ids.has(e.to));
      const sub: OrchestrationGraph = { ...graph, nodes, edges, declared: undefined };
      return {
        rootId,
        weight: active.filter((a) => rootOf(a.node.id) === rootId).reduce((s, a) => s + a.weight, 0),
        graph: sub,
        topology: compressGraph(sub, rootId),
      };
    }).sort((a, b) => b.weight - a.weight);
    out.push({
      repoId,
      label: repo?.label || repoId.replace(/^repo:/, '').split('/').pop() || repoId,
      path: repo?.meta?.path || repoId.replace(/^repo:/, ''),
      weight: r.weight,
      lastTouched: r.last || undefined,
      agents,
      groups,
    });
  }
  return out.sort((a, b) => b.weight - a.weight || a.label.localeCompare(b.label));
}
