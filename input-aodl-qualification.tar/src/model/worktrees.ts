/**
 * Worktree ladder: trunk -> integration -> feature packs -> leaves.
 * Generalised from zerOS `worktree-ladder.js`. Like the original, tiers and
 * packs classify branches by name; they never invent git merge edges.
 */
import type { WorktreeTier } from './types';

const TRUNK = /^(main|master|dev|develop|trunk|nightly|preview|release)$/;
const INTEGRATION = /^(integrate|integration|hitl|preview|dogfood|qualification|release|staging|pr)\//;
const LEAF_BRANCH = /^(tour\/[^/]+\/.+|worktree-agent-)/;
const LEAF_NAME = /^(worktree-)?agent-[0-9a-f]/i;

export function classifyWorktreeTier(w: { branch?: string; name?: string; primary?: boolean }): WorktreeTier {
  const branch = String(w.branch || '').replace(/^refs\/heads\//, '');
  const name = String(w.name || '');
  if (TRUNK.test(branch)) return 'trunk';
  if (INTEGRATION.test(branch) || /compressed-/.test(branch)) return 'integration';
  if (!branch || branch === 'DETACHED' || LEAF_BRANCH.test(branch) || LEAF_NAME.test(name)) return 'leaf';
  return 'feature';
}

/** Generic branch kinds that are not a pack on their own. */
const GENERIC = new Set(['feat', 'fix', 'ui', 'exp', 'chore', 'docs', 'worker', 'ephemeral', 'overnight', 'perf']);

/**
 * Pack key for a branch: `tour/<pack>/<leaf>` -> `tour/<pack>`; a non-generic
 * first segment (e.g. `ovt/…`) -> that segment; detached -> `detached`.
 * Returns null when the branch stands alone.
 */
export function packKey(branch: string | undefined): string | null {
  const b = String(branch || '');
  if (!b || b === 'DETACHED') return 'detached';
  const parts = b.split('/');
  if (parts[0] === 'tour' && parts.length >= 3) return `tour/${parts[1]}`;
  if (parts.length >= 2 && !GENERIC.has(parts[0])) return parts[0];
  return null;
}

export const TIER_ORDER: WorktreeTier[] = ['trunk', 'integration', 'feature', 'leaf'];
export const TIER_LABEL: Record<WorktreeTier, string> = {
  trunk: 'Trunk',
  integration: 'Integration',
  feature: 'Features',
  leaf: 'Leaves',
};
