/**
 * Glyph compression: graph -> one AODL topology id, only through AODL rules.
 *
 *  1. A declared topology id wins, if AODL defines it. Anything else is `unknown`.
 *  2. Declared `policies.kinds` match ir-map.json: an exact kind-set match on
 *     exactly one `expressible` topology, else the single-kind `fromHotl` hint.
 *  3. Observed structure, read from declared edge relations only:
 *       one executor, no delegation        -> solo      (ir-map: "One declared executor. No fan-out.")
 *       delegation fan-out of depth 1      -> star      (ir-map: "declared allocation/delegation")
 *       delegation tree of depth >= 2      -> hierarchy (ir-map: recursion, finite depth; observed => finite)
 *     Any other executor<->executor relation is mixed, undeclared coordination: `unknown`.
 *  `swarm` and `hybrid` are `not-inferred` in ir-map.json and are never returned
 *  by rules 2-3. Density of a drawing is not connectivity, so mesh/ring/council
 *  are never read off a shape either.
 */
import { irMap, isTopologyId, topologyStatus, type TopologyId } from '../aodl/encodings';
import type { CompressedTopology, DeclaredCoordination, OrchestrationGraph } from './types';

const AGENT_KINDS = new Set(['executor', 'verifier']);

function sameSet(a: string[], b: string[]): boolean {
  const A = new Set(a);
  const B = new Set(b);
  return A.size === B.size && [...A].every((x) => B.has(x));
}

export function topologyFromDeclared(declared: DeclaredCoordination | undefined): TopologyId | null {
  if (!declared) return null;
  if (declared.topologyId !== undefined) {
    return isTopologyId(declared.topologyId) ? declared.topologyId : 'unknown';
  }
  const kinds = (declared.policyKinds || []).filter((k) => typeof k === 'string');
  if (!kinds.length) return null;
  const topologies = irMap.topologies as Record<string, { status: string; policies?: { kinds?: string[] } }>;
  const exact = Object.entries(topologies).filter(
    ([id, t]) => t.status === 'expressible' && t.policies?.kinds && sameSet(t.policies.kinds, kinds) && isTopologyId(id),
  );
  if (exact.length === 1) return exact[0][0] as TopologyId;
  if (kinds.length === 1) {
    const hint = (irMap.fromHotl as Record<string, string | null>)[kinds[0]];
    if (hint && isTopologyId(hint) && topologyStatus(hint) === 'expressible') return hint;
  }
  return 'unknown';
}

/**
 * Compress the agent subgraph rooted at `rootId` (or the whole graph's agents
 * when omitted). Returns members in glyph order: root, then breadth-first.
 */
export function compressGraph(graph: Pick<OrchestrationGraph, 'nodes' | 'edges' | 'declared'>, rootId?: string): CompressedTopology {
  const agents = new Map(graph.nodes.filter((n) => AGENT_KINDS.has(n.kind)).map((n) => [n.id, n]));
  const agentEdges = graph.edges.filter((e) => agents.has(e.from) && agents.has(e.to));
  const children = new Map<string, string[]>();
  for (const e of agentEdges) {
    if (e.relation !== 'delegation') continue;
    if (!children.has(e.from)) children.set(e.from, []);
    children.get(e.from)!.push(e.to);
  }

  // Scope: root + everything it delegated to (breadth-first, cycle-safe).
  let scope: string[];
  const depthOf = new Map<string, number>();
  if (rootId) {
    if (!agents.has(rootId)) return { topologyId: 'unknown', rule: 'none', memberIds: [] };
    scope = [rootId];
    depthOf.set(rootId, 0);
    for (let i = 0; i < scope.length; i += 1) {
      for (const c of children.get(scope[i]) || []) {
        if (depthOf.has(c)) continue;
        depthOf.set(c, depthOf.get(scope[i])! + 1);
        scope.push(c);
      }
    }
  } else {
    scope = [...agents.keys()];
  }

  const declared = topologyFromDeclared(graph.declared);
  if (declared) return { topologyId: declared, rule: graph.declared?.topologyId !== undefined ? 'declared-topology' : 'declared-policy', memberIds: scope };

  const inScope = new Set(scope);
  const scoped = agentEdges.filter((e) => inScope.has(e.from) && inScope.has(e.to));
  if (scoped.some((e) => e.relation !== 'delegation')) return { topologyId: 'unknown', rule: 'none', memberIds: scope };

  if (scope.length === 1 && scoped.length === 0) return { topologyId: 'solo', rule: 'single-executor', memberIds: scope };
  if (!rootId) return { topologyId: 'unknown', rule: 'none', memberIds: scope };

  // Delegation must form a tree from the root: every non-root member has one parent.
  const parents = new Map<string, number>();
  for (const e of scoped) parents.set(e.to, (parents.get(e.to) || 0) + 1);
  const isTree = scope.slice(1).every((id) => parents.get(id) === 1) && !parents.has(rootId);
  if (!isTree) return { topologyId: 'unknown', rule: 'none', memberIds: scope };

  const maxDepth = Math.max(...scope.map((id) => depthOf.get(id) || 0));
  if (maxDepth === 1) return { topologyId: 'star', rule: 'delegation-fanout', memberIds: scope };
  return { topologyId: 'hierarchy', rule: 'delegation-tree', memberIds: scope };
}
