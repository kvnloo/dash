/**
 * GraphView: chats, subagents, repos and hosts as one living map.
 * From zerOS SystemNetworkGraph: same four organisations (spine, constellation,
 * radial, islands), focus vs all, tap to focus, long-press to inspect, and flow
 * particles along edges. Status is drawn as rings and cadence, not captions.
 */
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import Svg, { Circle, G, Path, Rect, Text as SvgText } from 'react-native-svg';
import Animated, { Easing, useAnimatedProps, useReducedMotion, useSharedValue, withTiming, type SharedValue } from 'react-native-reanimated';
import { providerHue } from '../aodl/encodings';
import { curvePath, edgeCurve, layoutGraph, LAYOUT_MODES, nodeEnergy, projectGraph, thinEdges, type LayoutMode, type Placed, type ViewNode } from '../layout/graph-layout';
import { CADENCE, desaturate, useClock, withAlpha } from '../motion/cadence';
import { motion, night } from '../tokens';
import { fonts } from '../fonts';
import type { OrchestrationEdge, OrchestrationGraph, OrchestrationNode } from '../model/types';
import { BreathRing, FlowDot } from './svg-motion';
import { InspectCard, Segmented } from './ui';

const ACircle = Animated.createAnimatedComponent(Circle);
const ARect = Animated.createAnimatedComponent(Rect);
const APath = Animated.createAnimatedComponent(Path);

export const RELATION_COLOR: Record<string, string> = {
  delegation: night.action,
  artifact: night.information,
  dependency: night.textFaint,
};

type ViewEdge = OrchestrationEdge & { structural?: boolean };

export interface GraphViewProps {
  graph: OrchestrationGraph;
  width: number;
  height?: number;
  initialLayout?: LayoutMode;
  initialMode?: 'focus' | 'all';
  initialFocusId?: string | null;
  onInspect?: (node: OrchestrationNode) => void;
  testID?: string;
}

const lerp = (a: number, b: number, p: number) => {
  'worklet';
  return a + (b - a) * p;
};

function nodeFill(n: ViewNode): string {
  if (n.role === 'repo') return night.action;
  if (n.role === 'host') return night.textSecondary;
  return desaturate(providerHue(n.providerId), CADENCE[n.state].desaturate);
}

function NodeShape({ n, from, to, p, dim, selected }: { n: ViewNode; from: Placed; to: Placed; p: SharedValue<number>; dim: boolean; selected: boolean }) {
  const fill = nodeFill(n);
  const op = dim ? 0.28 : 1;
  const circle = useAnimatedProps(() => ({ cx: lerp(from.x, to.x, p.value), cy: lerp(from.y, to.y, p.value), r: lerp(from.r, to.r, p.value) }));
  const rect = useAnimatedProps(() => {
    const r = lerp(from.r, to.r, p.value);
    return { x: lerp(from.x, to.x, p.value) - r, y: lerp(from.y, to.y, p.value) - r, width: 2 * r, height: 2 * r };
  });
  const dot = useAnimatedProps(() => ({ cx: lerp(from.x, to.x, p.value), cy: lerp(from.y, to.y, p.value) }));
  const ring = selected ? night.actionStrong : undefined;
  if (n.folded) {
    return (
      <G opacity={op}>
        <ACircle animatedProps={circle} cx={to.x} cy={to.y} r={to.r} fill={withAlpha(night.canvasRaised, 0.9)} stroke={night.borderDefault} strokeWidth={1} strokeDasharray="2 2.5" />
      </G>
    );
  }
  if (n.role === 'repo') {
    const w = Math.min(1, 0.18 + n.weight);
    return (
      <G opacity={op}>
        <ARect animatedProps={rect} x={to.x - to.r} y={to.y - to.r} width={to.r * 2} height={to.r * 2} rx={3} fill={withAlpha(fill, 0.12 + 0.3 * w)} stroke={ring || withAlpha(fill, 0.75)} strokeWidth={selected ? 2 : 1} />
      </G>
    );
  }
  if (n.role === 'host') {
    return (
      <G opacity={op}>
        <ACircle animatedProps={circle} cx={to.x} cy={to.y} r={to.r} fill="none" stroke={ring || withAlpha(fill, 0.8)} strokeWidth={selected ? 2 : 1.2} />
        <ACircle animatedProps={dot} cx={to.x} cy={to.y} r={2.4} fill={withAlpha(fill, 0.9)} />
      </G>
    );
  }
  return (
    <G opacity={op * CADENCE[n.state].opacity}>
      <ACircle
        animatedProps={circle}
        cx={to.x}
        cy={to.y}
        r={to.r}
        fill={n.role === 'subagent' ? withAlpha(fill, 0.85) : fill}
        stroke={ring || (n.phase === 'waiting-approval' ? night.actionStrong : withAlpha(night.canvas, 0.8))}
        strokeWidth={selected ? 2.2 : n.phase === 'waiting-approval' ? 1.4 : 1}
        strokeDasharray={n.phase === 'waiting-approval' && !selected ? '2 2' : undefined}
      />
    </G>
  );
}

function EdgePath({ e, a0, a1, b0, b1, p, dim, strength }: { e: ViewEdge; a0: Placed; a1: Placed; b0: Placed; b1: Placed; p: SharedValue<number>; dim: boolean; strength: number }) {
  const color = e.structural ? withAlpha(night.textFaint, 0.55) : withAlpha(RELATION_COLOR[e.relation] || night.textFaint, 0.16 + 0.42 * strength);
  const width = e.structural ? 0.8 : 0.6 + 1.6 * strength;
  const props = useAnimatedProps(() => {
    const ax = lerp(a0.x, a1.x, p.value);
    const ay = lerp(a0.y, a1.y, p.value);
    const bx = lerp(b0.x, b1.x, p.value);
    const by = lerp(b0.y, b1.y, p.value);
    const dx = bx - ax;
    const dy = by - ay;
    const dist = Math.sqrt(dx * dx + dy * dy) || 1;
    const nx = -dy / dist;
    const ny = dx / dist;
    const bend = Math.min(28, dist * 0.12);
    return {
      d: `M${ax} ${ay}C${ax + dx * 0.33 + nx * bend} ${ay + dy * 0.33 + ny * bend} ${ax + dx * 0.66 - nx * bend * 0.55} ${ay + dy * 0.66 - ny * bend * 0.55} ${bx} ${by}`,
    };
  });
  return <APath animatedProps={props} d={curvePath(edgeCurve(a1, b1))} stroke={color} strokeWidth={width} fill="none" opacity={dim ? 0.06 : 1} strokeDasharray={e.structural ? '1.5 3' : undefined} />;
}

const trunc = (s: string, n: number) => (s.length > n ? `${s.slice(0, n - 1)}…` : s);

export function GraphView({ graph, width, height, initialLayout = 'spine', initialMode = 'focus', initialFocusId = null, onInspect, testID }: GraphViewProps) {
  const H = height ?? (width < 480 ? 440 : 500);
  const narrow = width < 480;
  const [layoutMode, setLayoutMode] = useState<LayoutMode>(initialLayout);
  const [mode, setMode] = useState<'focus' | 'all'>(initialMode);
  const [focusId, setFocusId] = useState<string | null>(initialFocusId);
  const [inspect, setInspect] = useState<OrchestrationNode | null>(null);
  const reduced = useReducedMotion();

  const proj = useMemo(() => {
    const pr = projectGraph(graph, { mode, focusId });
    // Structural host links (where each root chat runs). Drawn faint; never flow.
    const ids = new Set(pr.nodes.map((n) => n.id));
    const extra: ViewEdge[] = [];
    for (const n of pr.nodes) {
      const hosts = n.folded ? [...new Set(n.folded.map((m) => m.hostId))] : [n.hostId];
      if ((n.role === 'chat' || (n.role === 'subagent' && !n.parentId && !n.folded)) && hosts[0] && ids.has(hosts[0])) {
        extra.push({ id: `host:${hosts[0]}->${n.id}`, from: hosts[0], to: n.id, relation: 'dependency', weight: 0.2, structural: true });
      }
    }
    const edges = mode === 'focus' ? thinEdges(pr.edges, { perAgent: 2, minShare: 0.008 }) : thinEdges(pr.edges, { perAgent: 4, minShare: 0.01 });
    return { ...pr, edges: [...extra, ...edges] as ViewEdge[] };
  }, [graph, mode, focusId]);

  const positions = useMemo(() => layoutGraph(proj, width, H - 8, layoutMode, focusId), [proj, width, H, layoutMode, focusId]);
  const prevRef = useRef<Map<string, Placed>>(positions);
  const shownRef = useRef<Map<string, Placed>>(positions);
  const p = useSharedValue(1);
  const [settled, setSettled] = useState(true);
  useEffect(() => {
    prevRef.current = shownRef.current;
    shownRef.current = positions;
    if (reduced) {
      p.value = 1;
      return undefined;
    }
    setSettled(false);
    p.value = 0;
    p.value = withTiming(1, { duration: motion.transition, easing: Easing.bezier(...motion.settle) });
    const id = setTimeout(() => setSettled(true), motion.transition + 40);
    return () => clearTimeout(id);
  }, [positions, reduced, p]);

  const hasFlow = proj.nodes.some((n) => n.state === 'running');
  const { t } = useClock(hasFlow);
  const nodeById = useMemo(() => new Map(proj.nodes.map((n) => [n.id, n])), [proj]);
  const neighbours = useMemo(() => {
    if (!focusId) return null;
    const s = new Set([focusId]);
    for (const e of proj.edges) {
      if (e.from === focusId) s.add(e.to);
      if (e.to === focusId) s.add(e.from);
    }
    return s;
  }, [focusId, proj]);

  const from = (id: string) => prevRef.current.get(id) || positions.get(id)!;
  const artMax = Math.max(1e-6, ...proj.edges.filter((e) => e.relation === 'artifact').map((e) => e.weight));

  // Labels: greedy, highest priority first, skipped if they would collide.
  const labels = useMemo(() => {
    const prio = (n: ViewNode) =>
      (n.id === focusId ? 100 : 0) + (neighbours?.has(n.id) ? 40 : 0) + (n.role === 'host' ? 30 : 0)
      + (n.state === 'running' ? 20 : 0) + (n.folded ? 25 : 0) + nodeEnergy(n) * 10 + (n.role === 'repo' ? 8 : 0) + (n.role === 'chat' ? 5 : 0);
    const placed: Array<{ x: number; y: number; w: number; h: number }> = [];
    const out: Array<{ id: string; x: number; y: number; text: string; anchor: 'start' | 'middle' }> = [];
    const max = narrow ? 9 : 22;
    const columns = layoutMode === 'spine' && !narrow;
    for (const n of [...proj.nodes].sort((a, b) => prio(b) - prio(a))) {
      if (out.length >= max) break;
      const pos = positions.get(n.id);
      if (!pos) continue;
      const text = trunc(n.folded ? n.label : n.label, narrow ? 16 : 24);
      const w = text.length * 5.4;
      const box = columns
        ? { x: pos.x + pos.r + 4, y: pos.y - 6, w, h: 12 }
        : { x: pos.x - w / 2, y: pos.y + pos.r + 2, w, h: 12 };
      if (box.x < 0 || box.x + box.w > width + 2) continue;
      if (placed.some((b) => box.x < b.x + b.w && b.x < box.x + box.w && box.y < b.y + b.h && b.y < box.y + box.h)) continue;
      placed.push(box);
      out.push({ id: n.id, x: columns ? box.x : pos.x, y: box.y + 9, text, anchor: columns ? 'start' : 'middle' });
    }
    return out;
  }, [proj, positions, focusId, neighbours, narrow, layoutMode, width]);

  const onTap = (n: ViewNode) => {
    if (n.folded) {
      setMode('all');
      return;
    }
    setFocusId(focusId === n.id ? null : n.id);
  };

  const shown = proj.nodes.filter((n) => !n.folded).length;
  return (
    <View style={{ width }} testID={testID}>
      <View style={[styles.controls, narrow && styles.controlsNarrow]}>
        <Segmented label="Layout" options={LAYOUT_MODES} value={layoutMode} onChange={setLayoutMode} />
        <View style={styles.controlsRight}>
          <Segmented label="Scope" options={[{ id: 'focus', label: 'Focus' }, { id: 'all', label: 'All' }]} value={mode} onChange={setMode} />
        </View>
      </View>
      <View style={[styles.canvas, { height: H }]}>
        <Svg width={width} height={H} accessibilityLabel={`System graph, ${layoutMode} layout. Tap to focus, hold to inspect.`}>
          {proj.edges.map((e) => {
            const a = positions.get(e.from);
            const b = positions.get(e.to);
            if (!a || !b) return null;
            const dim = Boolean(neighbours && !(neighbours.has(e.from) && neighbours.has(e.to)));
            const strength = e.relation === 'artifact' ? Math.sqrt(e.weight / artMax) : 0.55;
            return <EdgePath key={e.id} e={e} a0={from(e.from)} a1={a} b0={from(e.to)} b1={b} p={p} dim={dim} strength={strength} />;
          })}
          {settled && !reduced
            ? proj.edges.map((e, i) => {
              if (e.structural) return null;
              const a = nodeById.get(e.from);
              const b = nodeById.get(e.to);
              if (!a || !b || (a.state !== 'running' && b.state !== 'running')) return null;
              if (neighbours && !(neighbours.has(e.from) && neighbours.has(e.to))) return null;
              const pa = positions.get(e.from)!;
              const pb = positions.get(e.to)!;
              const color = RELATION_COLOR[e.relation] || night.textSecondary;
              const n = e.weight > 2 ? 2 : 1;
              return Array.from({ length: n }, (_, k) => (
                <FlowDot key={`${e.id}:${k}`} t={t} curve={edgeCurve(pa, pb)} speed={e.relation === 'delegation' ? 0.32 : 0.42} phase={((i * 0.29) + k / n) % 1} r={1.6} color={color} />
              ));
            })
            : null}
          {settled && !reduced
            ? proj.nodes.filter((n) => n.state === 'running' && !n.folded && n.role !== 'repo' && n.role !== 'host').map((n) => {
              const pos = positions.get(n.id)!;
              const dim = Boolean(neighbours && !neighbours.has(n.id));
              if (dim) return null;
              return <BreathRing key={`ring:${n.id}`} t={t} cx={pos.x} cy={pos.y} r={pos.r + 2} spread={4} period={3.6} color={nodeFill(n)} maxOpacity={0.45} />;
            })
            : null}
          {proj.nodes.map((n) => {
            const to = positions.get(n.id);
            if (!to) return null;
            return <NodeShape key={n.id} n={n} from={from(n.id)} to={to} p={p} dim={Boolean(neighbours && !neighbours.has(n.id))} selected={n.id === focusId} />;
          })}
          {settled
            ? proj.nodes.filter((n) => n.folded).map((n) => {
              const pos = positions.get(n.id)!;
              return (
                <SvgText key={`c:${n.id}`} x={pos.x} y={pos.y + 3.5} fontSize={10} fill={night.textSecondary} textAnchor="middle" fontFamily={fonts.telemetry}>
                  {String(n.folded!.length)}
                </SvgText>
              );
            })
            : null}
          {settled
            ? labels.map((l) => (
              <G key={`l:${l.id}`}>
                <SvgText x={l.x} y={l.y} fontSize={10} fill="none" stroke={night.canvas} strokeWidth={3.2} strokeLinejoin="round" textAnchor={l.anchor} fontFamily={fonts.operational}>
                  {l.text}
                </SvgText>
                <SvgText x={l.x} y={l.y} fontSize={10} fill={l.id === focusId ? night.textPrimary : night.textSecondary} textAnchor={l.anchor} fontFamily={fonts.operational}>
                  {l.text}
                </SvgText>
              </G>
            ))
            : null}
          {proj.nodes.map((n) => {
            const pos = positions.get(n.id);
            if (!pos) return null;
            return (
              <Circle
                key={`hit:${n.id}`}
                cx={pos.x}
                cy={pos.y}
                r={Math.max(12, pos.r + 5)}
                fill="transparent"
                onPress={() => onTap(n)}
                onLongPress={() => {
                  if (n.folded) return;
                  setInspect(n);
                  onInspect?.(n);
                }}
                delayLongPress={480}
              />
            );
          })}
        </Svg>
        {inspect ? (
          <View style={[styles.inspect, narrow ? { left: 8, right: 8 } : { right: 12, width: 300 }]}>
            <InspectCard node={inspect} now={graph.generatedAt} onClose={() => setInspect(null)} />
          </View>
        ) : null}
      </View>
      <Legend narrow={narrow} count={proj.hidden ? `${shown} of ${shown + proj.hidden} shown` : `${shown} shown`} />
    </View>
  );
}

function Legend({ narrow, count }: { narrow: boolean; count: string }) {
  const items: Array<[React.ReactNode, string]> = [
    [<Circle key="c" cx={6} cy={6} r={4.5} fill={providerHue('anthropic')} />, 'chat'],
    [<Circle key="s" cx={6} cy={6} r={3} fill={withAlpha(providerHue('openai'), 0.85)} />, 'subagent'],
    [<Rect key="r" x={2} y={2} width={8} height={8} rx={2} fill={withAlpha(night.action, 0.3)} stroke={night.action} strokeWidth={1} />, 'repo'],
    [<G key="h"><Circle cx={6} cy={6} r={4.5} fill="none" stroke={night.textSecondary} strokeWidth={1} /><Circle cx={6} cy={6} r={1.6} fill={night.textSecondary} /></G>, 'host'],
    [<Path key="d" d="M0 6h12" stroke={night.action} strokeWidth={1.4} />, 'delegated'],
    [<Path key="a" d="M0 6h12" stroke={night.information} strokeWidth={1.4} />, 'touched'],
  ];
  return (
    <View style={[styles.legend, narrow && { gap: 10 }]}>
      {items.map(([icon, label]) => (
        <View key={label} style={styles.legendItem}>
          <Svg width={12} height={12}>{icon}</Svg>
          <Text style={styles.legendText}>{label}</Text>
        </View>
      ))}
      <Text style={[styles.count, { marginLeft: 'auto' }]}>{count}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  controls: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10, gap: 8 },
  controlsNarrow: { flexDirection: 'column', alignItems: 'flex-start' },
  controlsRight: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  count: { color: night.textFaint, fontFamily: fonts.telemetry, fontSize: 10 },
  canvas: { position: 'relative' },
  inspect: { position: 'absolute', bottom: 8 },
  legend: { flexDirection: 'row', flexWrap: 'wrap', gap: 14, marginTop: 8 },
  legendItem: { flexDirection: 'row', alignItems: 'center', gap: 5 },
  legendText: { color: night.textTertiary, fontFamily: fonts.operational, fontSize: 11 },
});
