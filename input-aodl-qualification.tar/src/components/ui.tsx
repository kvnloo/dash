/** Quiet Living Night controls shared by the views. */
import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { ago } from '../model/decay';
import { CADENCE } from '../motion/cadence';
import { night, radius } from '../tokens';
import { fonts } from '../fonts';
import type { OrchestrationNode } from '../model/types';

export function Segmented<T extends string>({ options, value, onChange, label }: {
  options: Array<{ id: T; label: string }>;
  value: T;
  onChange: (id: T) => void;
  label: string;
}) {
  return (
    <View style={styles.seg} accessibilityRole="tablist" accessibilityLabel={label}>
      {options.map((o) => {
        const on = o.id === value;
        return (
          <Pressable
            key={o.id}
            onPress={() => onChange(o.id)}
            accessibilityRole="tab"
            accessibilityState={{ selected: on }}
            style={[styles.segItem, on && styles.segOn]}
          >
            <Text style={[styles.segText, on && styles.segTextOn]}>{o.label}</Text>
          </Pressable>
        );
      })}
    </View>
  );
}

export function StateDot({ state, size = 6 }: { state: OrchestrationNode['state']; size?: number }) {
  const c = CADENCE[state];
  const filled = state === 'running' || state === 'blocked';
  return (
    <View
      accessibilityLabel={state}
      style={{
        width: size,
        height: size,
        borderRadius: state === 'blocked' ? 1 : size,
        transform: state === 'blocked' ? [{ rotate: '45deg' }] : undefined,
        backgroundColor: filled ? c.accent : 'transparent',
        borderWidth: filled ? 0 : 1,
        borderColor: c.accent,
        borderStyle: state === 'stale' ? 'dashed' : 'solid',
        opacity: c.opacity,
      }}
    />
  );
}

/** Long-press inspect: the facts of one node, nothing else. */
export function InspectCard({ node, now, onClose }: { node: OrchestrationNode; now: number; onClose: () => void }) {
  const rows: Array<[string, string]> = [
    ['role', `${node.role} · ${node.kind}`],
    ['state', `${node.state}${node.phase && node.phase !== 'idle' ? ` · ${node.phase}` : ''}${node.tool ? ` · ${node.tool}` : ''}`],
  ];
  if (node.meta?.model) rows.push(['model', node.meta.model]);
  if (node.providerId !== 'unknown') rows.push(['provider', node.providerId]);
  if (node.lastActivity) rows.push(['active', `${ago(node.lastActivity, now)} ago`]);
  if (node.meta?.messages) rows.push(['turns', `${node.meta.messages} messages · ${node.meta.tools || 0} tool calls`]);
  if (node.meta?.profile) rows.push(['profile', `${node.meta.profile}${node.meta.source ? ` · ${node.meta.source}` : ''}`]);
  if (node.meta?.branch) rows.push(['branch', node.meta.branch]);
  if (node.meta?.path && node.role === 'repo') rows.push(['repo', node.meta.path]);
  if (node.role === 'repo') rows.push(['weight', node.weight.toFixed(2)]);
  return (
    <View style={styles.card} accessibilityRole="summary">
      <View style={styles.cardHead}>
        <StateDot state={node.state} size={7} />
        <Text style={styles.cardTitle} numberOfLines={2}>{node.label}</Text>
        <Pressable onPress={onClose} accessibilityRole="button" accessibilityLabel="Close" hitSlop={10}>
          <Text style={styles.close}>×</Text>
        </Pressable>
      </View>
      {rows.map(([k, v]) => (
        <View key={k} style={styles.row}>
          <Text style={styles.key}>{k}</Text>
          <Text style={styles.val} numberOfLines={1}>{v}</Text>
        </View>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  seg: { flexDirection: 'row', borderRadius: radius.pill, borderWidth: 1, borderColor: night.borderSubtle, padding: 2, alignSelf: 'flex-start' },
  segItem: { paddingHorizontal: 10, paddingVertical: 5, borderRadius: radius.pill },
  segOn: { backgroundColor: 'rgba(215,185,134,0.14)' },
  segText: { color: night.textTertiary, fontFamily: fonts.operational, fontSize: 12 },
  segTextOn: { color: night.actionStrong },
  card: {
    backgroundColor: night.glassRaised,
    borderColor: night.borderDefault,
    borderWidth: 1,
    borderRadius: radius.sheet,
    paddingHorizontal: 14,
    paddingVertical: 12,
    gap: 4,
  },
  cardHead: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 4 },
  cardTitle: { flex: 1, color: night.textPrimary, fontFamily: fonts.operational, fontSize: 14 },
  close: { color: night.textTertiary, fontSize: 18, lineHeight: 18, paddingHorizontal: 4 },
  row: { flexDirection: 'row', gap: 10 },
  key: { width: 58, color: night.textFaint, fontFamily: fonts.telemetry, fontSize: 10, lineHeight: 16, textTransform: 'uppercase', letterSpacing: 0.6 },
  val: { flex: 1, color: night.textSecondary, fontFamily: fonts.operational, fontSize: 12, lineHeight: 16 },
});
