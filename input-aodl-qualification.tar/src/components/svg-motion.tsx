/**
 * Small animated SVG primitives shared by every view. Each reads one frame
 * clock (seconds) on the UI thread; nothing re-renders React per frame.
 */
import React from 'react';
import { Circle, Path } from 'react-native-svg';
import Animated, { useAnimatedProps, type SharedValue } from 'react-native-reanimated';

const ACircle = Animated.createAnimatedComponent(Circle);
const APath = Animated.createAnimatedComponent(Path);

export interface Bezier {
  p0: { x: number; y: number };
  p1: { x: number; y: number };
  p2: { x: number; y: number };
  p3: { x: number; y: number };
}

export function lineAsBezier(x1: number, y1: number, x2: number, y2: number): Bezier {
  return {
    p0: { x: x1, y: y1 },
    p1: { x: x1 + (x2 - x1) / 3, y: y1 + (y2 - y1) / 3 },
    p2: { x: x1 + ((x2 - x1) * 2) / 3, y: y1 + ((y2 - y1) * 2) / 3 },
    p3: { x: x2, y: y2 },
  };
}

/** A particle travelling an edge from -> to: the flow channel. */
export function FlowDot({ t, curve, speed, phase, r, color }: {
  t: SharedValue<number>;
  curve: Bezier;
  /** Trips per second. */
  speed: number;
  phase: number;
  r: number;
  color: string;
}) {
  const { p0, p1, p2, p3 } = curve;
  const props = useAnimatedProps(() => {
    const u = (((t.value * speed + phase) % 1) + 1) % 1;
    const v = 1 - u;
    const a = v * v * v;
    const b = 3 * v * v * u;
    const c = 3 * v * u * u;
    const d = u * u * u;
    return {
      cx: a * p0.x + b * p1.x + c * p2.x + d * p3.x,
      cy: a * p0.y + b * p1.y + c * p2.y + d * p3.y,
      opacity: Math.sin(Math.PI * u) * 0.95,
    };
  });
  return <ACircle r={r} fill={color} animatedProps={props} cx={p0.x} cy={p0.y} opacity={0} />;
}

/** A soft ring that breathes around a node: live presence, or a warning pulse. */
export function BreathRing({ t, cx, cy, r, spread, period, color, width = 1, phase = 0, minOpacity = 0.08, maxOpacity = 0.5 }: {
  t: SharedValue<number>;
  cx: number;
  cy: number;
  r: number;
  spread: number;
  period: number;
  color: string;
  width?: number;
  phase?: number;
  minOpacity?: number;
  maxOpacity?: number;
}) {
  const props = useAnimatedProps(() => {
    const s = 0.5 - 0.5 * Math.cos(((t.value / period + phase) % 1) * Math.PI * 2);
    return { r: r + spread * s, opacity: maxOpacity - (maxOpacity - minOpacity) * s };
  });
  return <ACircle cx={cx} cy={cy} r={r} fill="none" stroke={color} strokeWidth={width} animatedProps={props} />;
}

/** Dash offset march along a path: used for flowing edges at glyph scale. */
export function MarchingPath({ t, d, color, width, dash, speed }: {
  t: SharedValue<number>;
  d: string;
  color: string;
  width: number;
  dash: [number, number];
  speed: number;
}) {
  const period = dash[0] + dash[1];
  const props = useAnimatedProps(() => ({ strokeDashoffset: -((t.value * speed * period) % period) }));
  return <APath d={d} stroke={color} strokeWidth={width} strokeDasharray={`${dash[0]} ${dash[1]}`} fill="none" strokeLinecap="round" animatedProps={props} />;
}
