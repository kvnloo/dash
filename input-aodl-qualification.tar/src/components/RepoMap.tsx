/**
 * RepoMap: where the work is. Bubble area = time-decayed touch weight
 * (the zerOS gallery ChatRepoMap prototype, as a packed layout). Scrub "as of"
 * back through the snapshot window or change the half-life and the bubbles
 * re-weigh in place. Each bubble carries a glyph per group of agents active in
 * that repo (their delegation subtree, compressed via AODL).
 */
import React, { useEffect, useMemo, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import Svg, { Circle, Text as SvgText } from 'react-native-svg';
import Animated, { Easing, useAnimatedProps, useReducedMotion, useSharedValue, withTiming } from 'react-native-reanimated';
import { fitPack, packCircles } from '../layout/pack';
import { ago } from '../model/decay';
import { repoWeights, type RepoWeight } from '../model/repo-weights';
import { withAlpha } from '../motion/cadence';
import { motion, night } from '../tokens';
import { fonts } from '../fonts';
import type { OrchestrationGraph } from '../model/types';
import { liveGlyph } from './glyph-data';
import { glyphWidth, TopologyGlyph } from './TopologyGlyph';
import { Segmented, StateDot } from './ui';

const ACircle = Animated.createAnimatedComponent(Circle);
const AText = Animated.createAnimatedComponent(SvgText);

export interface RepoMapProps {
  graph: OrchestrationGraph;
  width: number;
  height?: number;
  /** Only count work under this chat's delegation tree. */
  scopeRootId?: string | null;
  max?: number;
  testID?: string;
}

const AS_OF = [
  { id: '-12', label: '−12h' },
  { id: '-6', label: '−6h' },
  { id: '-2', label: '−2h' },
  { id: '0', label: 'Now' },
] as const;
const HALF_LIVES = [
  { id: '0.5', label: '30m' },
  { id: '2', label: '2h' },
  { id: '8', label: '8h' },
] as const;

function Bubble({ x, y, r, w, label, selected, onPress, outsideLabel }: { x: number; y: number; r: number; w: number; label: string; selected: boolean; onPress: () => void; outsideLabel: boolean }) {
  const reduced = useReducedMotion();
  const sx = useSharedValue(x);
  const sy = useSharedValue(y);
  const sr = useSharedValue(0);
  useEffect(() => {
    const cfg = { duration: reduced ? 0 : motion.transition, easing: Easing.bezier(...motion.settle) };
    sx.value = withTiming(x, cfg);
    sy.value = withTiming(y, cfg);
    sr.value = withTiming(r, cfg);
  }, [x, y, r, reduced, sx, sy, sr]);
  const circle = useAnimatedProps(() => ({ cx: sx.value, cy: sy.value, r: Math.max(0, sr.value) }));
  const inside = r >= 22;
  // Shrink the type a little to fit the whole name before truncating it.
  const fontSize = Math.max(9.5, Math.min(13, r / 3.6, (r * 1.75) / (label.length * 0.56)));
  const maxChars = Math.max(4, Math.floor((r * 1.75) / (fontSize * 0.56)));
  const text = label.length > maxChars ? `${label.slice(0, maxChars - 1)}…` : label;
  const textProps = useAnimatedProps(() => ({
    x: sx.value,
    y: inside ? sy.value - (r >= 34 ? 6 : -fontSize / 3) : sy.value + sr.value + 11,
  }));
  return (
    <>
      <ACircle
        animatedProps={circle}
        cx={x}
        cy={y}
        r={r}
        fill={withAlpha(night.action, 0.04 + 0.16 * w)}
        stroke={selected ? night.actionStrong : withAlpha(night.action, 0.28 + 0.5 * w)}
        strokeWidth={selected ? 2 : 1}
        onPress={onPress}
      />
      {inside || outsideLabel ? (
        <AText
          animatedProps={textProps}
          x={x}
          y={y}
          fontSize={inside ? fontSize : 10}
          fill={inside ? night.textPrimary : night.textTertiary}
          textAnchor="middle"
          fontFamily={fonts.operational}
          onPress={onPress}
        >
          {text}
        </AText>
      ) : null}
    </>
  );
}

export function RepoMap({ graph, width, height, scopeRootId = null, max = 22, testID }: RepoMapProps) {
  const H = height ?? (width < 480 ? 340 : 400);
  const narrow = width < 480;
  const [asOf, setAsOf] = useState<(typeof AS_OF)[number]['id']>('0');
  const [halfLife, setHalfLife] = useState<(typeof HALF_LIVES)[number]['id']>('2');
  const [selected, setSelected] = useState<string | null>(null);
  const at = graph.generatedAt + Number(asOf) * 3600;

  const repos = useMemo(() => {
    const all = repoWeights(graph, { at, halfLifeHours: Number(halfLife), scopeRootId });
    const top = all[0]?.weight || 0;
    return all.filter((r) => r.weight > top * 0.012).slice(0, max);
  }, [graph, at, halfLife, scopeRootId, max]);

  const packed = useMemo(() => {
    const top = repos[0]?.weight || 1;
    const items = repos.map((r) => ({ id: r.repoId, r: 10 + 90 * Math.sqrt(r.weight / top) }));
    return fitPack(packCircles(items, width / H), width, H, 10).circles;
  }, [repos, width, H]);

  const byId = useMemo(() => new Map(repos.map((r) => [r.repoId, r])), [repos]);
  // Small bubbles get a label underneath only where it touches nothing else.
  const outside = useMemo(() => {
    const ok = new Set<string>();
    const boxes: Array<{ x: number; y: number; w: number; h: number }> = [];
    for (const c of [...packed].sort((a, b) => b.r - a.r)) {
      if (c.r >= 22 || c.r < 9) continue;
      const label = byId.get(c.id)?.label || '';
      const text = label.length > 9 ? 9 : label.length;
      const w = text * 5.6;
      const box = { x: c.x - w / 2, y: c.y + c.r + 2, w, h: 12 };
      const hitsCircle = packed.some((o) => o.id !== c.id && Math.max(Math.abs(o.x - (box.x + w / 2)) - w / 2, 0) ** 2 + Math.max(Math.abs(o.y - (box.y + 6)) - 6, 0) ** 2 < o.r * o.r);
      const hitsLabel = boxes.some((b) => box.x < b.x + b.w && b.x < box.x + box.w && box.y < b.y + b.h && b.y < box.y + box.h);
      if (hitsCircle || hitsLabel || box.y + box.h > H || box.x < 0 || box.x + w > width) continue;
      boxes.push(box);
      ok.add(c.id);
    }
    return ok;
  }, [packed, byId, H, width]);
  const top = repos[0]?.weight || 1;
  const sel = selected ? byId.get(selected) : undefined;
  const [settled, setSettled] = useState(true);
  useEffect(() => {
    setSettled(false);
    const id = setTimeout(() => setSettled(true), motion.transition + 40);
    return () => clearTimeout(id);
  }, [packed]);

  return (
    <View style={{ width }} testID={testID}>
      <View style={[styles.controls, narrow && styles.controlsNarrow]}>
        <View style={styles.control}>
          <Text style={styles.controlLabel}>As of</Text>
          <Segmented label="As of" options={[...AS_OF]} value={asOf} onChange={setAsOf} />
        </View>
        <View style={styles.control}>
          <Text style={styles.controlLabel}>Half-life</Text>
          <Segmented label="Half-life" options={[...HALF_LIVES]} value={halfLife} onChange={setHalfLife} />
        </View>
      </View>
      <View style={{ width, height: H }}>
        <Svg width={width} height={H} accessibilityLabel="Repo map: bubble area is time-decayed touch weight">
          {packed.map((c) => {
            const r = byId.get(c.id)!;
            return (
              <Bubble key={c.id} x={c.x} y={c.y} r={c.r} w={Math.sqrt(r.weight / top)} label={r.label} selected={selected === c.id} onPress={() => setSelected(selected === c.id ? null : c.id)} outsideLabel={outside.has(c.id)} />
            );
          })}
        </Svg>
        {settled
          ? packed.map((c) => {
            const r = byId.get(c.id)!;
            if (c.r < 34 || !r.groups.length) return null;
            const groups = r.groups.slice(0, c.r >= 60 ? 3 : 2);
            const gw = glyphWidth(16) + 4;
            const total = groups.length * gw + (r.groups.length > groups.length ? 14 : 0);
            return (
              <View key={`g:${c.id}`} pointerEvents="none" style={[styles.glyphRow, { left: c.x - total / 2, top: c.y + 2, width: total }]}>
                {groups.map((g) => {
                  const lg = liveGlyph(g.graph, g.rootId, g.topology);
                  return <TopologyGlyph key={g.rootId} {...lg.props} size={16} />;
                })}
                {r.groups.length > groups.length ? <Text style={styles.plus}>{`+${r.groups.length - groups.length}`}</Text> : null}
              </View>
            );
          })
          : null}
        {!repos.length ? <Text style={styles.empty}>Nothing touched in this window yet.</Text> : null}
      </View>
      {sel ? <RepoDetail repo={sel} now={graph.generatedAt} onClose={() => setSelected(null)} /> : null}
    </View>
  );
}

function RepoDetail({ repo, now, onClose }: { repo: RepoWeight; now: number; onClose: () => void }) {
  return (
    <View style={styles.detail}>
      <View style={styles.detailHead}>
        <Text style={styles.detailTitle} numberOfLines={1}>{repo.path}</Text>
        <Text style={styles.detailMeta}>{repo.lastTouched ? `touched ${ago(repo.lastTouched, now)} ago` : ''}</Text>
        <Pressable onPress={onClose} hitSlop={10} accessibilityRole="button" accessibilityLabel="Close"><Text style={styles.close}>×</Text></Pressable>
      </View>
      {repo.agents.slice(0, 5).map((a) => (
        <View key={a.node.id} style={styles.agentRow}>
          <StateDot state={a.node.state} />
          <Text style={styles.agent} numberOfLines={1}>{a.node.label}</Text>
          <View style={[styles.bar, { width: Math.max(4, 64 * (a.weight / (repo.agents[0]?.weight || 1))) }]} />
        </View>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  controls: { flexDirection: 'row', gap: 18, marginBottom: 8, alignItems: 'center' },
  controlsNarrow: { flexDirection: 'column', alignItems: 'flex-start', gap: 8 },
  control: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  controlLabel: { color: night.textFaint, fontFamily: fonts.telemetry, fontSize: 10, textTransform: 'uppercase', letterSpacing: 0.8, width: 62 },
  glyphRow: { position: 'absolute', flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 4 },
  plus: { color: night.textTertiary, fontFamily: fonts.telemetry, fontSize: 9 },
  empty: { position: 'absolute', top: '45%', alignSelf: 'center', color: night.textTertiary, fontFamily: fonts.operational, fontSize: 12 },
  detail: { marginTop: 8, padding: 12, borderRadius: 12, borderWidth: 1, borderColor: night.borderSubtle, backgroundColor: night.glass, gap: 6 },
  detailHead: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  detailTitle: { flex: 1, color: night.textPrimary, fontFamily: fonts.operational, fontSize: 13 },
  detailMeta: { color: night.textFaint, fontFamily: fonts.telemetry, fontSize: 10 },
  close: { color: night.textTertiary, fontSize: 18, lineHeight: 18, paddingHorizontal: 4 },
  agentRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  agent: { flex: 1, color: night.textSecondary, fontFamily: fonts.operational, fontSize: 12 },
  bar: { height: 3, borderRadius: 2, backgroundColor: withAlpha(night.action, 0.6) },
});
