/**
 * Live graph -> glyph props: compress a chat's delegation subtree through the
 * AODL rules, then put each member on its silhouette slot.
 */
import { providerHue, silhouette, type ProviderId, type RuntimeStateId } from '../aodl/encodings';
import { compressGraph } from '../model/compress';
import { assignMembers } from '../layout/glyph-geometry';
import type { CompressedTopology, OrchestrationGraph, OrchestrationNode } from '../model/types';
import type { GlyphNodeFill, TopologyGlyphProps } from './TopologyGlyph';

export function childrenIndex(graph: Pick<OrchestrationGraph, 'edges'>): (id: string) => string[] {
  const m = new Map<string, string[]>();
  for (const e of graph.edges) {
    if (e.relation !== 'delegation') continue;
    if (!m.has(e.from)) m.set(e.from, []);
    m.get(e.from)!.push(e.to);
  }
  return (id) => m.get(id) || [];
}

/** Cadence for a group: running if any member runs, else the root's state. */
export function groupState(members: OrchestrationNode[]): RuntimeStateId {
  if (members.some((m) => m.state === 'running')) return 'running';
  if (members.some((m) => m.state === 'blocked')) return 'blocked';
  return members[0]?.state || 'unknown';
}

export function groupProvider(members: OrchestrationNode[]): ProviderId {
  const ids = new Set(members.map((m) => m.providerId).filter((p) => p !== 'unknown'));
  if (ids.size === 0) return 'unknown';
  if (ids.size === 1) return [...ids][0];
  return 'multi';
}

export interface LiveGlyph {
  compressed: CompressedTopology;
  props: Omit<TopologyGlyphProps, 'size'>;
  members: OrchestrationNode[];
  /** member id -> silhouette node index */
  slots: Map<string, number>;
}

export function liveGlyph(graph: OrchestrationGraph, rootId: string, compressed = compressGraph(graph, rootId)): LiveGlyph {
  const byId = new Map(graph.nodes.map((n) => [n.id, n]));
  const members = compressed.memberIds.map((id) => byId.get(id)!).filter(Boolean);
  const kids = childrenIndex(graph);
  const slots = assignMembers(compressed.topologyId, compressed.memberIds, kids);
  const sil = silhouette(compressed.topologyId);
  const nodes: Array<GlyphNodeFill | null> = sil.nodes.map(() => null);
  for (const m of members) {
    const i = slots.get(m.id);
    if (i !== undefined) nodes[i] = { hue: providerHue(m.providerId), state: m.state };
  }
  if (sil.centerIndex !== undefined) nodes[sil.centerIndex] = { hue: providerHue('unknown') };
  const live = members.filter((m) => m.state === 'running').length;
  const root = byId.get(rootId);
  return {
    compressed,
    members,
    slots,
    props: {
      topologyId: compressed.topologyId,
      providerId: groupProvider(members),
      state: groupState(members),
      activity: members.length ? Math.min(1, 0.25 + live / Math.max(2, members.length)) : 0,
      nodes,
      overflow: Math.max(0, members.length - slots.size),
      operatingModeId: root?.operatingModeId || 'unknown',
      label: `${root?.label || rootId}: ${compressed.topologyId}, ${live} of ${members.length} live`,
    },
  };
}
