/**
 * AgentThinking: what an agent is doing, as a thinking-orbs orb.
 * State -> orb type mapping is documented in src/thinking/mapping.ts.
 */
import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { orbFor, type ThinkingIntent } from '../thinking/mapping';
import { OrbRenderer } from '../thinking/orb-renderer';
import { night } from '../tokens';
import { fonts } from '../fonts';
import type { ThinkingPhase } from '../model/types';

export interface AgentThinkingProps {
  phase: ThinkingPhase;
  tool?: string;
  intent?: ThinkingIntent;
  /** thinking-orbs ships two tuned sizes: 20 (inline) and 64 (avatar). */
  size?: 20 | 64;
  caption?: boolean;
  testID?: string;
}

export function AgentThinking({ phase, tool, intent, size = 64, caption = false, testID }: AgentThinkingProps) {
  const choice = orbFor(phase, { tool, intent });
  // The rim slot is always reserved so orbs line up whether or not it shows.
  const pad = size >= 64 ? 6 : 3;
  return (
    <View style={[styles.wrap, size < 64 && styles.inline]} testID={testID}>
      <View
        style={[
          { width: size + pad * 2, height: size + pad * 2, padding: pad - 1, borderRadius: size },
          { borderWidth: 1, borderColor: choice.rim ? night.actionStrong : 'transparent' },
          choice.paused && { opacity: 0.55 },
        ]}
      >
        <OrbRenderer state={choice.orb} size={size} theme="dark" speed={choice.speed} paused={choice.paused} accessibilityLabel={choice.caption} />
      </View>
      {caption ? <Text style={[styles.caption, size < 64 && styles.captionInline]} numberOfLines={1}>{choice.caption}</Text> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { alignItems: 'center', gap: 8 },
  inline: { flexDirection: 'row', gap: 8 },
  caption: { color: night.textSecondary, fontFamily: fonts.operational, fontSize: 12 },
  captionInline: { fontSize: 12 },
});
