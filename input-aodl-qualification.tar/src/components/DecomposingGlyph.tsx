/**
 * DecomposingGlyph: the glyph is the graph, folded.
 *
 * Collapsed, it is a TopologyGlyph (AODL silhouette + cadence). Tap it and
 * every glyph node travels to its place in the member graph below the header
 * (shared-element style, one canvas, 560 ms settle), labels fade in and ghost
 * silhouette slots fade out. Tap the hub (or the fold control) to fold it back.
 * Inside, tap selects a node and long-press inspects it: the node stays a node
 * (Ripple's zoom language: unit -> pattern -> node).
 *
 * Works for a live chat (graph + rootId) or a bare AODL topology (topologyId).
 */
import React, { useEffect, useMemo, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import Svg, { Circle, G, Line, Text as SvgText } from 'react-native-svg';
import Animated, {
  Easing,
  useAnimatedProps,
  useAnimatedStyle,
  useReducedMotion,
  useSharedValue,
  withTiming,
  type SharedValue,
} from 'react-native-reanimated';
import { providerHue, silhouette, SILHOUETTE_H, SILHOUETTE_W, silhouetteNodeHue, type ProviderId, type TopologyId } from '../aodl/encodings';
import { memberLayout } from '../layout/glyph-geometry';
import { CADENCE, desaturate, useClock, withAlpha } from '../motion/cadence';
import { motion, night } from '../tokens';
import { fonts } from '../fonts';
import type { OrchestrationGraph, OrchestrationNode } from '../model/types';
import { childrenIndex, liveGlyph } from './glyph-data';
import { glyphWidth, TopologyGlyph, type GlyphSize } from './TopologyGlyph';
import { BreathRing } from './svg-motion';

const ACircle = Animated.createAnimatedComponent(Circle);
const ALine = Animated.createAnimatedComponent(Line);
const AG = Animated.createAnimatedComponent(G);

interface MorphNode {
  id: string;
  label: string;
  hue: string;
  sx: number;
  sy: number;
  sr: number;
  ex: number;
  ey: number;
  er: number;
  running: boolean;
  node?: OrchestrationNode;
  ghost?: boolean;
}

export interface DecomposingGlyphProps {
  /** Live mode: a graph and the chat whose delegation subtree is the glyph. */
  graph?: OrchestrationGraph;
  rootId?: string;
  /** Catalog mode: a bare AODL topology. */
  topologyId?: TopologyId;
  providerId?: ProviderId;
  width: number;
  /** Height of the decomposed graph area. */
  height?: number;
  size?: GlyphSize;
  header?: React.ReactNode;
  defaultOpen?: boolean;
  onOpenChange?: (open: boolean) => void;
  onInspect?: (node: OrchestrationNode) => void;
  testID?: string;
}

const lerp = (a: number, b: number, p: number) => {
  'worklet';
  return a + (b - a) * p;
};

function MorphCircle({ n, p, selected }: { n: MorphNode; p: SharedValue<number>; selected: boolean }) {
  const props = useAnimatedProps(() => ({
    cx: lerp(n.sx, n.ex, p.value),
    cy: lerp(n.sy, n.ey, p.value),
    r: Math.max(0, lerp(n.sr, n.er, p.value)),
    opacity: n.ghost ? 1 - Math.min(1, p.value * 1.6) : 1,
  }));
  return (
    <ACircle
      animatedProps={props}
      cx={n.sx}
      cy={n.sy}
      r={n.sr}
      fill={n.ghost ? 'none' : n.hue}
      stroke={n.ghost ? withAlpha(night.textFaint, 0.8) : selected ? night.actionStrong : withAlpha(night.canvas, 0.7)}
      strokeWidth={n.ghost ? 0.6 : selected ? 2 : 1}
    />
  );
}

function MorphEdge({ a, b, p, color, ghost }: { a: MorphNode; b: MorphNode; p: SharedValue<number>; color: string; ghost?: boolean }) {
  const props = useAnimatedProps(() => ({
    x1: lerp(a.sx, a.ex, p.value),
    y1: lerp(a.sy, a.ey, p.value),
    x2: lerp(b.sx, b.ex, p.value),
    y2: lerp(b.sy, b.ey, p.value),
    opacity: ghost ? 1 - Math.min(1, p.value * 1.6) : 1,
  }));
  return <ALine animatedProps={props} x1={a.sx} y1={a.sy} x2={b.sx} y2={b.sy} stroke={color} strokeWidth={ghost ? 0.6 : 1} strokeDasharray={ghost ? '1 2' : undefined} strokeLinecap="round" />;
}

function FadeIn({ p, children }: { p: SharedValue<number>; children: React.ReactNode }) {
  const props = useAnimatedProps(() => ({ opacity: Math.max(0, (p.value - 0.62) / 0.38) }));
  return <AG animatedProps={props} opacity={0}>{children}</AG>;
}

const trunc = (s: string, n: number) => (s.length > n ? `${s.slice(0, n - 1)}…` : s);

interface PlacedLabel { id: string; x: number; y: number; text: string; anchor: 'start' | 'middle' | 'end'; root: boolean }

/** Radial labels pointing away from the hub, greedy and collision-free. */
function placeLabels(nodes: MorphNode[], rootId: string | undefined, width: number, top: number, h: number): PlacedLabel[] {
  const hub = nodes.find((n) => n.id === rootId) || nodes[0];
  if (!hub) return [];
  const narrow = width < 480;
  const max = narrow ? 6 : 12;
  const boxes: Array<{ x: number; y: number; w: number; h: number }> = [];
  // Node discs are obstacles too.
  for (const n of nodes) if (!n.ghost) boxes.push({ x: n.ex - n.er - 1, y: n.ey - n.er - 1, w: 2 * n.er + 2, h: 2 * n.er + 2 });
  const ordered = nodes.filter((n) => !n.ghost && n.label).sort((a, b) =>
    Number(b.id === rootId) - Number(a.id === rootId) || Number(b.running) - Number(a.running) || (b.node?.lastActivity || 0) - (a.node?.lastActivity || 0));
  const out: PlacedLabel[] = [];
  const hit = (b: { x: number; y: number; w: number; h: number }) => boxes.some((o) => b.x < o.x + o.w && o.x < b.x + b.w && b.y < o.y + o.h && o.y < b.y + b.h);
  for (const n of ordered) {
    if (out.length >= max) break;
    const root = n.id === rootId;
    const text = trunc(n.label, root ? (narrow ? 26 : 34) : narrow ? 18 : 24);
    const tw = text.length * (root ? 5.9 : 5.4);
    const dx = n.ex - hub.ex;
    const dy = n.ey - hub.ey;
    let anchor: PlacedLabel['anchor'] = 'middle';
    let x = n.ex;
    let y = n.ey + n.er + 12;
    if (!root && Math.abs(dx) > Math.abs(dy) * 0.6) {
      anchor = dx > 0 ? 'start' : 'end';
      x = n.ex + (dx > 0 ? n.er + 6 : -(n.er + 6));
      y = n.ey + 3.5;
    } else if (!root && dy < 0) {
      y = n.ey - n.er - 6;
    }
    const bx = anchor === 'start' ? x : anchor === 'end' ? x - tw : x - tw / 2;
    const box = { x: bx - 2, y: y - 10, w: tw + 4, h: 13 };
    if (box.x < 0 || box.x + box.w > width || box.y < top - 4 || box.y + box.h > top + h + 6) continue;
    if (hit(box)) continue;
    boxes.push(box);
    out.push({ id: n.id, x, y, text, anchor, root });
  }
  return out;
}

export function DecomposingGlyph({
  graph,
  rootId,
  topologyId: bareTopology,
  providerId: bareProvider = 'multi',
  width,
  height,
  size = 40,
  header,
  defaultOpen = false,
  onOpenChange,
  onInspect,
  testID,
}: DecomposingGlyphProps) {
  const reduced = useReducedMotion();
  const [open, setOpen] = useState(defaultOpen);
  const [settled, setSettled] = useState(!defaultOpen);
  const [selected, setSelected] = useState<string | null>(null);
  const p = useSharedValue(defaultOpen ? 1 : 0);
  const gw = glyphWidth(size);
  const gh = size;
  const areaTop = gh + 10;
  const H = height ?? Math.round(Math.min(320, Math.max(180, width * 0.58)));

  const live = useMemo(() => (graph && rootId ? liveGlyph(graph, rootId) : null), [graph, rootId]);
  const topologyId: TopologyId = live?.compressed.topologyId || bareTopology || 'unknown';
  const glyphProps = live?.props || { topologyId, providerId: bareProvider, state: 'running' as const, activity: 0.7 };

  const model = useMemo(() => {
    const sil = silhouette(topologyId);
    const pad = 2;
    const s = Math.min((gw - 2 * pad) / SILHOUETTE_W, (gh - 2 * pad) / SILHOUETTE_H);
    const ox = (gw - SILHOUETTE_W * s) / 2;
    const oy = (gh - SILHOUETTE_H * s) / 2;
    const gp = sil.nodes.map(([x, y, r]) => ({ x: ox + x * s, y: oy + y * s, r: Math.max(1.1, r * s) }));
    const nodes: MorphNode[] = [];
    const edges: Array<{ a: string; b: string; ghost?: boolean }> = [];
    if (live) {
      const kids = childrenIndex(graph!);
      const inScope = new Set(live.compressed.memberIds);
      const scopedKids = (id: string) => kids(id).filter((k) => inScope.has(k));
      const layout = memberLayout(rootId!, scopedKids, width, H, width < 480 ? 24 : 36);
      const parentOf = new Map<string, string>();
      for (const id of live.compressed.memberIds) for (const k of scopedKids(id)) parentOf.set(k, id);
      const slotOf = (id: string): number | undefined => {
        let cur: string | undefined = id;
        while (cur !== undefined) {
          const slot = live.slots.get(cur);
          if (slot !== undefined) return slot;
          cur = parentOf.get(cur);
        }
        return 0;
      };
      for (const m of live.members) {
        const slot = live.slots.get(m.id);
        const start = gp[slotOf(m.id) ?? 0] || { x: gw / 2, y: gh / 2, r: 1 };
        const end = layout.get(m.id) || { x: width / 2, y: H / 2, depth: 1 };
        const isRoot = m.id === rootId;
        nodes.push({
          id: m.id,
          label: m.label,
          hue: desaturate(providerHue(m.providerId), CADENCE[m.state].desaturate),
          sx: start.x,
          sy: start.y,
          sr: slot !== undefined ? start.r : 0,
          ex: end.x,
          ey: areaTop + end.y,
          er: isRoot ? 8 : end.depth === 1 ? 6 : 4.5,
          running: m.state === 'running',
          node: m,
        });
      }
      for (const id of live.compressed.memberIds) for (const k of scopedKids(id)) edges.push({ a: id, b: k });
      // Silhouette slots no member fills: ghosts that fade as the graph opens.
      const filled = new Set(live.slots.values());
      sil.nodes.forEach((_, i) => {
        if (filled.has(i) || sil.centerIndex === i) return;
        nodes.push({ id: `ghost:${i}`, label: '', hue: night.textFaint, sx: gp[i].x, sy: gp[i].y, sr: gp[i].r * 0.8, ex: gp[i].x, ey: gp[i].y, er: gp[i].r * 0.8, running: false, ghost: true });
      });
      const bySlot = new Map<number, string>();
      for (const [id, slot] of live.slots) bySlot.set(slot, id);
      sil.edges.forEach(([a, b]) => {
        const ia = bySlot.get(a);
        const ib = bySlot.get(b);
        if (ia && ib) {
          if (!edges.some((e) => (e.a === ia && e.b === ib) || (e.a === ib && e.b === ia))) edges.push({ a: ia, b: ib });
        } else edges.push({ a: ia || `ghost:${a}`, b: ib || `ghost:${b}`, ghost: true });
      });
    } else {
      // Catalog: the silhouette itself, zoomed to the pattern (dots and wires inside).
      const pad = 26;
      const S = Math.min((width - 2 * pad) / SILHOUETTE_W, (H - 2 * pad) / SILHOUETTE_H);
      const OX = (width - SILHOUETTE_W * S) / 2;
      const OY = areaTop + (H - SILHOUETTE_H * S) / 2;
      sil.nodes.forEach(([x, y, r], i) => {
        nodes.push({
          id: `n${i}`,
          label: '',
          hue: sil.centerIndex === i ? night.textTertiary : silhouetteNodeHue(bareProvider, i),
          sx: gp[i].x,
          sy: gp[i].y,
          sr: gp[i].r,
          ex: OX + x * S,
          ey: OY + y * S,
          er: Math.max(4, r * S * 0.55),
          running: i === 0,
        });
      });
      sil.edges.forEach(([a, b]) => edges.push({ a: `n${a}`, b: `n${b}` }));
    }
    return { nodes, edges, byId: new Map(nodes.map((n) => [n.id, n])) };
  }, [live, graph, rootId, topologyId, bareProvider, width, H, gw, gh, areaTop]);

  const setOpenState = (next: boolean) => {
    setOpen(next);
    setSettled(false);
    onOpenChange?.(next);
    if (!next) setSelected(null);
    p.value = withTiming(next ? 1 : 0, { duration: reduced ? 0 : motion.transition, easing: Easing.bezier(...motion.settle) });
  };
  // Once folded, swap the morph canvas back for the live glyph (ambient cadence).
  useEffect(() => {
    if (open) return undefined;
    const id = setTimeout(() => setSettled(true), reduced ? 0 : motion.transition + 30);
    return () => clearTimeout(id);
  }, [open, reduced]);

  const heightStyle = useAnimatedStyle(() => ({ height: lerp(gh, areaTop + H, p.value) }));
  // While open, the header slot keeps a faint folded glyph: the way back.
  const foldStyle = useAnimatedStyle(() => ({ opacity: Math.max(0, (p.value - 0.5) * 0.7) }));
  const { t } = useClock(open);
  const showGlyph = !open && settled;
  const selectedNode = selected ? model.byId.get(selected) : undefined;
  const edgeColor = withAlpha(night.action, 0.55);
  const labels = useMemo(() => placeLabels(model.nodes, rootId, width, areaTop, H), [model, rootId, width, areaTop, H]);

  return (
    <View style={{ width }} testID={testID}>
      <Animated.View style={[styles.frame, heightStyle]}>
        <View style={[styles.headerRow, { minHeight: gh }]}>
          <Pressable
            onPress={() => setOpenState(!open)}
            accessibilityRole="button"
            accessibilityState={{ expanded: open }}
            accessibilityLabel={`${open ? 'Fold' : 'Open'} ${glyphProps.label || topologyId}`}
            hitSlop={8}
            style={{ width: gw, height: gh }}
          >
            {showGlyph ? <TopologyGlyph {...glyphProps} size={size} /> : (
              <Animated.View style={foldStyle}>
                <TopologyGlyph {...glyphProps} size={size} state="paused" />
              </Animated.View>
            )}
          </Pressable>
          {header ? <View style={styles.header}>{header}</View> : null}
        </View>
        {!showGlyph ? (
          <Svg width={width} height={areaTop + H} style={StyleSheet.absoluteFill} pointerEvents="box-none">
            {model.edges.map((e, i) => {
              const a = model.byId.get(e.a);
              const b = model.byId.get(e.b);
              if (!a || !b) return null;
              return <MorphEdge key={`e${i}`} a={a} b={b} p={p} color={e.ghost ? withAlpha(night.textFaint, 0.6) : edgeColor} ghost={e.ghost} />;
            })}
            {model.nodes.map((n) => <MorphCircle key={n.id} n={n} p={p} selected={selected === n.id} />)}
            {open ? (
              <FadeIn p={p}>
                {model.nodes.filter((n) => n.running && !n.ghost).map((n) => (
                  <BreathRing key={`b${n.id}`} t={t} cx={n.ex} cy={n.ey} r={n.er + 1.5} spread={4} period={3.6} color={n.hue} width={1} maxOpacity={0.5} />
                ))}
                {labels.map((l) => (
                  <G key={`l${l.id}`}>
                    <SvgText x={l.x} y={l.y} fontSize={l.root ? 11 : 10} fill="none" stroke={night.canvas} strokeWidth={3.2} strokeLinejoin="round" textAnchor={l.anchor} fontFamily={fonts.operational}>
                      {l.text}
                    </SvgText>
                    <SvgText x={l.x} y={l.y} fontSize={l.root ? 11 : 10} fill={l.root ? night.textPrimary : night.textSecondary} textAnchor={l.anchor} fontFamily={fonts.operational}>
                      {l.text}
                    </SvgText>
                  </G>
                ))}
                {model.nodes.filter((n) => !n.ghost).map((n) => (
                  <Circle
                    key={`hit${n.id}`}
                    cx={n.ex}
                    cy={n.ey}
                    r={Math.max(14, n.er + 6)}
                    fill="transparent"
                    onPress={() => (n.id === rootId || (!live && n.id === 'n0') ? setOpenState(false) : setSelected(n.id === selected ? null : n.id))}
                    onLongPress={() => n.node && onInspect?.(n.node)}
                  />
                ))}
              </FadeIn>
            ) : null}
          </Svg>
        ) : null}
      </Animated.View>
      {open && selectedNode?.node ? (
        <Text style={styles.selection} numberOfLines={1}>
          {selectedNode.node.label}
          <Text style={styles.selectionMeta}>{`  ·  ${selectedNode.node.role} · ${selectedNode.node.state}${selectedNode.node.tool ? ` · ${selectedNode.node.tool}` : ''}`}</Text>
        </Text>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  frame: { overflow: 'hidden' },
  headerRow: { flexDirection: 'row', alignItems: 'center' },
  header: { flex: 1, marginLeft: 12, justifyContent: 'center' },
  selection: { marginTop: 6, color: night.textPrimary, fontFamily: fonts.operational, fontSize: 12 },
  selectionMeta: { color: night.textTertiary, fontSize: 11 },
});
