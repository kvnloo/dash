/**
 * TopologyIslands: each chat that delegated is an island, drawn as its glyph.
 * From zerOS HarnessTopologyGraph, compacted: the island is the glyph, its
 * name and one quiet line; tap the glyph and it decomposes into its members.
 * A summary strip counts islands per AODL topology.
 */
import React, { useMemo } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { topologyOf, type TopologyId } from '../aodl/encodings';
import { compressGraph } from '../model/compress';
import { ago } from '../model/decay';
import { night, radius } from '../tokens';
import { fonts } from '../fonts';
import type { OrchestrationGraph, OrchestrationNode } from '../model/types';
import { DecomposingGlyph } from './DecomposingGlyph';
import { liveGlyph } from './glyph-data';
import { TopologyGlyph } from './TopologyGlyph';
import { AgentThinking } from './AgentThinking';

export interface TopologyIslandsProps {
  graph: OrchestrationGraph;
  width: number;
  max?: number;
  onInspect?: (node: OrchestrationNode) => void;
  testID?: string;
}

export function TopologyIslands({ graph, width, max = 6, onInspect, testID }: TopologyIslandsProps) {
  const { islands, counts } = useMemo(() => {
    const chats = graph.nodes.filter((n) => n.role === 'chat');
    const all = chats.map((c) => ({ chat: c, glyph: liveGlyph(graph, c.id, compressGraph(graph, c.id)) }));
    const counts = new Map<TopologyId, number>();
    for (const i of all) counts.set(i.glyph.compressed.topologyId, (counts.get(i.glyph.compressed.topologyId) || 0) + 1);
    const islands = all
      .filter((i) => i.glyph.members.length > 1)
      .sort((a, b) =>
        b.glyph.members.filter((m) => m.state === 'running').length - a.glyph.members.filter((m) => m.state === 'running').length
        || (b.chat.lastActivity || 0) - (a.chat.lastActivity || 0))
      .slice(0, max);
    return { islands, counts };
  }, [graph, max]);

  const cols = width >= 760 ? 2 : 1;
  const gap = 12;
  const cardW = Math.floor((width - gap * (cols - 1)) / cols);
  const inner = cardW - 28;

  return (
    <View style={{ width }} testID={testID}>
      <View style={styles.strip}>
        {[...counts.entries()].sort((a, b) => b[1] - a[1]).map(([id, n]) => (
          <View key={id} style={styles.chip}>
            <TopologyGlyph topologyId={id} size={16} providerId="unknown" state="paused" />
            <Text style={styles.chipText}>{`${topologyOf(id).label} ${n}`}</Text>
          </View>
        ))}
      </View>
      <View style={[styles.grid, { gap }]}>
        {islands.map(({ chat, glyph }) => {
          const live = glyph.members.filter((m) => m.state === 'running').length;
          return (
            <View key={chat.id} style={[styles.card, { width: cardW }]}>
              <DecomposingGlyph
                graph={graph}
                rootId={chat.id}
                width={inner}
                size={40}
                onInspect={onInspect}
                height={Math.round(Math.min(300, Math.max(190, inner * 0.62)))}
                header={(
                  <View style={styles.headRow}>
                    <View style={{ flex: 1 }}>
                    <Text style={styles.title} numberOfLines={1}>{chat.label}</Text>
                    <Text style={styles.meta} numberOfLines={1}>
                      {`${topologyOf(glyph.compressed.topologyId).label} · ${live}/${glyph.members.length} live · ${ago(chat.lastActivity, graph.generatedAt)}`}
                    </Text>
                    </View>
                    {chat.state === 'running' && chat.phase ? <AgentThinking phase={chat.phase} tool={chat.tool} size={20} /> : null}
                  </View>
                )}
              />
            </View>
          );
        })}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  strip: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 12 },
  chip: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 8, paddingVertical: 4, borderRadius: radius.pill, borderWidth: 1, borderColor: night.borderQuiet },
  chipText: { color: night.textTertiary, fontFamily: fonts.operational, fontSize: 11 },
  grid: { flexDirection: 'row', flexWrap: 'wrap' },
  card: { backgroundColor: night.glass, borderColor: night.borderSubtle, borderWidth: 1, borderRadius: radius.sheet, padding: 14 },
  headRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  title: { color: night.textPrimary, fontFamily: fonts.operational, fontSize: 14 },
  meta: { color: night.textTertiary, fontFamily: fonts.operational, fontSize: 11, marginTop: 2 },
});
