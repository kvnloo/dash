/**
 * TreeView: two collapsible trees from one graph.
 *  sessions:  host -> chat -> subagents (nested by delegation); each chat
 *             carries its glyph (delegation subtree compressed via AODL).
 *  worktrees: repo -> trunk -> integration -> feature packs -> leaves
 *             (zerOS WorktreeLadderPanel, by branch name; no invented merges).
 */
import React, { useMemo, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import Svg, { Path } from 'react-native-svg';
import { ago } from '../model/decay';
import { sessionTree, worktreeTree, type TreeItem } from '../model/tree';
import { night } from '../tokens';
import { fonts } from '../fonts';
import type { OrchestrationGraph, OrchestrationNode } from '../model/types';
import { liveGlyph } from './glyph-data';
import { TopologyGlyph } from './TopologyGlyph';
import { StateDot } from './ui';

export interface TreeViewProps {
  graph: OrchestrationGraph;
  which: 'sessions' | 'worktrees';
  width: number;
  /** Rows shown per level before "+ n more". */
  pageSize?: number;
  /** Ids open at start; default: first root and its first child. */
  initiallyOpen?: string[];
  onSelect?: (node: OrchestrationNode) => void;
  testID?: string;
}

function Chevron({ open }: { open: boolean }) {
  return (
    <Svg width={10} height={10} style={{ transform: [{ rotate: open ? '90deg' : '0deg' }] }}>
      <Path d="M3 1.5 7 5 3 8.5" stroke={night.textTertiary} strokeWidth={1.3} fill="none" strokeLinecap="round" strokeLinejoin="round" />
    </Svg>
  );
}

export function TreeView({ graph, which, width, pageSize = 8, initiallyOpen, onSelect, testID }: TreeViewProps) {
  const roots = useMemo(() => (which === 'sessions' ? sessionTree(graph) : worktreeTree(graph)), [graph, which]);
  const [open, setOpen] = useState<Set<string>>(() => {
    if (initiallyOpen) return new Set(initiallyOpen);
    const s = new Set<string>();
    if (roots[0]) {
      s.add(roots[0].id);
      if (which === 'worktrees') roots[0].children.slice(0, 3).forEach((c) => s.add(c.id));
      else {
        const firstWithKids = roots[0].children.find((c) => c.children.length);
        if (firstWithKids) s.add(firstWithKids.id);
      }
    }
    return s;
  });
  const [more, setMore] = useState<Set<string>>(new Set());
  const narrow = width < 480;
  const now = graph.generatedAt;
  const toggle = (id: string) => setOpen((prev) => {
    const next = new Set(prev);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    return next;
  });

  const rows: React.ReactNode[] = [];
  const walk = (items: TreeItem[], depth: number, parentId: string) => {
    const limit = more.has(parentId) ? items.length : pageSize;
    items.slice(0, limit).forEach((item) => {
      const isOpen = open.has(item.id);
      rows.push(<Row key={item.id} item={item} depth={depth} open={isOpen} onToggle={() => toggle(item.id)} onSelect={onSelect} graph={graph} now={now} narrow={narrow} />);
      if (isOpen && item.children.length) walk(item.children, depth + 1, item.id);
    });
    if (items.length > limit) {
      rows.push(
        <Pressable key={`${parentId}:more`} onPress={() => setMore(new Set([...more, parentId]))} style={[styles.row, { paddingLeft: 12 + depth * 16 }]} accessibilityRole="button">
          <Text style={styles.more}>{`+ ${items.length - limit} more`}</Text>
        </Pressable>,
      );
    }
  };
  walk(roots, 0, 'root');

  return (
    <View style={[styles.wrap, { width }]} testID={testID} accessibilityRole="list">
      {rows.length ? rows : <Text style={styles.empty}>{which === 'sessions' ? 'No sessions in this snapshot.' : 'No worktrees in this snapshot.'}</Text>}
    </View>
  );
}

function Row({ item, depth, open, onToggle, onSelect, graph, now, narrow }: {
  item: TreeItem;
  depth: number;
  open: boolean;
  onToggle: () => void;
  onSelect?: (n: OrchestrationNode) => void;
  graph: OrchestrationGraph;
  now: number;
  narrow: boolean;
}) {
  const hasKids = item.children.length > 0;
  const n = item.node;
  const glyph = item.type === 'chat' && item.topology && item.topology.memberIds.length > 1 ? liveGlyph(graph, item.id, item.topology) : null;
  const isGroup = item.type === 'host' || item.type === 'repo' || item.type === 'tier' || item.type === 'pack';
  let meta = '';
  if (item.type === 'host') meta = `${item.count} sessions${item.live ? ` · ${item.live} live` : ''}`;
  if (item.type === 'chat' && item.count) meta = `${item.count} sub${item.live ? ` · ${item.live} live` : ''}`;
  if (item.type === 'repo' || item.type === 'tier' || item.type === 'pack') meta = String(item.count);
  if ((item.type === 'chat' || item.type === 'subagent') && n?.lastActivity) meta = `${meta ? `${meta} · ` : ''}${ago(n.lastActivity, now)}`;
  if (item.type === 'worktree') meta = n?.meta?.head ? n.meta.head.slice(0, 7) : '';

  const label = item.type === 'worktree' ? (n?.meta?.branch || item.label) : item.label;
  const sub = item.type === 'worktree' && n?.meta?.branch && n.label !== n.meta.branch.split('/').pop() ? n.label : '';

  return (
    <Pressable
      onPress={hasKids ? onToggle : n ? () => onSelect?.(n) : undefined}
      onLongPress={n ? () => onSelect?.(n) : undefined}
      style={({ pressed }) => [styles.row, { paddingLeft: 8 + depth * 16 }, pressed && styles.pressed]}
      accessibilityRole={hasKids ? 'button' : 'text'}
      accessibilityState={hasKids ? { expanded: open } : undefined}
    >
      <View style={styles.chev}>{hasKids ? <Chevron open={open} /> : null}</View>
      {glyph ? (
        <View style={styles.glyph}><TopologyGlyph {...glyph.props} size={16} /></View>
      ) : n && (item.type === 'chat' || item.type === 'subagent' || item.type === 'host') ? (
        <View style={styles.dot}><StateDot state={n.state} /></View>
      ) : null}
      <View style={styles.text}>
        <Text
          numberOfLines={1}
          style={[
            styles.label,
            isGroup && styles.groupLabel,
            item.type === 'tier' && styles.tierLabel,
            (item.type === 'worktree' || item.type === 'pack') && styles.mono,
            n?.meta?.primary && { color: night.actionStrong },
          ]}
        >
          {label}
        </Text>
        {sub && !narrow ? <Text numberOfLines={1} style={styles.sub}>{sub}</Text> : null}
      </View>
      {meta ? <Text style={styles.meta}>{meta}</Text> : null}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  wrap: { borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: night.borderQuiet },
  row: { flexDirection: 'row', alignItems: 'center', minHeight: 32, paddingRight: 8, borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: night.borderQuiet },
  pressed: { backgroundColor: 'rgba(236,232,223,0.04)' },
  chev: { width: 14, alignItems: 'center' },
  glyph: { width: 30, alignItems: 'center' },
  dot: { width: 30, alignItems: 'center' },
  text: { flex: 1, flexDirection: 'row', alignItems: 'baseline', gap: 8, overflow: 'hidden' },
  label: { color: night.textPrimary, fontFamily: fonts.operational, fontSize: 13, flexShrink: 1 },
  groupLabel: { color: night.textSecondary },
  tierLabel: { color: night.textTertiary, fontSize: 11, textTransform: 'uppercase', letterSpacing: 1 },
  mono: { fontFamily: fonts.telemetry, fontSize: 12, color: night.textSecondary },
  sub: { color: night.textFaint, fontFamily: fonts.operational, fontSize: 11, flexShrink: 2 },
  meta: { color: night.textFaint, fontFamily: fonts.telemetry, fontSize: 10, marginLeft: 8 },
  more: { color: night.actionMuted, fontFamily: fonts.operational, fontSize: 12, paddingLeft: 22 },
  empty: { color: night.textTertiary, fontFamily: fonts.operational, fontSize: 12, padding: 12 },
});
