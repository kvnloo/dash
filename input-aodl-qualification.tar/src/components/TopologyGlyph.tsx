/**
 * TopologyGlyph: the icon/badge form of an orchestration graph.
 *
 * Shape  = AODL topology silhouette (topology-graphs.json), never redrawn.
 * Hue    = provider hue per node (visual.json providers); ghost = no member.
 * Motion = AODL runtime cadence (running flows, claimed slower, paused/stale
 *          still, blocked pulses a warning) scaled by activity.
 * At 40 px it also carries the operating-mode rune and the runtime-state marker.
 */
import React, { useMemo } from 'react';
import Svg, { Circle, G, Line, Path, Rect, Text as SvgText } from 'react-native-svg';
import {
  operatingModeOf,
  providerHue,
  silhouette,
  SILHOUETTE_H,
  SILHOUETTE_W,
  silhouetteNodeHue,
  topologyOf,
  type OperatingModeId,
  type ProviderId,
  type RuntimeStateId,
  type TopologyId,
} from '../aodl/encodings';
import { CADENCE, desaturate, useClock, withAlpha } from '../motion/cadence';
import { night } from '../tokens';
import { BreathRing, FlowDot, lineAsBezier } from './svg-motion';

export type GlyphSize = 16 | 24 | 40;

export interface GlyphNodeFill {
  hue: string;
  state?: RuntimeStateId;
}

export interface TopologyGlyphProps {
  topologyId: TopologyId;
  size?: GlyphSize;
  providerId?: ProviderId;
  state?: RuntimeStateId;
  /** 0..1: how busy the graph is right now. Scales flow speed and particle count. */
  activity?: number;
  /** Per silhouette node: a fill, or null for a ghost (silhouette slot with no member). */
  nodes?: Array<GlyphNodeFill | null>;
  /** Members the silhouette could not hold. Shown as +n at 40 px. */
  overflow?: number;
  operatingModeId?: OperatingModeId;
  label?: string;
  testID?: string;
}

export const glyphWidth = (size: number) => Math.round((size * SILHOUETTE_W) / SILHOUETTE_H);

/** Rune paths in a 10x10 box (operating modes). */
const MODE_RUNES: Partial<Record<string, string>> = {
  link: 'M5.3 5a2.2 2.2 0 1 1-4.4 0a2.2 2.2 0 1 1 4.4 0M9.1 5a2.2 2.2 0 1 1-4.4 0a2.2 2.2 0 1 1 4.4 0',
  crescent: 'M6.6 1.3a3.8 3.8 0 1 0 0 7.4a3 3 0 1 1 0-7.4z',
  cycle: 'M8.2 5.4a3.3 3.3 0 1 1-1.1-2.9M7.4 1.1v1.9h1.9',
  fork: 'M5 9.2V5.6M5 5.6L2.2 1.6M5 5.6l2.8-4',
  stack: 'M1.6 2.6h6.8M1.6 5h6.8M1.6 7.4h6.8',
};

function StateMarker({ state, x, y, s }: { state: RuntimeStateId; x: number; y: number; s: number }) {
  const c = CADENCE[state].accent;
  const w = 1 / s;
  const r = 2.4;
  switch (state) {
    case 'running':
      return null; // running is carried by motion, not a badge
    case 'claimed':
      return <Circle cx={x} cy={y} r={r} fill="none" stroke={c} strokeWidth={w} />;
    case 'paused':
      return (
        <G>
          <Rect x={x - 2} y={y - 2.2} width={1.4} height={4.4} fill={c} />
          <Rect x={x + 0.6} y={y - 2.2} width={1.4} height={4.4} fill={c} />
        </G>
      );
    case 'stale':
      return <Circle cx={x} cy={y} r={r} fill="none" stroke={c} strokeWidth={w} strokeDasharray={`${1.2} ${1}`} />;
    case 'blocked':
      return <Path d={`M${x} ${y - 2.6}L${x + 2.6} ${y}L${x} ${y + 2.6}L${x - 2.6} ${y}Z`} fill={c} />;
    default:
      return null;
  }
}

export function TopologyGlyph({
  topologyId,
  size = 24,
  providerId = 'unknown',
  state = 'running',
  activity = 0.6,
  nodes,
  overflow = 0,
  operatingModeId = 'unknown',
  label,
  testID,
}: TopologyGlyphProps) {
  const sil = useMemo(() => silhouette(topologyId), [topologyId]);
  const cadence = CADENCE[state];
  const w = glyphWidth(size);
  const h = size;
  const pad = size <= 16 ? 0.5 : size <= 24 ? 1 : 2;
  const s = Math.min((w - 2 * pad) / SILHOUETTE_W, (h - 2 * pad) / SILHOUETTE_H);
  const ox = (w - SILHOUETTE_W * s) / 2;
  const oy = (h - SILHOUETTE_H * s) / 2;
  const px = (n: number) => n / s; // convert screen px to silhouette units
  const animate = cadence.speed > 0 && sil.nodes.length > 0;
  const { t, reduced } = useClock(animate);
  const moving = animate && !reduced;
  const topology = topologyOf(topologyId);

  const fills = sil.nodes.map((_, i) => {
    if (nodes) return nodes[i] ?? null;
    return { hue: silhouetteNodeHue(providerId, i) } as GlyphNodeFill;
  });
  const tone = (hue: string, st?: RuntimeStateId) => {
    const c = CADENCE[st || state];
    return desaturate(hue, Math.max(cadence.desaturate, c.desaturate));
  };
  const edgeHue = providerId === 'unknown' && nodes?.find(Boolean) ? nodes.find(Boolean)!.hue : providerHue(providerId);
  const edgeColor = withAlpha(tone(edgeHue), size <= 16 ? 0.55 : 0.42);
  const strokeW = px(size <= 16 ? 0.7 : size <= 24 ? 0.8 : 1);
  const dash = sil.soft || cadence.dashed ? `${px(1.4)} ${px(1.6)}` : undefined;
  const at = (i: number) => sil.nodes[i] || [36, 22, 0];
  const speed = (0.35 + 0.75 * Math.max(0, Math.min(1, activity))) * cadence.speed;
  const flowEdges = size >= 24 && moving ? sil.edges.slice(0, size >= 40 ? 10 : 6) : [];
  const envelopeColor = withAlpha(topology.nodeAccent, 0.28);
  const a11y = label || `${topology.label} topology, ${state}`;

  return (
    <Svg width={w} height={h} accessibilityLabel={a11y} accessibilityRole="image" testID={testID} opacity={cadence.opacity}>
      <G transform={`translate(${ox} ${oy}) scale(${s})`}>
        {sil.envelope === 'council' ? <Circle cx={36} cy={22} r={18} fill="none" stroke={envelopeColor} strokeWidth={strokeW} /> : null}
        {sil.envelope === 'supervisor' ? <Circle cx={36} cy={22} r={19} fill="none" stroke={withAlpha(night.danger, 0.4)} strokeWidth={strokeW} /> : null}
        {sil.envelope === 'marketplace' ? <Circle cx={36} cy={22} r={18} fill="none" stroke={envelopeColor} strokeWidth={strokeW} strokeDasharray={`${px(1.5)} ${px(1.5)}`} /> : null}
        {sil.envelope === 'cluster' ? (
          <G fill="none" stroke={envelopeColor} strokeWidth={strokeW}>
            <Circle cx={16} cy={16} r={12} />
            <Circle cx={50} cy={15} r={12} />
            <Circle cx={34} cy={34} r={11} />
          </G>
        ) : null}

        {sil.edges.map(([a, b], i) => {
          const [x1, y1] = at(a);
          const [x2, y2] = at(b);
          const ghost = !fills[a] || !fills[b];
          return (
            <Line
              key={`e${i}`}
              x1={x1}
              y1={y1}
              x2={x2}
              y2={y2}
              stroke={ghost ? withAlpha(night.textFaint, 0.5) : edgeColor}
              strokeWidth={strokeW}
              strokeDasharray={ghost ? `${px(0.8)} ${px(1.4)}` : dash}
              strokeLinecap="round"
            />
          );
        })}
        {sil.directed && size >= 24
          ? sil.edges.map(([a, b], i) => {
            const [x1, y1] = at(a);
            const [x2, y2, r2] = at(b);
            const ang = Math.atan2(y2 - y1, x2 - x1);
            const tipX = x2 - Math.cos(ang) * (r2 + px(0.8));
            const tipY = y2 - Math.sin(ang) * (r2 + px(0.8));
            const k = px(size >= 40 ? 2.6 : 2);
            const l = { x: tipX - Math.cos(ang - 0.5) * k, y: tipY - Math.sin(ang - 0.5) * k };
            const r = { x: tipX - Math.cos(ang + 0.5) * k, y: tipY - Math.sin(ang + 0.5) * k };
            return <Path key={`a${i}`} d={`M${tipX} ${tipY}L${l.x} ${l.y}L${r.x} ${r.y}Z`} fill={edgeColor} />;
          })
          : null}

        {flowEdges.map(([a, b], i) => {
          const [x1, y1] = at(a);
          const [x2, y2] = at(b);
          if (!fills[a] || !fills[b]) return null;
          return (
            <FlowDot
              key={`f${i}`}
              t={t}
              curve={lineAsBezier(x1, y1, x2, y2)}
              speed={speed * 0.55}
              phase={(i * 0.37) % 1}
              r={px(size >= 40 ? 1.1 : 0.85)}
              color={withAlpha(night.textPrimary, 0.9)}
            />
          );
        })}

        {sil.center === 'blackboard' ? (
          <G fill="none" stroke={withAlpha(topology.nodeAccent, 0.75)} strokeWidth={strokeW}>
            <Rect x={27} y={14} width={18} height={16} rx={2} fill={withAlpha(night.canvas, 0.9)} />
            {size >= 24 ? <Path d="M31 19h10M31 22h10M31 25h7" /> : null}
          </G>
        ) : null}
        {sil.center === 'marketplace' ? (
          <Path d="M36 14 44 22 36 30 28 22Z" fill={withAlpha(night.canvas, 0.9)} stroke={withAlpha(topology.nodeAccent, 0.8)} strokeWidth={strokeW} />
        ) : null}
        {sil.center === 'unknown' ? (
          <G fill="none" stroke={withAlpha(night.textTertiary, 0.9)} strokeWidth={px(size <= 16 ? 0.8 : 1)} strokeLinecap="round" strokeLinejoin="round">
            <Path d="M28 14 36 8l8 6v16l-8 6-8-6Z" />
            <Path d="M33 18c0-2 1.4-3.4 3.5-3.4 2 0 3.5 1.2 3.5 3.1 0 3-3.6 3-3.6 6M36.4 28h.1" />
          </G>
        ) : null}

        {sil.nodes.map(([x, y, r], i) => {
          if (sil.centerIndex === i) return null; // drawn as the blackboard / market centre
          const f = fills[i];
          const rr = Math.max(r, px(size <= 16 ? 0.9 : 1.1));
          if (!f) {
            return <Circle key={`n${i}`} cx={x} cy={y} r={rr * 0.8} fill="none" stroke={withAlpha(night.textFaint, 0.8)} strokeWidth={px(0.6)} />;
          }
          const hue = tone(f.hue, f.state);
          const hollow = i === 0 && cadence.hollowHub;
          return (
            <Circle
              key={`n${i}`}
              cx={x}
              cy={y}
              r={rr}
              fill={hollow ? 'none' : hue}
              stroke={hollow ? hue : withAlpha(night.canvas, 0.6)}
              strokeWidth={hollow ? px(1) : px(0.4)}
            />
          );
        })}

        {moving && sil.nodes.length && fills[0] ? (
          <BreathRing
            t={t}
            cx={at(0)[0]}
            cy={at(0)[1]}
            r={at(0)[2] + px(0.6)}
            spread={px(size >= 40 ? 3.2 : 2)}
            period={3.6 / Math.max(0.3, cadence.speed)}
            color={tone(fills[0]!.hue)}
            width={px(0.7)}
            maxOpacity={0.55}
          />
        ) : null}
        {cadence.warning && !reduced ? (
          <BreathRing t={t} cx={36} cy={22} r={19} spread={px(1)} period={5.8} color={night.danger} width={px(1)} minOpacity={0.24} maxOpacity={0.56} />
        ) : null}
        {cadence.warning && reduced ? <Circle cx={36} cy={22} r={19} fill="none" stroke={withAlpha(night.danger, 0.5)} strokeWidth={px(1)} /> : null}
      </G>

      {size >= 40 && MODE_RUNES[operatingModeOf(operatingModeId).marker] ? (
        <G transform={`translate(1 1) scale(${0.9})`}>
          <Path
            d={MODE_RUNES[operatingModeOf(operatingModeId).marker]!}
            fill={operatingModeOf(operatingModeId).marker === 'crescent' ? operatingModeOf(operatingModeId).accent : 'none'}
            stroke={operatingModeOf(operatingModeId).accent}
            strokeWidth={1}
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </G>
      ) : null}
      {size >= 40 ? (
        <G transform={`translate(${w - 5} ${h - 5}) scale(1)`}>
          <StateMarker state={state} x={0} y={0} s={1} />
        </G>
      ) : null}
      {size >= 40 && overflow > 0 ? (
        <SvgText x={w - 2} y={9} fontSize={8} fill={night.textTertiary} textAnchor="end" fontFamily="IBM Plex Mono, ui-monospace, monospace">
          {`+${overflow}`}
        </SvgText>
      ) : null}
    </Svg>
  );
}
