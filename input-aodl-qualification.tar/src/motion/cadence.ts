/**
 * Runtime cadence: AODL `runtimeStates` -> how a drawing moves.
 * Mirrors the zerOS agent-core-language.css cadence: running flows, claimed
 * flows 2.2x slower with a hollow hub, paused and stale hold still (stale is
 * dashed and faded), blocked holds still behind a slow warning pulse, unknown
 * holds still.
 */
import { useEffect } from 'react';
import { useFrameCallback, useReducedMotion, useSharedValue, type SharedValue } from 'react-native-reanimated';
import { runtimeStateOf, type RuntimeStateId } from '../aodl/encodings';

export interface Cadence {
  /** Flow speed multiplier; 0 = no flow. */
  speed: number;
  opacity: number;
  /** 0..1 toward neutral grey. */
  desaturate: number;
  dashed: boolean;
  hollowHub: boolean;
  warning: boolean;
  accent: string;
}

export const CADENCE: Record<RuntimeStateId, Cadence> = {
  running: { speed: 1, opacity: 1, desaturate: 0, dashed: false, hollowHub: false, warning: false, accent: runtimeStateOf('running').accent },
  claimed: { speed: 1 / 2.2, opacity: 0.9, desaturate: 0.1, dashed: false, hollowHub: true, warning: false, accent: runtimeStateOf('claimed').accent },
  paused: { speed: 0, opacity: 0.7, desaturate: 0.65, dashed: false, hollowHub: false, warning: false, accent: runtimeStateOf('paused').accent },
  stale: { speed: 0, opacity: 0.5, desaturate: 0.85, dashed: true, hollowHub: false, warning: false, accent: runtimeStateOf('stale').accent },
  blocked: { speed: 0, opacity: 0.8, desaturate: 0.45, dashed: false, hollowHub: false, warning: true, accent: runtimeStateOf('blocked').accent },
  unknown: { speed: 0, opacity: 0.7, desaturate: 0.5, dashed: false, hollowHub: false, warning: false, accent: runtimeStateOf('unknown').accent },
};

const hex = (c: string) => {
  const m = /^#?([0-9a-f]{6})$/i.exec(c.trim());
  if (!m) return null;
  const n = parseInt(m[1], 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
};

/** Mix a hue toward the AODL neutral (#9ca39a) by `amount`. */
export function desaturate(color: string, amount: number): string {
  const a = hex(color);
  const b = hex('#9ca39a')!;
  if (!a || amount <= 0) return color;
  const k = Math.min(1, amount);
  const out = a.map((v, i) => Math.round(v + (b[i] - v) * k));
  return `#${out.map((v) => v.toString(16).padStart(2, '0')).join('')}`;
}

export function withAlpha(color: string, alpha: number): string {
  const a = hex(color);
  if (!a) return color;
  return `rgba(${a[0]},${a[1]},${a[2]},${Math.max(0, Math.min(1, alpha)).toFixed(3)})`;
}

/**
 * One frame clock (seconds) per drawing, driven on the UI thread by
 * Reanimated. Stops when inactive or when the OS asks for reduced motion.
 */
export function useClock(active: boolean): { t: SharedValue<number>; reduced: boolean } {
  const reduced = useReducedMotion();
  const t = useSharedValue(0);
  const frame = useFrameCallback((info) => {
    t.value = (info.timeSinceFirstFrame || 0) / 1000;
  }, false);
  useEffect(() => {
    frame.setActive(active && !reduced);
    return () => frame.setActive(false);
  }, [active, reduced, frame]);
  return { t, reduced };
}
