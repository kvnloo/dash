// Metro sees the library source one directory up (the repo root).
const path = require('path');
const { getDefaultConfig } = require('expo/metro-config');

const projectRoot = __dirname;
const repoRoot = path.resolve(projectRoot, '..');
const config = getDefaultConfig(projectRoot);
config.watchFolders = [repoRoot];
config.resolver.nodeModulesPaths = [path.resolve(repoRoot, 'node_modules')];
config.resolver.disableHierarchicalLookup = true;
module.exports = config;
