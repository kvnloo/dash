/**
 * aodl-views gallery. Every component on the live Hermes snapshot
 * (public/live.json, written by scripts/live-snapshot.py), next to the zerOS
 * view it came from (captured PNGs of the legacy gallery), plus a 390 px
 * phone column. Built with Expo for web (react-native-web).
 */
import React, { useEffect, useMemo, useState } from 'react';
import { Image, Linking, Platform, Pressable, ScrollView, StyleSheet, Text, useWindowDimensions, View } from 'react-native';

// On web the document scrolls (so full-page captures and anchors work); native uses a ScrollView.
const Scroll = Platform.OS === 'web' ? (({ contentContainerStyle, children }: { contentContainerStyle?: object; children: React.ReactNode }) => <View style={contentContainerStyle}>{children}</View>) : ScrollView;
import {
  aodlSource,
  AgentThinking,
  ago,
  ALL_ORB_TYPES,
  compressGraph,
  DecomposingGlyph,
  fromLiveSnapshot,
  GraphView,
  InspectCard,
  night,
  RepoMap,
  TOPOLOGY_IDS,
  topologyOf,
  topologyStatus,
  TopologyGlyph,
  TopologyIslands,
  TreeView,
  type OrchestrationGraph,
  type OrchestrationNode,
  type RuntimeStateId,
  type ThinkingPhase,
} from '../src';
import { fonts } from '../src/fonts';
import { OrbRenderer } from '../src/thinking/orb-renderer';

const ORIGINALS: Record<string, { w: number; h: number; title: string }> = {
  graph: { w: 948, h: 1162, title: 'SystemNetworkGraph' },
  tree: { w: 948, h: 1361, title: 'WorktreeLadderPanel' },
  topology: { w: 948, h: 1400, title: 'HarnessTopologyGraph' },
  chat: { w: 948, h: 412, title: 'ChatRepoMap prototype' },
  orbs: { w: 948, h: 487, title: 'VoiceOrbAvatar' },
};

function Section({ n, title, line, children, id }: { n: number; title: string; line: string; children: React.ReactNode; id: string }) {
  return (
    <View style={styles.section} nativeID={id} testID={`section-${id}`}>
      <View style={styles.sectionHead}>
        <Text style={styles.sectionNum}>{String(n).padStart(2, '0')}</Text>
        <Text style={styles.sectionTitle}>{title}</Text>
      </View>
      <Text style={styles.sectionLine}>{line}</Text>
      {children}
    </View>
  );
}

function Original({ id, width }: { id: keyof typeof ORIGINALS; width: number }) {
  const o = ORIGINALS[id];
  const full = (width * o.h) / o.w;
  const h = Math.min(520, full);
  return (
    <View style={{ width }} testID={`original-${id}`}>
      <Text style={styles.colLabel}>{`zerOS original · ${o.title} · captured`}</Text>
      <View style={[styles.originalFrame, { height: h }]}>
        <Image source={{ uri: `/originals/zeros-${id}.png` }} style={{ width, height: full }} resizeMode="cover" accessibilityLabel={`zerOS ${o.title}, captured`} />
      </View>
      <Pressable onPress={() => Linking.openURL(`/legacy/gallery.html#${id}`)}>
        <Text style={styles.link}>open the live original in /legacy/</Text>
      </Pressable>
    </View>
  );
}

function Compare({ id, contentW, children }: { id: keyof typeof ORIGINALS; contentW: number; children: (w: number) => React.ReactNode }) {
  const wide = contentW >= 900;
  const origW = wide ? Math.round(contentW * 0.32) : contentW;
  const newW = wide ? contentW - origW - 28 : contentW;
  return (
    <View style={wide ? { flexDirection: 'row', gap: 28 } : undefined}>
      {wide ? <Original id={id} width={origW} /> : null}
      <View style={{ width: newW }}>
        <Text style={[styles.colLabel, styles.colLabelNew]}>aodl-views · live</Text>
        {children(newW)}
      </View>
      {!wide ? <View style={{ marginTop: 26 }}><Original id={id} width={origW} /></View> : null}
    </View>
  );
}

const STATES: RuntimeStateId[] = ['running', 'claimed', 'paused', 'stale', 'blocked', 'unknown'];

function GlyphCatalog({ width }: { width: number }) {
  const cols = width >= 900 ? 4 : width >= 560 ? 3 : 2;
  const cellW = Math.floor((width - (cols - 1) * 10) / cols);
  return (
    <View style={styles.catalog}>
      {TOPOLOGY_IDS.map((id) => {
        const status = topologyStatus(id);
        return (
          <View key={id} style={[styles.cell, { width: cellW }]} testID={`glyph-${id}`}>
            <View style={styles.cellGlyphs}>
              <TopologyGlyph topologyId={id} size={40} providerId="multi" state="running" />
              <TopologyGlyph topologyId={id} size={24} providerId="anthropic" state="running" />
              <TopologyGlyph topologyId={id} size={16} providerId="openai" state="running" />
            </View>
            <Text style={styles.cellTitle}>{topologyOf(id).label}</Text>
            <Text style={[styles.cellMeta, status !== 'expressible' && { color: night.warning }]}>{status}</Text>
          </View>
        );
      })}
    </View>
  );
}

function CadenceRow() {
  return (
    <View style={styles.cadence}>
      {STATES.map((s) => (
        <View key={s} style={styles.cadenceCell} testID={`cadence-${s}`}>
          <TopologyGlyph topologyId="star" size={40} providerId="anthropic" state={s} operatingModeId="copilot" />
          <Text style={styles.cellMeta}>{s}</Text>
        </View>
      ))}
    </View>
  );
}

const THINKING: Array<{ phase: ThinkingPhase; tool?: string; intent?: 'planning' | 'solving' | 'voice'; note: string }> = [
  { phase: 'idle', note: 'idle' },
  { phase: 'thinking', note: 'thinking' },
  { phase: 'thinking', intent: 'planning', note: 'thinking · planning' },
  { phase: 'thinking', intent: 'solving', note: 'thinking · solving' },
  { phase: 'tool', tool: 'terminal', note: 'tool' },
  { phase: 'tool', tool: 'web_search', note: 'tool · search' },
  { phase: 'tool', tool: 'patch', note: 'tool · edit' },
  { phase: 'streaming', note: 'streaming' },
  { phase: 'streaming', intent: 'voice', note: 'streaming · voice' },
  { phase: 'waiting-approval', note: 'waiting-approval' },
];

function ThinkingPanel({ width }: { width: number }) {
  const cols = width >= 700 ? 5 : width >= 480 ? 4 : 2;
  const cellW = Math.floor((width - (cols - 1) * 10) / cols);
  return (
    <View>
      <View style={styles.catalog}>
        {THINKING.map((s) => (
          <View key={s.note} style={[styles.cell, styles.orbCell, { width: cellW }]} testID={`thinking-${s.note}`}>
            <AgentThinking phase={s.phase} tool={s.tool} intent={s.intent} size={64} caption />
            <Text style={styles.cellMeta}>{s.note}</Text>
          </View>
        ))}
      </View>
      <Text style={[styles.colLabel, { marginTop: 20 }]}>all nine orb types · 20 px inline</Text>
      <View style={styles.inlineOrbs}>
        {ALL_ORB_TYPES.map((o) => (
          <View key={o} style={styles.inlineOrb}>
            <OrbRenderer state={o} size={20} theme="dark" />
            <Text style={styles.cellMeta}>{o}</Text>
          </View>
        ))}
      </View>
    </View>
  );
}

function PhoneColumn({ graph, focusChat }: { graph: OrchestrationGraph; focusChat: string | null }) {
  const inner = 390 - 32;
  return (
    <View style={styles.phone} testID="phone-column">
      <Text style={styles.phoneTitle}>PHONE · 390</Text>
      {focusChat ? (
        <View style={styles.phoneBlock}>
          <DecomposingGlyph graph={graph} rootId={focusChat} width={inner} header={<GlyphHeader graph={graph} id={focusChat} />} />
        </View>
      ) : null}
      <View style={styles.phoneBlock}><GraphView graph={graph} width={inner} height={420} initialFocusId={focusChat} /></View>
      <View style={styles.phoneBlock}><TreeView graph={graph} which="sessions" width={inner} pageSize={6} /></View>
      <View style={styles.phoneBlock}><TopologyIslands graph={graph} width={inner} max={3} /></View>
      <View style={styles.phoneBlock}><RepoMap graph={graph} width={inner} height={320} /></View>
      <View style={[styles.phoneBlock, styles.phoneOrbs]}>
        {(['thinking', 'tool', 'streaming', 'waiting-approval'] as const).map((p) => (
          <AgentThinking key={p} phase={p} tool={p === 'tool' ? 'terminal' : undefined} size={20} caption />
        ))}
      </View>
    </View>
  );
}

function GlyphHeader({ graph, id }: { graph: OrchestrationGraph; id: string }) {
  const n = graph.nodes.find((x) => x.id === id)!;
  const t = compressGraph(graph, id);
  const members = graph.nodes.filter((x) => t.memberIds.includes(x.id));
  return (
    <View>
      <Text style={styles.gTitle} numberOfLines={1}>{n.label}</Text>
      <Text style={styles.gMeta} numberOfLines={1}>
        {`${topologyOf(t.topologyId).label} · ${members.filter((m) => m.state === 'running').length}/${members.length} live`}
      </Text>
    </View>
  );
}

export default function App() {
  const { width } = useWindowDimensions();
  const [raw, setRaw] = useState<unknown>(null);
  const [error, setError] = useState<string | null>(null);
  const [inspect, setInspect] = useState<OrchestrationNode | null>(null);
  useEffect(() => {
    // The real snapshot is private and never committed; the sample keeps CI and fresh clones working.
    fetch('/live.json', { cache: 'no-store' })
      .then((r) => (r.ok ? r.json() : fetch('/live.sample.json').then((x) => x.json())))
      .then(setRaw)
      .catch((e) => setError(String(e)));
  }, []);
  const graph = useMemo(() => (raw ? fromLiveSnapshot(raw, { excludeSources: ['oneshot', 'cron'], maxChats: 40 }) : null), [raw]);
  const picks = useMemo(() => {
    if (!graph) return { focus: null as string | null, second: null as string | null };
    const chats = graph.nodes.filter((n) => n.role === 'chat').map((c) => ({ c, t: compressGraph(graph, c.id) }));
    const ranked = [...chats].sort((a, b) => Number(b.c.state === 'running') - Number(a.c.state === 'running') || b.t.memberIds.length - a.t.memberIds.length);
    const focus = ranked[0]?.c.id || null;
    const second = chats.filter((x) => x.c.id !== focus && x.t.memberIds.length > 1)
      .sort((a, b) => Number(b.t.topologyId === 'hierarchy') - Number(a.t.topologyId === 'hierarchy') || b.t.memberIds.length - a.t.memberIds.length)[0]?.c.id || null;
    return { focus, second };
  }, [graph]);

  const pad = width < 600 ? 16 : 32;
  const contentW = Math.min(1100, width - 2 * pad);
  const half = contentW >= 900 ? (contentW - 28) / 2 : contentW;

  if (error) return <View style={styles.page}><Text style={styles.note}>{`Could not load live.json: ${error}`}</Text></View>;
  if (!graph) return <View style={styles.page}><Text style={styles.note}>Loading the live snapshot…</Text></View>;

  const chats = graph.nodes.filter((n) => n.role === 'chat');
  const subs = graph.nodes.filter((n) => n.role === 'subagent');
  const live = graph.nodes.filter((n) => (n.role === 'chat' || n.role === 'subagent') && n.state === 'running').length;
  const host = graph.nodes.find((n) => n.role === 'host')?.label;

  return (
    <View style={styles.page}>
      <Scroll contentContainerStyle={[styles.content, { paddingHorizontal: pad }]}>
        <View style={styles.row}>
          <View style={{ width: contentW }}>
            <View style={styles.hero}>
              <Text style={styles.eyebrow}>AODL VIEWS · LIVING NIGHT</Text>
              <Text style={[styles.h1, width < 600 && { fontSize: 32, lineHeight: 36 }]}>The orchestration, folded and unfolded</Text>
              <Text style={styles.lede}>
                {`${chats.length} chats · ${subs.length} subagents · ${live} live on ${host} · snapshot ${ago(graph.generatedAt, Date.now() / 1000)} old`}
              </Text>
              <Text style={styles.provenance}>
                {`AODL ${aodlSource.sha.slice(0, 7)} · thinking-orbs 0.3.1 · originals: zerOS wip/control-uncommitted-2026-07-16`}
              </Text>
            </View>

            <Section n={1} id="glyph" title="Glyph" line="An orchestration as a badge: the AODL silhouette is the shape, provider hue colours the nodes, runtime cadence sets the motion. Tap a live glyph and it unfolds into its members; tap the hub to fold it.">
              <View style={contentW >= 900 ? { flexDirection: 'row', gap: 28 } : { gap: 26 }}>
                {picks.focus ? (
                  <View style={{ width: half }} testID="decompose-live">
                    <DecomposingGlyph graph={graph} rootId={picks.focus} width={half} defaultOpen onInspect={setInspect} header={<GlyphHeader graph={graph} id={picks.focus} />} />
                  </View>
                ) : null}
                <View style={{ width: half, gap: 26 }}>
                  {picks.second ? (
                    <DecomposingGlyph graph={graph} rootId={picks.second} width={half} onInspect={setInspect} header={<GlyphHeader graph={graph} id={picks.second} />} />
                  ) : null}
                  <DecomposingGlyph
                    topologyId="council"
                    providerId="multi"
                    width={half}
                    header={<View><Text style={styles.gTitle}>Council</Text><Text style={styles.gMeta}>AODL catalog silhouette, zoomed to its pattern</Text></View>}
                  />
                  <DecomposingGlyph
                    topologyId="pipeline"
                    providerId="openai"
                    width={half}
                    header={<View><Text style={styles.gTitle}>Pipeline</Text><Text style={styles.gMeta}>AODL catalog silhouette, zoomed to its pattern</Text></View>}
                  />
                </View>
              </View>
              <Text style={[styles.colLabel, { marginTop: 30 }]}>every AODL topology · 40 / 24 / 16 px</Text>
              <GlyphCatalog width={contentW} />
              <Text style={[styles.colLabel, { marginTop: 24 }]}>runtime cadence</Text>
              <CadenceRow />
            </Section>

            <Section n={2} id="graph" title="Graph" line="Hosts, chats, subagents and the repos they touch. Tap to focus a neighbourhood, hold to inspect.">
              <Compare id="graph" contentW={contentW}>{(w) => <GraphView graph={graph} width={w} initialFocusId={picks.focus} testID="graph-view" />}</Compare>
            </Section>

            <Section n={3} id="tree" title="Tree" line="Who spawned whom, and where each branch sits on the ladder from trunk to leaf.">
              <Compare id="tree" contentW={contentW}>
                {(w) => {
                  const two = w >= 640;
                  const tw = two ? (w - 20) / 2 : w;
                  return (
                    <View style={two ? { flexDirection: 'row', gap: 20 } : { gap: 24 }}>
                      <View style={{ width: tw }}>
                        <Text style={styles.subLabel}>Sessions</Text>
                        <TreeView graph={graph} which="sessions" width={tw} onSelect={setInspect} testID="tree-sessions" />
                      </View>
                      <View style={{ width: tw }}>
                        <Text style={styles.subLabel}>Worktrees</Text>
                        <TreeView graph={graph} which="worktrees" width={tw} onSelect={setInspect} testID="tree-worktrees" />
                      </View>
                    </View>
                  );
                }}
              </Compare>
            </Section>

            <Section n={4} id="topology" title="Topology islands" line="Every chat that delegated, drawn as its glyph. The strip counts chats per topology.">
              <Compare id="topology" contentW={contentW}>{(w) => <TopologyIslands graph={graph} width={w} onInspect={setInspect} testID="islands" />}</Compare>
            </Section>

            <Section n={5} id="repos" title="Repo map" line="Bubble area is touch weight, halved every half-life. Scrub back or change the half-life and the map re-weighs.">
              <Compare id="chat" contentW={contentW}>{(w) => <RepoMap graph={graph} width={w} testID="repo-map" />}</Compare>
            </Section>

            <Section n={6} id="thinking" title="Thinking" line="Agent state as a thinking-orbs orb. A gold rim means it is waiting for you.">
              <Compare id="orbs" contentW={contentW}>{(w) => <ThinkingPanel width={w} />}</Compare>
            </Section>

            {width >= 600 ? (
              <Section n={7} id="phone" title="Phone" line="The same components in a 390 px column, as Dash would mount them.">
                <View style={{ alignItems: 'center' }}><PhoneColumn graph={graph} focusChat={picks.focus} /></View>
              </Section>
            ) : null}

            <View style={styles.footer}>
              <Text style={styles.footerText}>{`kvnloo/aodl-views @ ${process.env.EXPO_PUBLIC_BUILD_SHA || 'dev'}`}</Text>
              <Pressable onPress={() => Linking.openURL('/legacy/gallery.html')}><Text style={styles.link}>legacy zerOS gallery</Text></Pressable>
            </View>
          </View>
        </View>
      </Scroll>
      {inspect ? (
        <View style={styles.inspectOverlay} pointerEvents="box-none">
          <View style={{ width: Math.min(360, width - 32) }}>
            <InspectCard node={inspect} now={graph.generatedAt} onClose={() => setInspect(null)} />
          </View>
        </View>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  page: { flexGrow: 1, backgroundColor: night.canvas, minHeight: '100%' },
  content: { paddingTop: 44, paddingBottom: 80, alignItems: 'center' },
  row: { flexDirection: 'row' },
  note: { color: night.textTertiary, fontFamily: fonts.operational, padding: 24 },
  hero: { marginBottom: 12 },
  eyebrow: { color: night.actionMuted, fontFamily: fonts.telemetry, fontSize: 10, letterSpacing: 2, marginBottom: 12 },
  h1: { color: night.textPrimary, fontFamily: fonts.editorial, fontSize: 44, lineHeight: 48, fontWeight: '500' },
  lede: { color: night.textSecondary, fontFamily: fonts.operational, fontSize: 14, marginTop: 14 },
  provenance: { color: night.textFaint, fontFamily: fonts.telemetry, fontSize: 10, marginTop: 6, lineHeight: 15 },
  section: { marginTop: 48, paddingTop: 30, borderTopWidth: 1, borderTopColor: night.borderQuiet },
  sectionHead: { flexDirection: 'row', alignItems: 'baseline', gap: 12 },
  sectionNum: { color: night.actionMuted, fontFamily: fonts.telemetry, fontSize: 11 },
  sectionTitle: { color: night.textPrimary, fontFamily: fonts.editorial, fontSize: 30, fontWeight: '500' },
  sectionLine: { color: night.textTertiary, fontFamily: fonts.operational, fontSize: 13, lineHeight: 19, marginTop: 6, marginBottom: 22, maxWidth: 660 },
  colLabel: { color: night.textFaint, fontFamily: fonts.telemetry, fontSize: 10, letterSpacing: 1, textTransform: 'uppercase', marginBottom: 10 },
  colLabelNew: { color: night.actionMuted },
  subLabel: { color: night.textTertiary, fontFamily: fonts.operational, fontSize: 12, marginBottom: 6 },
  originalFrame: { overflow: 'hidden', borderRadius: 12, borderWidth: 1, borderColor: night.borderSubtle, opacity: 0.9 },
  link: { color: night.actionMuted, fontFamily: fonts.operational, fontSize: 11, marginTop: 8 },
  catalog: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  cell: { paddingVertical: 12, paddingHorizontal: 12, borderRadius: 12, borderWidth: 1, borderColor: night.borderQuiet, backgroundColor: 'rgba(21,22,17,0.5)' },
  cellGlyphs: { flexDirection: 'row', alignItems: 'center', gap: 10, minHeight: 40 },
  cellTitle: { color: night.textPrimary, fontFamily: fonts.operational, fontSize: 13, marginTop: 8 },
  cellMeta: { color: night.textFaint, fontFamily: fonts.telemetry, fontSize: 10, marginTop: 2 },
  orbCell: { alignItems: 'center', gap: 4 },
  cadence: { flexDirection: 'row', flexWrap: 'wrap', gap: 14 },
  cadenceCell: { alignItems: 'center', gap: 4, width: 76 },
  inlineOrbs: { flexDirection: 'row', flexWrap: 'wrap', gap: 16 },
  inlineOrb: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  gTitle: { color: night.textPrimary, fontFamily: fonts.operational, fontSize: 14 },
  gMeta: { color: night.textTertiary, fontFamily: fonts.operational, fontSize: 11, marginTop: 2 },
  phone: { width: 390, borderRadius: 28, borderWidth: 1, borderColor: night.borderSubtle, padding: 16, backgroundColor: night.canvas },
  phoneTitle: { color: night.textFaint, fontFamily: fonts.telemetry, fontSize: 10, letterSpacing: 1.5, marginBottom: 14 },
  phoneBlock: { marginBottom: 30 },
  phoneOrbs: { flexDirection: 'row', flexWrap: 'wrap', gap: 14 },
  footer: { marginTop: 60, flexDirection: 'row', justifyContent: 'space-between', flexWrap: 'wrap', gap: 10 },
  footerText: { color: night.textFaint, fontFamily: fonts.telemetry, fontSize: 10 },
  inspectOverlay: { position: Platform.OS === 'web' ? ('fixed' as 'absolute') : 'absolute', right: 16, bottom: 16, left: 16, alignItems: 'flex-end' },
});
