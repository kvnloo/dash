# NOTICE

aodl-views is MIT licensed (see LICENSE). It includes or depends on the
following third-party work.

## thinking-orbs — MIT © 2026 Jakub Antalik

- Web: the npm package `thinking-orbs@0.3.1` (dependency, unmodified). Its
  React-free geometry entry `thinking-orbs/engine` is the single source of orb
  geometry on every platform.
- Native: `src/thinking/vendor/thinking-orbs-native/` is the upstream React
  Native port (`ports/react-native/thinking-orbs-native/src`), vendored
  unmodified from the owner's fork `kvnloo/thinking-orbs` at
  `de85557ca220332586d070d8788c0e1d6e877a0d` (0 commits ahead / 0 behind
  `Jakubantalik/thinking-orbs`). The upstream licence is kept next to it as
  `LICENSE`. Fixes go to the fork first, then get re-vendored.

Upstream: https://github.com/Jakubantalik/thinking-orbs · https://orbs.jakubantalik.com

## AODL encodings — kvnloo/aodl

`aodl/visual.json`, `aodl/topology-graphs.json`, `aodl/ir-map.json` and
`aodl/catalog.json` are a pinned copy of `kvnloo/aodl` (commit in
`aodl/SOURCE.json`). They are data; this repository never edits them.

## Fonts (gallery only, not shipped in the library)

Cormorant Garamond, Hanken Grotesk and IBM Plex Mono via `@fontsource/*`
(SIL Open Font License 1.1), copied into the gallery build at build time.
