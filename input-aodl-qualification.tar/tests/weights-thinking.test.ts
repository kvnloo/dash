import { describe, expect, it } from 'vitest';
import { fromLiveSnapshot } from '../src/model/live-snapshot';
import { repoWeights } from '../src/model/repo-weights';
import { ALL_ORB_TYPES, orbFor } from '../src/thinking/mapping';

const NOW = 1_800_000_000;
const H = 3600;

const snap = {
  schemaVersion: 2,
  generatedAt: NOW,
  halfLifeHours: 2,
  chats: [
    { id: 'a', source: 'cli', title: 'A', live: true, lastActivity: NOW, repoTouches: { 'x/old': [[NOW - 10 * H, 40]], 'x/new': [[NOW - 600, 4]] } },
    { id: 'b', source: 'cli', title: 'B', live: false, lastActivity: NOW - H, repoTouches: { 'x/new': [[NOW - H, 2]] } },
  ],
  subagents: [
    { id: 'a1', source: 'subagent', title: 'A1', parent: 'a', live: true, lastActivity: NOW, repoTouches: { 'x/new': [[NOW - 60, 3]] } },
  ],
};

describe('repoWeights (time decay)', () => {
  const g = fromLiveSnapshot(snap);
  it('now, 2h half-life: recent work outweighs old volume', () => {
    const r = repoWeights(g, { halfLifeHours: 2 });
    expect(r.map((x) => x.label)).toEqual(['new', 'old']);
  });
  it('long half-life: the old heavy repo wins again', () => {
    const r = repoWeights(g, { halfLifeHours: 48 });
    expect(r[0].label).toBe('old');
  });
  it('scrubbing back drops touches that had not happened yet', () => {
    const r = repoWeights(g, { at: NOW - 5 * H, halfLifeHours: 2 });
    expect(r.map((x) => x.label)).toEqual(['old']);
  });
  it('scope to one chat counts only its delegation tree', () => {
    const r = repoWeights(g, { scopeRootId: 'chat:b' });
    expect(r.map((x) => x.label)).toEqual(['new']);
    expect(r[0].agents.map((a) => a.node.id)).toEqual(['chat:b']);
  });
  it('groups active agents by root chat and compresses each through AODL rules', () => {
    const [fresh] = repoWeights(g, { halfLifeHours: 2 });
    const byRoot = Object.fromEntries(fresh.groups.map((x) => [x.rootId, x.topology.topologyId]));
    expect(byRoot['chat:a']).toBe('star');
  });
});

describe('thinking-orbs mapping', () => {
  it('reaches all nine orb types', () => {
    const seen = new Set([
      orbFor('idle').orb,
      orbFor('thinking').orb,
      orbFor('thinking', { intent: 'planning' }).orb,
      orbFor('thinking', { intent: 'solving' }).orb,
      orbFor('tool').orb,
      orbFor('tool', { tool: 'web_search' }).orb,
      orbFor('tool', { tool: 'patch' }).orb,
      orbFor('streaming').orb,
      orbFor('streaming', { intent: 'voice' }).orb,
      orbFor('waiting-approval').orb,
    ]);
    expect([...seen].sort()).toEqual([...ALL_ORB_TYPES].sort());
  });
  it('waiting-approval is the only state with the gold rim; idle is frozen', () => {
    expect(orbFor('waiting-approval').rim).toBe(true);
    expect(orbFor('thinking').rim).toBe(false);
    expect(orbFor('idle').paused).toBe(true);
  });
});
