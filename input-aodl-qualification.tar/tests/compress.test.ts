import { describe, expect, it } from 'vitest';
import { compressGraph, topologyFromDeclared } from '../src/model/compress';
import { TOPOLOGY_IDS } from '../src/aodl/encodings';
import type { OrchestrationEdge, OrchestrationGraph, OrchestrationNode } from '../src/model/types';

const agent = (id: string): OrchestrationNode => ({
  id, kind: 'executor', role: 'chat', label: id, providerId: 'anthropic', modelId: 'unknown',
  operatingModeId: 'unknown', state: 'running', weight: 1,
});
const del = (from: string, to: string): OrchestrationEdge => ({ id: `${from}>${to}`, from, to, relation: 'delegation', weight: 1 });
const g = (nodes: string[], edges: OrchestrationEdge[], declared?: OrchestrationGraph['declared']) => ({ nodes: nodes.map(agent), edges, declared });

describe('compressGraph (AODL rules only)', () => {
  it('one executor with no delegation is solo', () => {
    expect(compressGraph(g(['a'], []), 'a')).toMatchObject({ topologyId: 'solo', rule: 'single-executor', memberIds: ['a'] });
  });

  it('delegation fan-out of depth 1 is star, members hub-first', () => {
    const r = compressGraph(g(['a', 'b', 'c', 'd'], [del('a', 'b'), del('a', 'c'), del('a', 'd')]), 'a');
    expect(r.topologyId).toBe('star');
    expect(r.memberIds).toEqual(['a', 'b', 'c', 'd']);
  });

  it('nested delegation is hierarchy', () => {
    const r = compressGraph(g(['a', 'b', 'c', 'd'], [del('a', 'b'), del('a', 'c'), del('b', 'd')]), 'a');
    expect(r.topologyId).toBe('hierarchy');
    expect(r.rule).toBe('delegation-tree');
  });

  it('never infers mesh/ring/swarm from density: peer messages stay unknown', () => {
    const msgs: OrchestrationEdge[] = [];
    const ids = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'];
    for (const x of ids) for (const y of ids) if (x < y) msgs.push({ id: `${x}${y}`, from: x, to: y, relation: 'message', weight: 1 });
    const r = compressGraph(g(ids, [del('a', 'b'), ...msgs]), 'a');
    expect(r.topologyId).toBe('unknown');
    expect(compressGraph(g(ids, msgs)).topologyId).toBe('unknown');
  });

  it('a delegation DAG with two parents is not a tree: unknown', () => {
    const r = compressGraph(g(['a', 'b', 'c', 'd'], [del('a', 'b'), del('a', 'c'), del('b', 'd'), del('c', 'd')]), 'a');
    expect(r.topologyId).toBe('unknown');
  });

  it('declared topology id wins; an id AODL does not define stays unknown', () => {
    expect(compressGraph(g(['a'], [], { topologyId: 'council' }), 'a').topologyId).toBe('council');
    expect(compressGraph(g(['a'], [], { topologyId: 'map_reduce' }), 'a').topologyId).toBe('unknown');
    expect(compressGraph(g(['a'], [], { topologyId: 'debate' }), 'a').rule).toBe('declared-topology');
  });

  it('declared policy kinds compile through ir-map', () => {
    expect(topologyFromDeclared({ policyKinds: ['auction'] })).toBe('marketplace');
    expect(topologyFromDeclared({ policyKinds: ['recursion'] })).toBe('hierarchy');
    expect(topologyFromDeclared({ policyKinds: ['sequence', 'retry'] })).toBe('pipeline');
    expect(topologyFromDeclared({ policyKinds: ['human_gate'] })).toBe('supervisor');
    // fanout+reducer matches council AND cluster exactly: ambiguous, so unknown.
    expect(topologyFromDeclared({ policyKinds: ['fanout', 'reducer'] })).toBe('unknown');
    // retry alone is a modifier with no silhouette.
    expect(topologyFromDeclared({ policyKinds: ['retry'] })).toBe('unknown');
    expect(topologyFromDeclared({ policyKinds: ['payment'] })).toBe('unknown');
  });

  it('swarm and hybrid are never produced by inference', () => {
    const seen = new Set<string>();
    for (const kinds of [['fanout'], ['sequence'], ['fanout', 'reducer'], ['blackboard'], ['reducer'], ['auction']]) {
      seen.add(String(topologyFromDeclared({ policyKinds: kinds })));
    }
    expect(seen.has('swarm')).toBe(false);
    expect(seen.has('hybrid')).toBe(false);
  });

  it('every returned id is an AODL visual.json id', () => {
    for (const declared of ['solo', 'nope', 'swarm', '', 'unknown']) {
      expect(TOPOLOGY_IDS).toContain(compressGraph(g(['a'], [], { topologyId: declared }), 'a').topologyId);
    }
  });

  it('missing root is unknown with no members', () => {
    expect(compressGraph(g(['a'], []), 'zzz')).toEqual({ topologyId: 'unknown', rule: 'none', memberIds: [] });
  });
});
