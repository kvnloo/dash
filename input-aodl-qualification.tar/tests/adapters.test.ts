import { describe, expect, it } from 'vitest';
import { ago, decayFactor, weightAt } from '../src/model/decay';
import { fromLiveSnapshot, parseLiveSnapshot, phaseFromActivity } from '../src/model/live-snapshot';
import { fromDashRoster, fromZ0BridgeSessions } from '../src/model/roster';
import { resolveModel } from '../src/aodl/encodings';
import { classifyWorktreeTier, packKey } from '../src/model/worktrees';
import { sessionTree, worktreeTree } from '../src/model/tree';

const NOW = 1_800_000_000;
const H = 3600;

const snapshotV2 = {
  schemaVersion: 2,
  generatedAt: NOW,
  halfLifeHours: 2,
  host: 'groot',
  chats: [
    { id: 'c1', source: 'cli', title: 'Debug Hermes', model: 'claude-opus-5-5', parent: null, live: true, lastActivity: NOW - 30, activity: 'tool running: terminal',
      repoTouches: { 'kvnloo/dash': [[NOW - 600, 3]], 'kvnloo/aodl': [[NOW - 4 * H, 8]] } },
    { id: 'c2', source: 'telegram', title: 'Plan garden', model: 'gpt-6.1-sol', parent: null, live: false, ended: true, lastActivity: NOW - 3 * H, activity: '' },
    { id: 'c3', source: 'oneshot', title: 'one shot', model: 'x', parent: null, live: false, lastActivity: NOW - 60 },
    { id: 'c4', source: 'cron', title: 'nightly', model: 'codex-sol-1', parent: null, live: false, ended: false, lastActivity: NOW - 2 * H },
  ],
  subagents: [
    { id: 's1', source: 'subagent', title: 'Subagent: build glyph', model: 'claude-opus-5-5', parent: 'c1', live: true, lastActivity: NOW - 5, activity: 'receiving stream response',
      repoTouches: { 'kvnloo/dash': [[NOW - 60, 5]] } },
    { id: 's2', source: 'subagent', title: 'Subagent: nested', model: 'anthropic/claude-haiku-4.5', parent: 's1', live: false, ended: true, lastActivity: NOW - 900 },
    { id: 's3', source: 'subagent', title: 'Subagent: of a one-shot', parent: 'c3', live: false, lastActivity: NOW - 90 },
    { id: 's4', source: 'subagent', title: 'Subagent: orphan', parent: 'gone', live: false, lastActivity: NOW - 90 },
  ],
  worktrees: [
    { path: '/w/dash', branch: 'integrate/dash-v2', repo: 'kvnloo/dash', name: 'dash', isPrimary: true },
    { path: '/w/dash-main', branch: 'main', repo: 'kvnloo/dash', name: 'dash-main' },
    { path: '/w/feat', branch: 'feat/x', repo: 'kvnloo/dash', name: 'x' },
    { path: '/w/t1', branch: 'tour/perf/gen1-a', repo: 'kvnloo/dash', name: 'a' },
    { path: '/w/t2', branch: 'tour/perf/gen1-b', repo: 'kvnloo/dash', name: 'b' },
    { path: '/w/d', repo: 'kvnloo/dash', name: 'detached' },
  ],
};

describe('decay', () => {
  it('halves every half-life and ignores future touches', () => {
    expect(decayFactor(0, 2)).toBe(1);
    expect(decayFactor(2 * H, 2)).toBeCloseTo(0.5, 10);
    expect(decayFactor(6 * H, 2)).toBeCloseTo(0.125, 10);
    const touches = [[NOW - 2 * H, 4], [NOW, 1], [NOW + H, 100]] as const;
    expect(weightAt(touches, NOW, 2)).toBeCloseTo(4 * 0.5 + 1, 10);
    // Scrubbing back: the later touch has not happened yet.
    expect(weightAt(touches, NOW - 2 * H, 2)).toBeCloseTo(4, 10);
  });

  it('half-life re-ranks: short favours recent, long favours volume', () => {
    const recent = [[NOW - 600, 3]] as const;
    const heavy = [[NOW - 4 * H, 8]] as const;
    expect(weightAt(recent, NOW, 0.5)).toBeGreaterThan(weightAt(heavy, NOW, 0.5));
    expect(weightAt(heavy, NOW, 8)).toBeGreaterThan(weightAt(recent, NOW, 8));
  });

  it('formats ages', () => {
    expect(ago(NOW - 42, NOW)).toBe('42s');
    expect(ago(NOW - 7 * 60, NOW)).toBe('7m');
    expect(ago(NOW - 3 * H, NOW)).toBe('3h');
    expect(ago(undefined, NOW)).toBe('—');
  });
});

describe('fromLiveSnapshot', () => {
  const g = fromLiveSnapshot(snapshotV2);
  const node = (id: string) => g.nodes.find((n) => n.id === id);

  it('maps sessions to AODL executors with role, provider, cadence and phase', () => {
    expect(node('chat:c1')).toMatchObject({ kind: 'executor', role: 'chat', providerId: 'anthropic', state: 'running', phase: 'tool', tool: 'terminal', operatingModeId: 'copilot' });
    expect(node('chat:c2')).toMatchObject({ state: 'paused', phase: 'idle', providerId: 'openai', modelId: 'unknown' });
    expect(node('chat:c4')).toMatchObject({ state: 'stale', operatingModeId: 'batch', providerId: 'openai', modelId: 'codex-sol' });
    expect(node('subagent:s1')).toMatchObject({ role: 'subagent', phase: 'streaming', label: 'build glyph', parentId: 'chat:c1' });
    expect(node('subagent:s2')).toMatchObject({ parentId: 'subagent:s1', modelId: 'claude-haiku' });
  });

  it('drops one-shots and their subagents, keeps orphans under the host', () => {
    expect(node('chat:c3')).toBeUndefined();
    expect(node('subagent:s3')).toBeUndefined();
    expect(node('subagent:s4')).toMatchObject({ parentId: undefined, hostId: 'host:groot' });
  });

  it('emits delegation and artifact edges with raw touches', () => {
    const rel = g.edges.map((e) => `${e.relation}:${e.from}->${e.to}`);
    expect(rel).toContain('delegation:chat:c1->subagent:s1');
    expect(rel).toContain('delegation:subagent:s1->subagent:s2');
    const art = g.edges.find((e) => e.id === 'artifact:chat:c1->repo:kvnloo/aodl')!;
    expect(art.touches).toEqual([[NOW - 4 * H, 8]]);
    expect(art.weight).toBeCloseTo(8 * 0.25, 10);
  });

  it('repo weight sums every touching session', () => {
    const dash = node('repo:kvnloo/dash')!;
    expect(dash.kind).toBe('artifact');
    expect(dash.weight).toBeCloseTo(3 * decayFactor(600, 2) + 5 * decayFactor(60, 2), 10);
  });

  it('classifies worktrees into ladder tiers', () => {
    const tiers = Object.fromEntries(g.nodes.filter((n) => n.role === 'worktree').map((n) => [n.label, n.meta?.tier]));
    expect(tiers).toEqual({ dash: 'integration', 'dash-main': 'trunk', x: 'feature', a: 'leaf', b: 'leaf', detached: 'leaf' });
  });

  it('accepts schema 1 (pre-decayed weights) and rejects junk', () => {
    const v1 = { generatedAt: NOW, chats: [{ id: 'a', source: 'cli', title: 't', live: true, lastActivity: NOW, repos: { 'x/y': 2.5 } }], subagents: [] };
    const g1 = fromLiveSnapshot(v1);
    expect(g1.nodes.find((n) => n.id === 'repo:x/y')?.weight).toBeCloseTo(2.5, 10);
    expect(fromLiveSnapshot(null).nodes).toEqual([]);
    expect(parseLiveSnapshot({ chats: [] })).toBeNull();
    expect(fromLiveSnapshot({ generatedAt: NOW, chats: [{ nope: 1 }, 'x'], subagents: 7 }).nodes.map((n) => n.role)).toEqual(['host']);
  });
});

describe('phaseFromActivity', () => {
  it.each([
    ['tool running: clarify', 'waiting-approval'],
    ['terminal command running (20s elapsed)', 'tool'],
    ['delegate_task: subagent running terminal (iteration 3)', 'tool'],
    ['receiving stream response', 'streaming'],
    ['', 'thinking'],
  ])('%s -> %s', (activity, phase) => {
    expect(phaseFromActivity(activity, true).phase).toBe(phase);
  });
  it('not live is idle', () => expect(phaseFromActivity('tool running: terminal', false).phase).toBe('idle'));
});

describe('resolveModel', () => {
  it('uses AODL ownerRules first, then provider family only', () => {
    expect(resolveModel('codex-sol')).toEqual({ providerId: 'openai', modelId: 'codex-sol' });
    expect(resolveModel('kimi-k2')).toEqual({ providerId: 'moonshot', modelId: 'kimi' });
    expect(resolveModel('claude-opus-5-5')).toEqual({ providerId: 'anthropic', modelId: 'unknown' });
    expect(resolveModel('meituan/longcat-2.0')).toEqual({ providerId: 'unknown', modelId: 'unknown' });
    expect(resolveModel(null)).toEqual({ providerId: 'unknown', modelId: 'unknown' });
  });
});

describe('roster adapters', () => {
  it('Dash HostInfo[] -> hosts + agents, no invented edges', () => {
    const g = fromDashRoster([
      { id: 'groot', name: 'groot', hostname: 'groot', online: true, self: true, agents: [
        { id: 'h1', name: 'Hermes', kind: 'hermes', status: 'running' },
        { id: 'c1', name: 'Codex', kind: 'codex', status: 'available' },
      ] },
      { bad: true },
    ], NOW);
    expect(g.edges).toEqual([]);
    expect(g.nodes.map((n) => `${n.role}:${n.state}`)).toEqual(['host:running', 'chat:running', 'chat:paused']);
    expect(g.nodes[2]).toMatchObject({ providerId: 'openai', modelId: 'codex', hostId: 'host:groot' });
  });

  it('z0bridge SessionList -> chats with ms timestamps converted', () => {
    const g = fromZ0BridgeSessions({ sessions: [
      { harness: 'hermes', profile: 'clean', id: 's', title: 'T', source: 'cli', startedAt: 0, lastActivityAt: (NOW - 60) * 1000, messageCount: 4, ended: false },
      { harness: 'codex', profile: 'p', id: 'e', title: 'E', source: 'cli', startedAt: 0, lastActivityAt: (NOW - 4 * H) * 1000, messageCount: 1, ended: true },
    ] }, { now: NOW, hostId: 'groot' });
    expect(g.nodes[1]).toMatchObject({ state: 'running', lastActivity: NOW - 60, harnessId: 'hermes' });
    expect(g.nodes[2]).toMatchObject({ state: 'paused', providerId: 'openai' });
    expect(g.nodes[2].weight).toBeCloseTo(0.25, 10);
  });
});

describe('worktree ladder', () => {
  it('tiers and packs by branch name only', () => {
    expect(classifyWorktreeTier({ branch: 'dev' })).toBe('trunk');
    expect(classifyWorktreeTier({ branch: 'hitl/compressed-pure' })).toBe('integration');
    expect(classifyWorktreeTier({ branch: 'qualification/oura' })).toBe('integration');
    expect(classifyWorktreeTier({ branch: 'ovt/4-GT-ROI' })).toBe('feature');
    expect(classifyWorktreeTier({ branch: 'worktree-agent-ae3' })).toBe('leaf');
    expect(classifyWorktreeTier({ branch: '', name: 'x' })).toBe('leaf');
    expect(packKey('tour/brain-perf/gen1-io')).toBe('tour/brain-perf');
    expect(packKey('ovt/4-GT-ROI')).toBe('ovt');
    expect(packKey('feat/x')).toBeNull();
    expect(packKey(undefined)).toBe('detached');
  });
});

describe('trees', () => {
  const g = fromLiveSnapshot(snapshotV2);
  it('host -> chat -> subagents, nested, with chat glyph compression', () => {
    const [host] = sessionTree(g);
    expect(host.label).toBe('groot');
    const c1 = host.children.find((c) => c.id === 'chat:c1')!;
    expect(c1.topology?.topologyId).toBe('hierarchy');
    expect(c1.children[0].children[0].id).toBe('subagent:s2');
    expect(c1.count).toBe(2);
    expect(host.children.find((c) => c.id === 'chat:c2')!.topology?.topologyId).toBe('solo');
    expect(host.children.some((c) => c.id === 'subagent:s4')).toBe(true);
  });
  it('repo -> trunk -> integration -> features/packs -> leaves', () => {
    const [dash] = worktreeTree(g);
    expect(dash.children.map((t) => t.tier)).toEqual(['trunk', 'integration', 'feature', 'leaf']);
    const leaves = dash.children[3];
    expect(leaves.children.map((c) => `${c.type}:${c.label}:${c.count}`)).toEqual(['pack:tour/perf:2', 'pack:detached:1']);
  });
});
