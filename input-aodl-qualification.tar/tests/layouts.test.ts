import { describe, expect, it } from 'vitest';
import { layoutGraph, LAYOUT_MODES, projectGraph, thinEdges } from '../src/layout/graph-layout';
import { fitPack, packCircles } from '../src/layout/pack';
import { assignMembers, glyphFrame, memberLayout } from '../src/layout/glyph-geometry';
import { aodlSource, silhouette, TOPOLOGY_IDS, visual } from '../src/aodl/encodings';
import type { OrchestrationGraph, OrchestrationNode } from '../src/model/types';

const n = (id: string, role: OrchestrationNode['role'], state: OrchestrationNode['state'] = 'paused', weight = 0.1): OrchestrationNode => ({
  id, role, kind: role === 'repo' ? 'artifact' : role === 'host' ? 'environment' : 'executor', label: id,
  providerId: 'unknown', modelId: 'unknown', operatingModeId: 'unknown', state, weight,
});

function bigGraph(): OrchestrationGraph {
  const nodes = [n('h', 'host', 'running', 1)];
  const edges: OrchestrationGraph['edges'] = [];
  for (let i = 0; i < 20; i += 1) {
    nodes.push(n(`c${i}`, 'chat', i < 3 ? 'running' : 'paused', i < 3 ? 1 : 0.01));
    nodes.push(n(`r${i}`, 'repo', 'running', 20 - i));
    edges.push({ id: `a${i}`, from: `c${i}`, to: `r${i}`, relation: 'artifact', weight: 1 });
  }
  return { source: 'live-snapshot', generatedAt: 0, halfLifeHours: 2, nodes, edges };
}

describe('focus projection', () => {
  it('keeps hot nodes up to the cap and folds the rest into one quiet node per role', () => {
    const p = projectGraph(bigGraph(), { mode: 'focus' });
    const chats = p.nodes.filter((x) => x.role === 'chat');
    expect(chats.filter((x) => !x.folded)).toHaveLength(8);
    expect(chats.filter((x) => !x.folded).slice(0, 3).map((x) => x.id)).toEqual(['c0', 'c1', 'c2']);
    const quiet = chats.find((x) => x.folded)!;
    expect(quiet.id).toBe('quiet:chat');
    expect(quiet.folded).toHaveLength(12);
    expect(p.hidden).toBe(24);
    // Edges into folded members re-point at aggregates and stay unique.
    const ids = p.edges.map((e) => e.id);
    expect(new Set(ids).size).toBe(ids.length);
    for (const e of p.edges) {
      expect(p.nodes.some((x) => x.id === e.from)).toBe(true);
      expect(p.nodes.some((x) => x.id === e.to)).toBe(true);
    }
  });

  it('always keeps the focused node and its neighbours', () => {
    const p = projectGraph(bigGraph(), { mode: 'focus', focusId: 'c19' });
    expect(p.nodes.some((x) => x.id === 'c19')).toBe(true);
    expect(p.nodes.some((x) => x.id === 'r19')).toBe(true);
  });

  it('all mode shows everything', () => {
    expect(projectGraph(bigGraph(), { mode: 'all' }).nodes).toHaveLength(41);
  });
});

describe('thinEdges', () => {
  it('keeps each agent\'s strongest repos and every delegation edge', () => {
    const e = (id: string, from: string, relation: 'artifact' | 'delegation', weight: number) => ({ id, from, to: `${id}:to`, relation, weight });
    const out = thinEdges([
      e('a1', 'x', 'artifact', 10), e('a2', 'x', 'artifact', 5), e('a3', 'x', 'artifact', 4),
      e('tiny', 'y', 'artifact', 0.1), e('d', 'x', 'delegation', 0.01),
    ], { perAgent: 2, minShare: 0.05 });
    expect(out.map((x) => x.id).sort()).toEqual(['a1', 'a2', 'd']);
  });
});

describe('graph layouts', () => {
  const p = projectGraph(bigGraph(), { mode: 'focus' });
  for (const { id } of LAYOUT_MODES) {
    for (const [w, h] of [[390, 420], [1040, 520]]) {
      it(`${id} at ${w}x${h} places every node inside the box, deterministically`, () => {
        const a = layoutGraph(p, w, h, id, 'c0');
        const b = layoutGraph(p, w, h, id, 'c0');
        expect(a.size).toBe(p.nodes.length);
        for (const [key, v] of a) {
          expect(v.x).toBeGreaterThanOrEqual(0);
          expect(v.x).toBeLessThanOrEqual(w);
          expect(v.y).toBeGreaterThanOrEqual(0);
          expect(v.y).toBeLessThanOrEqual(h);
          expect(b.get(key)).toEqual(v);
        }
      });
    }
  }
});

describe('circle packing', () => {
  it('packs without overlap and fits the box', () => {
    const items = Array.from({ length: 24 }, (_, i) => ({ id: `r${i}`, r: 6 + ((i * 37) % 30) }));
    const { circles } = fitPack(packCircles(items, 1.6), 1040, 420);
    expect(circles).toHaveLength(24);
    for (let i = 0; i < circles.length; i += 1) {
      const a = circles[i];
      expect(a.x - a.r).toBeGreaterThanOrEqual(-0.01);
      expect(a.x + a.r).toBeLessThanOrEqual(1040.01);
      expect(a.y - a.r).toBeGreaterThanOrEqual(-0.01);
      expect(a.y + a.r).toBeLessThanOrEqual(420.01);
      for (let j = i + 1; j < circles.length; j += 1) {
        const b = circles[j];
        expect(Math.hypot(a.x - b.x, a.y - b.y)).toBeGreaterThanOrEqual(a.r + b.r - 0.01);
      }
    }
  });
  it('biggest circle sits nearest the centre', () => {
    const packed = packCircles([{ id: 'small', r: 2 }, { id: 'big', r: 20 }, { id: 'mid', r: 8 }]);
    expect(packed[0]).toMatchObject({ id: 'big', x: 0, y: 0 });
  });
});

describe('AODL silhouettes', () => {
  it('vendored encodings are pinned to an AODL commit', () => {
    expect(aodlSource.repo).toBe('kvnloo/aodl');
    expect(aodlSource.sha).toMatch(/^[0-9a-f]{40}$/);
  });
  it('every visual topology id has a silhouette whose edges point at drawn nodes', () => {
    expect(TOPOLOGY_IDS).toEqual(Object.keys(visual.topologies));
    for (const id of TOPOLOGY_IDS) {
      const s = silhouette(id);
      for (const [a, b] of s.edges) {
        expect(a).toBeLessThan(s.nodes.length);
        expect(b).toBeLessThan(s.nodes.length);
      }
    }
    expect(silhouette('blackboard').centerIndex).toBe(6);
    expect(silhouette('unknown').nodes).toEqual([]);
  });
  it('glyph frame scales the 72x44 silhouette into the box', () => {
    const f = glyphFrame('pipeline', 72 * 2, 44 * 2);
    expect(f.scale).toBe(2);
    expect(f.points[0]).toEqual({ x: 18, y: 44, r: 7 });
  });
  it('members follow the delegation tree onto star/hierarchy nodes; overflow stays unmapped', () => {
    const kids: Record<string, string[]> = { root: ['a', 'b'], a: ['a1', 'a2', 'a3'], b: ['b1'] };
    const map = assignMembers('hierarchy', ['root', 'a', 'b', 'a1', 'a2', 'a3', 'b1'], (id) => kids[id] || []);
    expect(map.get('root')).toBe(0);
    expect(map.get('a')).toBe(1);
    expect(map.get('b')).toBe(2);
    expect([map.get('a1'), map.get('a2')]).toEqual([3, 4]);
    expect(map.has('a3')).toBe(false);
    expect(map.get('b1')).toBe(5);
  });
  it('decomposed layout: star rings the hub, deeper trees are layered', () => {
    const star = memberLayout('h', (id) => (id === 'h' ? ['a', 'b', 'c'] : []), 300, 200);
    expect(star.get('h')).toEqual({ x: 150, y: 100, depth: 0 });
    const tree = memberLayout('h', (id) => ({ h: ['a', 'b'], a: ['a1'] } as Record<string, string[]>)[id] || [], 300, 200);
    expect(tree.get('h')!.y).toBeLessThan(tree.get('a')!.y);
    expect(tree.get('a')!.y).toBeLessThan(tree.get('a1')!.y);
  });
});
