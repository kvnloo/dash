import { useCallback, useMemo } from "react";
import { Alert } from "react-native";
import type { AgentInfo, BotInfo, HostInfo } from "../../../../shared/protocol";
import { Tree } from "../../components/Tree";
import { botsTree, hostLabel } from "../../lib/bots-tree";
import { botSummary } from "../../lib/bots";
import { profileFromAgent } from "../../lib/roster";
import { inAppFeedbackEnabled } from "../../lib/feedback";
import { submitInAppFeedback } from "../../lib/feedback-submit";
import type { ScreenProps } from "../../navigation";
import { openAgentConversation, store } from "../../store/app";

export function BotsPane({ navigation }: Pick<ScreenProps<"Main">, "navigation">) {
  const hosts = store.use(s => s.connection.hosts);
  const conversations = store.use(s => s.conversations);
  const open = useCallback((host: HostInfo, agent: AgentInfo) => {
    const result = openAgentConversation(profileFromAgent(host, agent));
    if ("error" in result) { Alert.alert("Session unavailable", result.error); return; }
    navigation.navigate("Chat");
  }, [navigation]);
  const actions = useCallback((host: HostInfo, bot?: BotInfo) => {
    const name = bot?.name ?? hostLabel(host);
    Alert.alert(name, bot ? botSummary(bot) : `${host.address ?? "No address"} · ${host.online ? "Online" : "Offline"}`, [
      { text: "Close", style: "cancel" },
      ...(bot && inAppFeedbackEnabled(store.get().settings) ? [{ text: "Send feedback", onPress: () => {
        submitInAppFeedback({ kind: "select", text: `Selected bot ${bot.name}`, selection: { kind: "bot", id: bot.id, label: bot.name } });
        navigation.navigate("Chat");
      } }] : []),
    ]);
  }, [navigation]);
  const nodes = useMemo(() => botsTree(hosts, open, actions, Date.now(), conversations), [hosts, open, actions, conversations]);
  return <Tree nodes={nodes} label="Bots, harnesses and sessions" />;
}
