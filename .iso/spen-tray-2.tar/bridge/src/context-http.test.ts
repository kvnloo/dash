import { describe, expect, test } from "bun:test";
import { Database } from "bun:sqlite";
import { mkdtempSync, rmSync } from "node:fs";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { contextHttp, parseProviderUsage, planCache } from "./context-http";
import { HermesSessions } from "./hermes-sessions";
import { contextFixture } from "../../shared/context.test";

describe("provider plan projection", () => {
  test("allows percentages and reset timestamps, never identity or tokens", () => {
    const result = parseProviderUsage([{ provider: "claude", token: "never-forward", usage: { identity: { email: "private" }, primary: { usedPercent: 68, resetsAt: "2026-10-22T01:00:00Z" }, secondary: { usedPercent: 24 }, extraRateWindows: [{ title: "Opus", window: { usedPercent: 17 } }] } }], "claude");
    expect(result).toEqual({ provider: "claude", windows: [{ label: "Session limit", percent: 68, resetsAt: "2026-10-22T01:00:00Z" }, { label: "Weekly limit", percent: 24 }, { label: "Opus", percent: 17 }] });
    expect(JSON.stringify(result)).not.toMatch(/private|never-forward|identity|token/);
  });
  test("handles missing and malformed windows without inventing zero", () => {
    expect(parseProviderUsage(null, "codex")).toEqual({ provider: "codex", windows: [], unavailable: true });
    expect(parseProviderUsage([{ provider: "codex", usage: { primary: null, secondary: { usedPercent: 14 }, tertiary: { usedPercent: NaN } } }], "codex").windows).toEqual([{ label: "Weekly limit", percent: 14 }]);
    for (const usedPercent of [-1, 101, Infinity, "20"]) expect(parseProviderUsage({ provider: "claude", usage: { primary: { usedPercent } } }, "claude").windows).toEqual([]);
  });
  test("coalesces and caches 60 seconds", async () => {
    let calls = 0; let now = 0;
    const read = planCache(async provider => { calls++; return { provider, windows: [] }; }, () => now);
    const first = read(); expect(read()).toBe(first); await first; expect(calls).toBe(2);
    now = 59_999; await read(); expect(calls).toBe(2);
    now = 60_000; await read(); expect(calls).toBe(4);
  });
});

test("context endpoint authenticates, resolves native identity, verifies compaction readback", async () => {
  const root = mkdtempSync(join(tmpdir(), "dash-context-"));
  try {
    const db = new Database(join(root, "state.db"));
    db.exec("CREATE TABLE sessions(id TEXT,source TEXT,title TEXT,started_at REAL,last_activity_at REAL,message_count INTEGER,cwd TEXT,archived INTEGER,hidden INTEGER,parent_session_id TEXT,end_reason TEXT,model_config TEXT); INSERT INTO sessions VALUES('scratch','cli','Scratch',1,1,2,'/workspace',0,0,NULL,NULL,'{}');"); db.close();
    const sessions = new HermesSessions({ root, env: {} });
    let reads = 0; let writes = 0;
    const handler = contextHttp({ sessions, plans: async () => [], read: async () => { reads++; return contextFixture(writes ? { used: 80_000, revision: "summary" } : {}); }, compact: async () => { writes++; return { ok: true, code: "committed" }; } });
    const url = "http://localhost/chat/context?profile=default&session=scratch";
    expect((await handler(new Request(url), false))?.status).toBe(401); expect(reads).toBe(0);
    expect((await handler(new Request(url.replace("scratch", "unknown")), true))?.status).toBe(404);
    expect((await handler(new Request(url.replace("default", "../../etc")), true))?.status).toBe(404);
    expect((await handler(new Request(url, { method: "POST" }), true))?.status).toBe(405);
    const response = await handler(new Request(url.replace("context?", "context/compact?"), { method: "POST" }), true);
    expect(response?.status).toBe(200); expect(writes).toBe(1); expect(reads).toBe(2);
    expect(await response?.json()).toMatchObject({ ok: true, context: { used: 80_000, revision: "summary" } });
  } finally { rmSync(root, { recursive: true, force: true }); }
});

test("read-only usage sheet separates context reads from provider work and keeps compaction unavailable", async () => {
  const root = mkdtempSync(join(tmpdir(), "dash-usage-"));
  try {
    const db = new Database(join(root, "state.db"));
    db.exec("CREATE TABLE sessions(id TEXT,source TEXT,title TEXT,started_at REAL,last_activity_at REAL,message_count INTEGER,cwd TEXT,archived INTEGER,hidden INTEGER,parent_session_id TEXT,end_reason TEXT,model_config TEXT); INSERT INTO sessions VALUES('scratch','cli','Scratch',1,1,2,'/workspace',0,0,NULL,NULL,'{}');"); db.close();
    let plans = 0; let reads = 0;
    const handler = contextHttp({ sessions: new HermesSessions({ root, env: {} }), read: async () => { reads++; return contextFixture(); }, plans: async () => { plans++; return [{ provider: "codex", windows: [], unavailable: true }]; } });
    const url = "http://localhost/chat/context?profile=default&session=scratch";
    expect((await handler(new Request(url.replace("context?", "usage?")), false))?.status).toBe(401);
    expect(plans).toBe(0); expect(reads).toBe(0);
    expect(await (await handler(new Request(url), true))?.json()).toMatchObject({ compactionSupported: false, plans: [] });
    expect(plans).toBe(0);
    expect(await (await handler(new Request(url.replace("context?", "usage?")), true))?.json()).toMatchObject({ plans: [{ provider: "codex", unavailable: true }] });
    expect(plans).toBe(1);
    expect((await handler(new Request(url.replace("context?", "context/compact?"), { method: "POST" }), true))?.status).toBe(501);
    expect(reads).toBe(2);
  } finally { rmSync(root, { recursive: true, force: true }); }
});
test("burn uses only valid observed weekly windows and never invents a reset or window length", () => {
  const now = Date.parse("2026-10-25T00:00:00Z");
  const weekly = { usedPercent: 50, resetsAt: "2026-10-25T12:00:00Z", windowMinutes: 1440 };
  expect(parseProviderUsage({ provider: "codex", usage: { secondary: weekly } }, "codex", now).burn).toEqual({ observed: 50 / 12, sustainable: 50 / 12, ratio: 1 });
  expect(parseProviderUsage({ provider: "codex", usage: { secondary: { ...weekly, windowMinutes: undefined } } }, "codex", now).burn).toBeUndefined();
  expect(parseProviderUsage({ provider: "codex", usage: { secondary: { ...weekly, resetsAt: "invalid" } } }, "codex", now).burn).toBeUndefined();
});
